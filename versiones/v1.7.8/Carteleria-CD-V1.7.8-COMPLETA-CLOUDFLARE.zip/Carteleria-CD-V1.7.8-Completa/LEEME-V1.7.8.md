# Cartelería C&D SBA V1.7.8

Base: V1.7.7 completa recuperada del ZIP publicado por el usuario. Cambios:
- Indicadores por lista EDLP y Lista Promocional bajo los totales, en Layout panorámico y Filtro Categorías del local autenticado.
- Estado destacado IMPRESO · N / NO IMPRESO por cartel, con el precio vigente. Sin verificar si falla la consulta.
- Registro idempotente de confirmaciones de impresión por ticket en tabla nueva carteleria_print_events82. Conserva tabla de recibos y fecha de inicio V1.7.7.
- Contador también en detalle de impresos del Administrador/jefe de mercado. No cambia la adherencia única.
- Los indicadores operativos son específicos del local; no se presentan cifras de un local no seleccionado a perfiles de mercado o administrador.
- No altera promociones, OCCAM, accesos, colas, alertas ni revisión semanal. No requiere eliminar ni reemplazar datos existentes.

El porcentaje usa carteles vigentes imprimibles y no bloqueados, igual que el reporte V1.7.7. Las impresiones previas verificadas se conservan con un mínimo de 1; repeticiones anteriores no recuperables. El contador es de confirmaciones por trabajo distinto, no copias físicas. Una versión antigua que siga abierta no envía el identificador nuevo, por lo que debe recargarse después de publicar para obtener deduplicación por ticket. No publicado en Cloudflare; falta comprobación en producción.
