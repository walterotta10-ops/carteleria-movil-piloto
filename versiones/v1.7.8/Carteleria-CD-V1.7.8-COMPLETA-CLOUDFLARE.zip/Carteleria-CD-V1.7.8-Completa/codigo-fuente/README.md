# Actualización V1.7.8 · Porcentaje por lista y contador de impresiones

Compilar: `node build.cjs`. Resultado: `worker-v1.7.8.mjs`.
Pruebas: `node tests/v177/test-compliance.cjs`, `node tests/v178/test-print-count.cjs` y `node tests/v178/test-local-print-view.cjs` (Node 22+). Mantener D1 y sus registros.

# V1.7.7 · Impresión de cartelería por mercado/local

Se incorporó `src/print-compliance-backend.mjs` y `src/app/print-compliance.js`, se amplió la confirmación en `src/app/alert-printing.js`, y `build.cjs` genera `worker-v1.7.7.mjs`. El seguimiento inicia con la primera activación y no deduce históricos. Consulta LEEME-V1.7.7.md en el ZIP.

---

# Cartelería C&D · V1.7.5 completa

**Consultas limitadas a la función que se utiliza.** El menú, Uso por local y Manual no cargan promociones al entrar. Layout carga el catálogo al abrirlo y recorre departamentos y categorías con esos datos, sin consultar cola, revisión semanal o reportes por cada clic. La cola conserva la sincronización cuando se abre y cuando hay cambios pendientes.

La vista macro de Administrador carga sus estadísticas. Catálogo, interacciones e historial de cargas se consultan al abrir sus secciones. Uso por local consulta únicamente los locales del mercado autorizado.

Los productos, las fichas verificadas y la respuesta común se reutilizan por revisión de catálogo, revisión de fichas y día de Chile, con memoria acotada. Los recibos permanecen separados por local. Antes de imprimir se comprueba la versión vigente y el servidor rechaza confirmaciones obsoletas.

Se conserva la optimización de fechas y de planes de V1.7.4. La revisión semanal prepara sus grupos cuando se solicita y no se reinicia el ciclo del 16/11 ni se borran revisiones guardadas.

Las pruebas comprueban navegación sin consultas adicionales, recuperación de sincronización de cola, sesiones sin reenvíos duplicados, igualdad de datos con V1.7.4 y permisos e impresión. Consulta **COMPROBACIONES-V1.7.5.md** y **DIAGNOSTICO-CONSUMO-V1.7.5.md**.

La primera preparación del catálogo sigue teniendo coste. La versión reduce trabajo repetido; no garantiza que cada solicitud cumpla el presupuesto del plan gratuito de Cloudflare. El historial técnico de CPU debe comprobarse en Cloudflare después de publicar.

Se mantienen la recuperación de errores de lectura de V1.7.3 y el popup preciso de la i.

Las alertas corresponden al **último reporte aplicado**. Se mantienen hasta aplicar otro reporte, cualquiera sea el tiempo transcurrido. **No vencen a los 7 días ni dependen de un jueves o de una semana calendario.**

## Publicar en el Worker existente

1. Abre el Worker de Cartelería en Cloudflare.
2. Reemplaza el código completo por **CLOUDFLARE-CYD-V1.7.5-COMPLETA.js** y publica.
3. Conserva la vinculación **DB** a la misma base D1 y el secreto **ADMIN_PASSWORD**.
4. Recarga la aplicación en PC y teléfonos. El encabezado y `/health` deben mostrar **V1.7.5**.

Este paquete está preparado y probado; no publica por sí solo. No es necesario instalar versiones intermedias ni volver a cargar el reporte vigente.

## Alertas del último reporte

- Seleccionar un archivo o pulsar **Revisar carga** no reemplaza las alertas. El cambio ocurre al confirmar **Aplicar carga** y guardarse correctamente.
- Un nuevo reporte de OCCAM o de Actualización de los jueves reemplaza las alertas anteriores. Quedan únicamente los cambios de precios de esa carga, aunque se aplique al día siguiente o varias semanas después.
- Si el nuevo reporte solo corrige descripciones o medidas y no cambia precios, no hereda las alertas antiguas.
- Los precios ya corregidos se incorporan a la lista. No vuelven a los precios anteriores al cambiar de reporte ni cuando un producto deja de aparecer en la actualización de los jueves.
- Las correcciones individuales de precios conservan el resto de las alertas del reporte vigente. El siguiente reporte aplicado reemplaza ese conjunto.
- Las confirmaciones de impresión se conservan por local. Una impresión anterior no confirma automáticamente un cambio nuevo.

En **Carteles**, en el detalle y en el **Layout OCCAM**, los productos corregidos muestran **Corregido el…**, con fecha y hora de Chile y el archivo que originó la corrección. La fecha corresponde a la aplicación efectiva, no a la selección del archivo.

## Información y carteles con fallas

Cada alerta incluye una **i dentro de un círculo**. Al abrirla se consulta la información vigente y se muestra el cambio concreto. Si no se puede imprimir, indica la causa: medida, descripción o marca faltante, precio inconsistente, código inválido, vigencia o bloqueo de promoción.

Los carteles que no pueden imprimirse muestran **Pendiente de corrección**, permanecen rojos con su i y no se suman a los pendientes de impresión. Cuando solo quedan esos productos, la campana general y el resumen del local pasan a verde con **Sin imprimibles pendientes**. No se crean comprobantes de impresión para conseguir ese estado.

Las descripciones, marcas y medidas incompletas se contrastan con la maestra compartida aprobada y, cuando coincide exactamente el producto y la barra, con el último reporte válido. No se inventan precios ni se sustituye una ficha válida por otra sin verificar.

La medida **300MT** del FILM PLÁSTICO INSTITUCIONAL se reconoce correctamente. También se reconocen variantes como M, MTS y METROS.

Si una unidad cuesta lo mismo que el precio normal, se presenta como **precio normal**, sin oferta ni ahorro. Se incorpora una corrección única y respaldada para el caso confirmado de Coca-Cola retornable de 3 L, **LISTA4|432282**, referencia y precio actual **$2.090**. Solo se aplica si el registro todavía coincide con el caso antiguo de referencia $2.050; las cargas oficiales posteriores mantienen su prioridad.

## Cargas de listas y de jueves

La pantalla detecta el tipo del archivo por sus columnas y muestra la pestaña correcta al revisarlo. Distingue **Seleccionado**, **Revisado, falta aplicar** y **Aplicado**, con el archivo vigente y su fecha. Después de aplicar, vuelve a consultar el catálogo para verificar el resultado.

Una lista OCCAM recién aplicada tiene prioridad sobre un reporte de jueves anterior. Una actualización de jueves posterior puede volver a modificar la promoción según las reglas de precio menor o cambio de mecánica. La referencia de precio normal procede de OCCAM.

La revisión muestra por separado los cambios de precios y los de descripción o medida. Rechaza registros duplicados con precios contradictorios, en lugar de tomar silenciosamente el primero. Los duplicados idénticos se omiten e informan.

## Datos existentes y revisión semanal

La actualización utiliza el catálogo guardado en D1. Antes de incorporar las revisiones a la lista, conserva la versión anterior. Al migrar desde V1.6 identifica la última carga aplicada y separa sus cambios del historial de alertas acumulado, manteniendo el archivo original y los comprobantes de impresión correspondientes.

En la comprobación previa de la aplicación operativa se identificó **Reporte_Productos_Destacado - 2026-11-12 Jueves.xlsx**, aplicado el **14/11/2026 a las 19:09:10 de Chile**, con **1.441 productos** y **47 promociones actualizadas** en la pantalla vigente. Esa comprobación fue de consulta; no se reemplazó el reporte de producción.

Se conserva la revisión del mercado **814**, con inicio el **lunes 16/11/2026**, ciclo de 21 días hasta el **domingo 06/12/2026** y siguiente ciclo desde el **lunes 07/12/2026**. Incluye los locales **170, 171, 186, 198, 504, 507, 511, 538, 540, 541, 579 y 622**, más los nuevos locales que Administrador incorpore a ese mercado. Cada local mantiene sus registros independientes. El resumen de revisión semanal continúa en Administrador.

También se conservan el escáner de cámara y foto, Cartelería Manual, búsqueda UPC/EAN, cola compartida, impresión, reportes y controles de bloqueo de promociones.

## Comprobaciones realizadas

- Recuperación de lectura ante HTML 500 temporal y pérdida temporal de conexión.
- Error persistente con mensaje claro y retorno al acceso; JSON incompleto y verificación de acceso sin bucles.
- Sin repetición automática de operaciones de guardado.
- Igualdad de catálogo, precios, validaciones y referencias de impresión antes y después de optimizar.
- Consulta de versión sin reconstrucción de catálogo y con detección de nuevas fichas aprobadas.

- Alertas todavía vigentes después de **20 días** sin reporte nuevo.
- Sustitución de alertas solo al aplicar otro reporte; revisar un archivo no publica.
- Permanencia de precios corregidos, fecha y archivo de origen, y cargas solo de especificaciones.
- Migración desde V1.6 con conservación de la impresión confirmada del último reporte.
- Carga OCCAM completa de **1.775 productos**, con fecha y archivo para todos y dentro del límite de D1.
- i informativa, fallas rojas, resumen verde sin pendientes imprimibles y ausencia de comprobantes falsos.
- Prioridad de listas nuevas sobre jueves anteriores y de una carga de jueves posterior cuando corresponde.
- Revisión del mercado 814, permisos, separación entre impresión y check, historial y ciclo siguiente.
- Flujo real de los scripts de impresión y cola, lectura de códigos de cámara y foto, sintaxis y tipos.

Las pruebas se ejecutaron con bases independientes. La publicación en el Worker operativo queda a cargo del usuario.

## Código para GitHub

La carpeta **codigo-fuente** incluye los recursos de la aplicación, los módulos del backend y el compilador. Para construir el Worker completo:

```sh
node build.cjs
node --check worker-v1.7.5.mjs
```

Para la comprobación de tipos con TypeScript instalado, utiliza `tsc -p tsconfig.worker.json`. Esa configuración comprueba el Worker sin tipos de navegador.

La compilación no descarga dependencias. La optimización de revisión y fechas está en `src/weekly-performance-backend.mjs` y `src/review-market-backend.mjs`. La consulta liviana de versión está en `src/catalog-performance-backend.mjs`. El ciclo de alertas está en `src/alert-lifecycle-backend.mjs`; las validaciones compartidas están en `src/app/specification-core.js`, `src/app/cartel-rules.js` y `src/catalog-validation-backend.mjs`.

Usa `wrangler.toml.example` como referencia conservando el Worker y la base D1 existentes. Si el repositorio tiene un `index.html` raíz que redirige Render a Cloudflare, consérvalo: `src/app/index.html` es la interfaz interna del Worker.

Licencias: **THIRD-PARTY-NOTICES.txt**.
