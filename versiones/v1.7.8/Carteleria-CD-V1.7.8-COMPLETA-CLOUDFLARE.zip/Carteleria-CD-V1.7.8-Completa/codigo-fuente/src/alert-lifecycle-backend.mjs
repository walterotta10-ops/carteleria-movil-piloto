// Las alertas pertenecen al último reporte aplicado. No vencen por días.
// Al incorporar sus precios a OCCAM, reemplazar un reporte no revierte correcciones.
const CYD76_INIT=new WeakMap();
const CYD76_FIELDS=['name','brand','size','upc','category','group','subgroup','from','to'];
function cyd76report(id,kind,filename,appliedAt){return {id,kind,filename,appliedAt};}
function cyd76note(report,before,reason){
 return report.kind==='weekly'?{reportId:report.id,before:{qty:before[0],offer:before[1]},reason}:{reportId:report.id};
}
function cyd76revision(state,row){
 const note=row.lastRevision76,report=state.reportRefs76?.[note?.reportId];
 return report?{...note,kind:report.kind,source:report.filename,at:report.appliedAt}:null;
}
function cyd76annotate(candidate,previous,report,day){
 // Guarda el nombre y la fecha del reporte una sola vez, incluso en listas completas.
 candidate.reportRefs76={...previous.reportRefs76,...candidate.reportRefs76,[report.id]:report};
 const priorRows=new Map(previous.base.map(row=>[CYD53_E.key(row),row])),prior=cyd62prices(previous,day),current=cyd62prices(candidate,day),weekly=new Map(candidate.weekly.map(row=>[row.pn,row]));
 for(const row of candidate.base){
  const key=CYD53_E.key(row),old=priorRows.get(key),before=prior.get(key),after=current.get(key),fields=old?CYD76_FIELDS.filter(field=>String(row[field]||'')!==String(old[field]||'')):CYD76_FIELDS;
  const changed=before&&!cyd62samePrice(before,after);
  if(changed||fields.length){
   const reason=report.kind==='weekly'?CYD53_E.weeklyDecision(row,weekly.get(row.pn),day).reason:report.kind==='correction'?'Corrección de precio publicada':'Actualización de lista OCCAM';
   row.lastRevision76=cyd76note(report,before||after,reason);
  }else if(old?.lastRevision76)row.lastRevision76=old.lastRevision76;
 }
}
function cyd76incorporate(state,day){
 const prices=cyd62prices(state,day);
 for(const row of state.base){const p=prices.get(CYD53_E.key(row));row.qty=p[0];row.offer=p[1];}
 const used=new Set([state.alertReport76?.id,...state.base.map(row=>row.lastRevision76?.reportId)]);
 state.reportRefs76=Object.fromEntries(Object.entries(state.reportRefs76||{}).filter(([id])=>used.has(id)));
}
function cyd76repairBase(state,day){
 const products=new Map(cyd53catalog(state,day).filter(p=>p.occamKey).map(p=>[p.occamKey,p]));
 for(const row of state.base){
  const p=products.get(CYD53_E.key(row)),recovered=p?.specificationCheck75?.recovered||[];
  for(const [field,label] of [['name','descripción'],['brand','marca'],['size','medida']])if(recovered.includes(label))row[field]=p[field];
 }
}
function cyd76finalize(candidate,previous,draft,now){
 const day=cyd53day(),report=cyd76report(draft.id,draft.kind,draft.filename,now);
 const specifications=CYD75_SPECIFICATIONS.get(previous);if(specifications)CYD75_SPECIFICATIONS.set(candidate,specifications);
 cyd76repairBase(candidate,day);
 // Una corrección individual conserva el resto de alertas del reporte vigente.
 const history=draft.kind==='correction'?(previous.priceChanges||{}):{};
 candidate.priceChanges=cyd62changes(cyd62prices(candidate,day),cyd62prices(previous,day),history);
 if(draft.kind!=='correction')candidate.alertReport76=report;
 else candidate.alertReport76=previous.alertReport76||report;
 cyd76annotate(candidate,previous,report,day);
 for(const row of [...candidate.base,...candidate.weekly])if(row.loadedRevision75===draft.base_revision+1)row.loadedAt75=now;
 if(draft.kind==='correction')for(const change of JSON.parse(draft.preview).report.changes||[]){
  const correction=candidate.corrections?.[change.key];if(correction)correction.updatedAt=now;
 }
 cyd76incorporate(candidate,day);candidate.loadedAt=now;
}
async function cyd76lifecycle(env){
 if(!CYD76_INIT.has(env.DB))CYD76_INIT.set(env.DB,(async()=>{
  for(let attempt=0;attempt<3;attempt++){
   const row=await env.DB.prepare('SELECT revision,data,updated_at,last_import FROM carteleria_promos53 WHERE id=1').first(),state=JSON.parse(row.data);
   if(state.alertReport76)return;
   const latest=await env.DB.prepare("SELECT * FROM carteleria_imports53 WHERE state='applied' AND kind IN ('occam','weekly') ORDER BY committed_at DESC,base_revision DESC LIMIT 1").first();
   const history=await cyd62history({...row,state},env),publication=latest?.committed_at||state.loadedAt||row.updated_at,day=H(new Date(publication));
   if(latest){
    const snapshot=await env.DB.prepare('SELECT data FROM carteleria_promo_versions53 WHERE revision=?').bind(latest.base_revision).first(),after=JSON.parse(latest.preview).candidate,before=snapshot?JSON.parse(snapshot.data):state;
    const report=cyd76report(latest.id,latest.kind,latest.filename,latest.committed_at);
    state.alertReport76=report;state.priceChanges=cyd62changes(cyd62prices(after,day),cyd62prices(before,day));
    cyd76annotate(after,before,report,day);
    state.reportRefs76={...state.reportRefs76,...after.reportRefs76};
    const notes=new Map(after.base.filter(r=>r.lastRevision76).map(r=>[CYD53_E.key(r),r.lastRevision76]));
    for(const base of state.base)if(notes.has(CYD53_E.key(base)))base.lastRevision76=notes.get(CYD53_E.key(base));
    // Las correcciones individuales posteriores al reporte también siguen vigentes.
    const corrections=await env.DB.prepare("SELECT * FROM carteleria_imports53 WHERE state='applied' AND kind='correction' AND base_revision>? ORDER BY base_revision").bind(latest.base_revision).all();
    for(const correction of corrections.results){
     const date=H(new Date(correction.committed_at)),draft=JSON.parse(correction.preview),previous=await env.DB.prepare('SELECT data FROM carteleria_promo_versions53 WHERE revision=?').bind(correction.base_revision).first();
     if(!previous)continue;
     const old=JSON.parse(previous.data),report=cyd76report(correction.id,correction.kind,correction.filename,correction.committed_at);
     state.priceChanges=cyd62changes(cyd62prices(draft.candidate,date),cyd62prices(old,date),state.priceChanges);cyd76annotate(draft.candidate,old,report,date);
     state.reportRefs76={...state.reportRefs76,...draft.candidate.reportRefs76};
     for(const change of draft.report.changes||[]){const base=state.base.find(r=>CYD53_E.key(r)===change.key),note=draft.candidate.base.find(r=>CYD53_E.key(r)===change.key)?.lastRevision76;if(base&&note)base.lastRevision76=note;}
    }
   }else{state.alertReport76=cyd76report(row.last_import||'initial-v53','initial',state.source?.weekly||state.source?.occam||'Base incorporada',publication);state.priceChanges=history;}
   // Usa la fecha real del reporte, sin generar una carga ni una fecha nueva.
   cyd76incorporate(state,day);
   const now=new Date().toISOString();
   await env.DB.batch([
    env.DB.prepare('INSERT OR IGNORE INTO carteleria_promo_versions53 (revision,data,saved_at) SELECT revision,data,updated_at FROM carteleria_promos53 WHERE id=1'),
    env.DB.prepare('UPDATE carteleria_promos53 SET data=?,revision=revision+1,updated_at=? WHERE id=1 AND revision=?').bind(JSON.stringify(state),now,row.revision)
   ]);
   const saved=await env.DB.prepare('SELECT data FROM carteleria_promos53 WHERE id=1').first();if(JSON.parse(saved.data).alertReport76)return;
  }
  cyd53error('El catálogo cambió durante la incorporación de las revisiones. Actualiza y vuelve a intentarlo.',409);
 })().catch(error=>{CYD76_INIT.delete(env.DB);throw error;}));
 await CYD76_INIT.get(env.DB);
}
