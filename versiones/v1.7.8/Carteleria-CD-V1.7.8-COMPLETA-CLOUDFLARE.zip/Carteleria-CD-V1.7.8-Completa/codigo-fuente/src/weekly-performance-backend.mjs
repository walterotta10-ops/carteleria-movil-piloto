// Conversión de fechas compartida por uso, calendario, revisión e impresión.
// Caché acotada por instante: conserva la fecha exacta de Chile, incluidos cambios de hora.
let CYD79_FORMATTER;
const CYD79_DAYS=new Map(),CYD79_WEEKLY=new WeakMap();
function cyd79day(value){
 const date=value instanceof Date?value:new Date(value),key=date.getTime(),cached=CYD79_DAYS.get(key);
 if(cached)return cached;
 if(!CYD79_FORMATTER)CYD79_FORMATTER=new Intl.DateTimeFormat('en-GB',{timeZone:'America/Santiago',year:'numeric',month:'2-digit',day:'2-digit'});
 const parts=Object.fromEntries(CYD79_FORMATTER.formatToParts(date).map(p=>[p.type,p.value])),day=parts.year+'-'+parts.month+'-'+parts.day;
 if(CYD79_DAYS.size>=512)CYD79_DAYS.delete(CYD79_DAYS.keys().next().value);
 CYD79_DAYS.set(key,day);return day;
}
function cyd79planLocals(env){
 const locals=cyd69locals(env),profile=env.principal?.profile;
 return profile?.role==='store'&&locals.includes(profile.code)?[profile.code]:locals;
}
async function cyd79prime(env,current,catalog){
 const profile=env.principal?.profile;
 if(profile?.role!=='master'&&!(profile?.role==='store'&&env.roster.localMarket[profile.code]==='814'))return;
 const day=cyd53day(),key=current.revision+'|'+(current.specificationRevision75||0)+'|'+day,prior=CYD79_WEEKLY.get(env.DB);
 if(prior?.key===key)return prior.promise;
 const entry={key,promise:null};
 entry.promise=cyd69groups(catalog,day).then(groups=>({current,groups})).catch(error=>{if(CYD79_WEEKLY.get(env.DB)===entry)CYD79_WEEKLY.delete(env.DB);throw error;});
 CYD79_WEEKLY.set(env.DB,entry);return entry.promise;
}
async function cyd79weekly(env){
 // Precios y fichas aprobadas invalidan juntos esta única entrada por base de datos.
 // Los checks y comprobantes del local se siguen leyendo desde D1 en cada consulta.
 const meta=await cyd78version(env),key=meta.revision+'|'+meta.specificationRevision+'|'+meta.day,existing=CYD79_WEEKLY.get(env.DB);
 if(existing?.key===key)return existing.promise;
 const entry={key,promise:null};
 entry.promise=(async()=>{
  const prepared=await cyd80prepared(env,meta),current=prepared.current,groups=await cyd69groups(prepared.catalog,meta.day);
  entry.key=current.revision+'|'+(current.specificationRevision75||0)+'|'+meta.day;
  return {current,groups};
 })().catch(error=>{if(CYD79_WEEKLY.get(env.DB)===entry)CYD79_WEEKLY.delete(env.DB);throw error;});
 CYD79_WEEKLY.set(env.DB,entry);return entry.promise;
}
