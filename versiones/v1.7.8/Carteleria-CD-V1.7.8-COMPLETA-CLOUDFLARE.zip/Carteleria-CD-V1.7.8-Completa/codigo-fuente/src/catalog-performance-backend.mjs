// Consultar si cambió el catálogo no necesita reconstruir sus productos ni la maestra.
async function cyd78version(env){
 await cyd53init(env);await cyd75priceReference(env);await cyd76lifecycle(env);await cyd56init(env);
 const [meta,printRevision]=await Promise.all([
  env.DB.batch([
   env.DB.prepare('SELECT revision FROM carteleria_promos53 WHERE id=1'),
   env.DB.prepare('SELECT revision FROM carteleria_manual_meta56 WHERE id=1')
  ]),
  cyd68revision(env)
 ]);
 return {ok:true,revision:meta[0].results[0]?.revision||1,day:cyd53day(),specificationRevision:meta[1].results[0]?.revision||0,printRevision};
}
