// Datos comunes por revisión; recibos y permisos siempre pertenecen al local actual.
// Una entrada por DB y dos respuestas con recibos: memoria acotada, sin caché de sesiones.
const CYD80_CATALOG=new WeakMap(),CYD80_SPECIFICATIONS=new WeakMap(),CYD80_LOADING=new WeakMap();
const cyd80key=(revision,specification,day)=>revision+'|'+specification+'|'+day;
async function cyd80specifications(env){
 await cyd56init(env);
 const revision=(await env.DB.prepare('SELECT revision FROM carteleria_manual_meta56 WHERE id=1').first())?.revision||0;
 const prior=CYD80_SPECIFICATIONS.get(env.DB);if(prior?.revision===revision)return prior.promise;
 const entry={revision,promise:null};
 entry.promise=(async()=>{
  const [rows,meta]=await env.DB.batch([
   env.DB.prepare('SELECT item,upc,descripcion,marca,unidad,updated_at FROM carteleria_products56 ORDER BY item,upc'),
   env.DB.prepare('SELECT revision FROM carteleria_manual_meta56 WHERE id=1')
  ]);
  entry.revision=meta.results[0]?.revision||0;
  return {lookup:CYD56_CORE.index(rows.results),revision:entry.revision,checkedAt:new Date().toISOString()};
 })().catch(error=>{if(CYD80_SPECIFICATIONS.get(env.DB)===entry)CYD80_SPECIFICATIONS.delete(env.DB);throw error;});
 CYD80_SPECIFICATIONS.set(env.DB,entry);return entry.promise;
}
async function cyd80base(current,env){
 const day=cyd53day(),key=cyd80key(current.revision,current.specificationRevision75||0,day),prior=CYD80_CATALOG.get(env.DB);
 if(prior?.key===key)return prior.promise;
 const entry={key,promise:null,unprinted:null,printed:new Map()};
 entry.promise=(async()=>{
  const catalog=await cyd62catalog(current,env);
  for(const p of catalog){const reasons=CYD75_PRINT_RULES.validate(p);p.printability75={printable:reasons.length===0,reasons};}
  await Promise.all(catalog.filter(p=>p.priceChange).map(async p=>{
   const c=p.priceChange,token=await cyd54sha(JSON.stringify([p.occamKey,p.code,p.barcode,current.state.priceChangeIds?.[p.occamKey]||'legacy',c.before.qty,c.before.offer,c.before.regular,c.after.qty,c.after.offer,c.after.regular]));
   p.priceChange={...c,token,family:cyd68family(p.occamList),printedAt:null,printable:p.printability75.printable,reasons:p.printability75.reasons};
  }));
  return {catalog,current,revision:current.revision,updatedAt:current.updated_at,day,specificationRevision:current.specificationRevision75||0,entry};
 })().catch(error=>{if(CYD80_CATALOG.get(env.DB)===entry)CYD80_CATALOG.delete(env.DB);throw error;});
 CYD80_CATALOG.set(env.DB,entry);return entry.promise;
}
async function cyd80receipts(catalog,env){
 if(env.principal?.profile.role!=='store')return {catalog,hasReceipts:false,receiptKey:''};
 await cyd68init(env);const tokens=catalog.filter(p=>p.priceChange).map(p=>p.priceChange.token);
 const receipts=tokens.length?(await env.DB.prepare('SELECT occam_key,fingerprint,printed_at FROM carteleria_alert_prints68 WHERE local=? AND fingerprint IN (SELECT value FROM json_each(?))').bind(env.principal.profile.code,JSON.stringify(tokens)).all()).results:[];
 if(!receipts.length)return {catalog,hasReceipts:false,receiptKey:''};
 const dates=new Map(receipts.map(r=>[r.occam_key+'|'+r.fingerprint,r.printed_at]));
 return {catalog:catalog.map(p=>p.priceChange?{...p,priceChange:{...p.priceChange,printedAt:dates.get(p.occamKey+'|'+p.priceChange.token)||null}}:p),hasReceipts:true,receiptKey:JSON.stringify(receipts)};
}
async function cyd80catalog(current,env,includeBlocked=false){
 const base=await cyd80base(current,env),catalog=base.catalog.filter(p=>includeBlocked||!p.promotionBlocked);
 return (await cyd80receipts(catalog,env)).catalog;
}
async function cyd80prepared(env,meta){
 const key=cyd80key(meta.revision,meta.specificationRevision,meta.day),prior=CYD80_CATALOG.get(env.DB);
 if(prior?.key===key)return prior.promise;
 const pending=CYD80_LOADING.get(env.DB);if(pending?.key===key)return pending.promise;
 const entry={key,promise:null};
 entry.promise=(async()=>cyd80base(await cyd53state(env),env))().finally(()=>{if(CYD80_LOADING.get(env.DB)===entry)CYD80_LOADING.delete(env.DB);});
 CYD80_LOADING.set(env.DB,entry);return entry.promise;
}
async function cyd80catalogResponse(env){
 const meta=await cyd78version(env),base=await cyd80prepared(env,meta);
 const visible=base.catalog.filter(p=>!p.promotionBlocked),{catalog,hasReceipts,receiptKey:receipts}=await cyd80receipts(visible,env);
 // El estado local se consulta en D1 incluso cuando se reutiliza el JSON común.
 const entry=base.entry,receiptKey=env.principal.profile.code+'|'+receipts;
 let body=hasReceipts?entry.printed.get(receiptKey):entry.unprinted;
 if(!body){
  body=cyd54enc.encode(JSON.stringify({ok:true,revision:base.revision,updatedAt:base.updatedAt,day:base.day,specificationRevision:base.specificationRevision,catalog,layout:cyd53layout(catalog)}));
  if(hasReceipts){if(entry.printed.size>=2)entry.printed.delete(entry.printed.keys().next().value);entry.printed.set(receiptKey,body);}else entry.unprinted=body;
 }
 return new Response(body,{headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'}});
}
