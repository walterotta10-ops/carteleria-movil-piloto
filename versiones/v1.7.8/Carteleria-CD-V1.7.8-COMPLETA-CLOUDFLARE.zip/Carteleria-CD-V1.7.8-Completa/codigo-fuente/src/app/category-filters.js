(function(g){
 'use strict';
 const text=v=>String(v??'').trim(),norm=v=>text(v).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toUpperCase(),esc=v=>text(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const number=v=>Number(v).toLocaleString('es-CL'),money=v=>Number.isFinite(Number(v))?'$'+Math.round(Number(v)).toLocaleString('es-CL'):'Precio por revisar';
 const groups={red:new Set(['EDLP','EDLPEXTENSION','EDLPMMPP']),yellow:new Set(['BODEGAZO3','LISTA4','TRAFICO3'])};
 function listOf(value){return typeof value==='string'?value:value?.list||value?.occamList||value?.lista||'';}
 function classify(value){const list=norm(listOf(value)).replace(/[^A-Z0-9]/g,'');return groups.red.has(list)?'red':groups.yellow.has(list)?'yellow':'other';}
 function matches(value,type){return !type||type==='all'||classify(value)===type;}
 function records(catalog){return (catalog||[]).filter(p=>p.occamKey).map(p=>{
  const department=text(p.subgrupo)||'Sin departamento',category=[text(p.categoryId),text(p.categoryName)].filter(Boolean).join(' ')||'Sin categoría',list=text(p.occamList),item=text(p.code),upc=text(p.barcode);
  return {key:p.occamKey,department,category,list,item,upc,name:text(p.name),brand:text(p.brand),size:text(p.size),type:classify(list),sign:p,search:norm([p.name,p.brand,p.size,item,upc,p.sourceProductNbr,department,category,list].join(' '))};
 });}
 function filter(rows,state){const tokens=norm(state.query).split(/\s+/).filter(Boolean);return rows.filter(r=>matches(r,state.type)&&(state.department==='all'||!state.department||r.department===state.department)&&(state.category==='all'||!state.category||r.category===state.category)&&(state.list==='all'||!state.list||r.list===state.list)&&tokens.every(t=>r.search.includes(t)));}
 const collator=new Intl.Collator('es-CL',{numeric:true,sensitivity:'base'});
 const categoryName=value=>text(value).replace(/^\d+\s*(?:[-–·:]\s*)?(?=[^\d\s])/,'');
 const compareCategories=(a,b)=>collator.compare(categoryName(a),categoryName(b))||collator.compare(text(a),text(b));
 function orderProducts(rows,mode='department'){
  // Ordena una copia. Las claves de selección y los datos del catálogo no cambian.
  const entries=rows.map(row=>{
   const p=row.sign||row;
   const product=[row.name||p.name||p.nombre,row.brand||p.brand||p.marca,row.size||p.size||p.contenido,listOf(row)||listOf(p),row.item||p.code||p.codigo,row.upc||p.barcode,row.key||p.occamKey||p.layoutId].map(text);
   return {row,values:mode==='name'?product:[text(row.department||p.subgrupo),categoryName(row.category||p.categoria||[p.categoryId,p.categoryName].filter(Boolean).join(' ')),...product]};
  });
  entries.sort((a,b)=>{
   for(let i=0;i<a.values.length;i++){const compared=collator.compare(a.values[i],b.values[i]);if(compared)return compared;}
   return 0;
  });
  return entries.map(entry=>entry.row);
 }
 function preferredOrder(){try{const saved=localStorage.getItem('carteleria.category-sort.v67');return ['department','name'].includes(saved)?saved:'department';}catch{return 'department';}}
 function counts(rows){return rows.reduce((out,r)=>{out[classify(r)]++;out.all++;return out;},{all:0,red:0,yellow:0,other:0});}
 const bell='<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9m-8 12a2 2 0 0 0 4 0"/></svg>';
 const familyName={red:'EDLP',yellow:'Lista Promocional'};
 function promotion(row){
  const p=row.sign||row;
  const key=row.key||p.occamKey||p.layoutId;
  return {key,name:p.name||p.nombre||'Sin descripción',list:listOf(row)||listOf(p),item:p.code||p.codigo,upc:p.barcode||p.upc,sign:p,change:g.CYD68_ALERTS?.change(key,p.priceChange)||null};
 }
 function priceBell(row){
  const p=promotion(row);
  if(!p.change)return '';
  return `<button type="button" class="cyd62-bell ${p.change.printedAt&&p.change.printable!==false?'is-printed':'is-ringing'}" data-cyd62-item="${esc(p.key)}" data-cyd68-name="Ver cambio de precio de ${esc(p.name)}" aria-label="${p.change.printable===false?'Pendiente de corrección':p.change.printedAt?'Impresa':'Pendiente'}. Ver cambio de precio de ${esc(p.name)}" title="${esc(g.CYD68_ALERTS.status(p.change))}">${bell}</button>`;
 }
 function printState(p){return p.change?'<div class="cyd75-alert-state"><span class="cyd68-print-state '+(p.change.printedAt&&p.change.printable!==false?'is-printed':'')+'" data-cyd68-status-key="'+esc(p.key)+'">'+esc(g.CYD68_ALERTS.status(p.change))+'</span><button type="button" class="cyd75-info" data-cyd75-info="'+esc(p.key)+'" aria-label="Información de '+esc(p.name)+'" title="Ver motivo y datos del cartel"><span aria-hidden="true">i</span></button></div>':'';}
 function priceSummary(change){
  const {before,after}=change;
  const offer=p=>p.qty+' × '+money(p.offer);
  const amount=p=>p.regular>0?money(p.regular):'Sin registro';
  const normalChanged=before.regular!==after.regular;
  return `<dl class="cyd62-comparison"><div><dt>Antes</dt><dd>${offer(before)}</dd>${normalChanged?'<small>Precio normal '+amount(before)+'</small>':''}</div><div><dt>Ahora</dt><dd>${offer(after)}</dd>${normalChanged?'<small>Precio normal '+amount(after)+'</small>':''}</div></dl>`+(after.qty===1&&after.regular===after.offer?'<p class="cyd75-normal">Precio normal · Sin oferta ni ahorro.</p>':'');
 }
 function revisionNote(sign){
  const revision=sign.priceRevision76;if(!revision?.at)return '';
  const date=new Date(revision.at);if(!Number.isFinite(date.getTime()))return '';
  return '<span class="cyd76-revision"><strong>Corregido el '+esc(date.toLocaleString('es-CL',{timeZone:'America/Santiago',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit'}))+'</strong><span>'+esc(revision.source||'Revisión aplicada')+'</span></span>';
 }
 function information(sign,returnTo){
  const issues=sign.printability75?.reasons||g.CARTELERIA_RULES.validate(sign),change=sign.reportInformation75?sign.priceChange:g.CYD68_ALERTS.change(sign.occamKey,sign.priceChange);
  const price=p=>(Number(p.qty)>1?number(p.qty)+' × ':'')+money(p.offer),normal=value=>Number(value)>0?money(value):'No informado',details=[];
  if(change?.before&&change?.after){
   const {before,after}=change;
   if(before.qty!==after.qty||before.offer!==after.offer)details.push((before.qty>1||after.qty>1?'Promoción: ':'Precio: ')+price(before)+' → '+price(after));
   if(before.regular!==after.regular)details.push('Precio normal: '+normal(before.regular)+' → '+normal(after.regular));
  }
  if(!details.length)details.push('Precio actual: '+price({qty:sign.qty,offer:sign.offer}));
  function reason(message){
   if(['Falta tamaño','Unidad o cantidad de medida sin verificar'].includes(message))return sign.size?'Medida no válida: «'+text(sign.size)+'».':'Falta una medida válida.';
   if(['Falta modaPrice válido','Precio antes OCCAM no válido'].includes(message))return 'Falta un precio normal válido.';
   if(message==='Falta precio de oferta válido')return 'Falta un precio actual válido.';
   if(message==='Oferta mayor al precio regular conjunto: verificar')return 'El precio '+money(sign.offer)+' supera el precio normal '+(Number(sign.qty)>1?'de '+number(sign.qty)+' unidades ':'')+'('+money(Number(sign.unit)*Number(sign.qty))+').';
   if(['Barra sin EAN-13 verificable','Código EAN-13 inválido','Falta código de barras'].includes(message))return 'Código de barras no válido.';
   if(['Vigencia no verificada','Falta vigencia verificable de la misma campaña'].includes(message))return 'Fechas de vigencia no válidas.';
   if(message==='Precio de referencia distinto al response')return 'El precio normal no coincide con el reporte.';
   if(message==='Oferta distinta al response')return 'El precio actual no coincide con el reporte.';
   if(message.startsWith('Promoción bloqueada por Administrador'))return 'Promoción bloqueada'+(sign.promotionBlock?.reason?': '+sign.promotionBlock.reason:'.');
   return message;
  }
  const failures=[...new Set(issues.map(reason))];
  const body='<div class="cyd75-information">'+details.map(detail=>'<p class="cyd77-change">'+esc(detail)+'</p>').join('')+(failures.length?'<div class="cyd77-blockers"><strong>No se puede imprimir</strong><ul>'+failures.map(failure=>'<li>'+esc(failure)+'</li>').join('')+'</ul></div>':'')+'</div>';
  return showDialog('Detalle del cambio',text(sign.name)||'Producto',body,returnTo,{preservePrevious:true,closeLabel:'Volver',compact:true});
 }
 function bindInformation(dialog,rows,actions=null,onFresh=null){
  dialog.addEventListener('click',async event=>{
   const button=event.target.closest('[data-cyd75-info]');if(!button)return;button.disabled=true;
   try{if(actions?.refresh)await actions.refresh();const current=actions?.records?.()||rows;onFresh?.(current);const record=current.find(row=>(row.key||row.occamKey)===button.dataset.cyd75Info);if(!record)throw new Error('El producto ya no está en el catálogo vigente. Actualiza las alertas.');information(record.sign||record,button);}
   catch(error){showDialog('Información del cartel','No se pudo verificar la información más reciente.','<p>'+esc(error.message)+'</p>',button,{preservePrevious:true,closeLabel:'Volver a las alertas'});}
   finally{button.disabled=false;}
  });
 }
 function changedRows(rows,type){return rows.filter(r=>matches(r,type)&&promotion(r).change);}

 // V1.7.8: local-only current-price print counts; no extra calls while screen is closed.
 const progress={local:'',counts:null,loaded:0,pending:null,error:false,generation:0};
 const localProfile=()=>g.CYD54_ACCESS?.profile?.role==='store'?String(g.CYD54_ACCESS.profile.code):'';
 const fingerprint=p=>JSON.stringify([Number(p.qty),Number(p.offer),Number(p.unit)]);
 function resetProgress(local){progress.local=local;progress.counts=null;progress.loaded=0;progress.error=false;progress.pending=null;progress.generation++;}
 function currentCount(p){return progress.counts?.get(p.occamKey+'|'+fingerprint(p))||0;}
 function printable(p){return !p.promotionBlocked&&p.printability75?.printable!==false;}
 function paintProgress(){
  const local=localProfile();if(!local||progress.local!==local)return;
  const catalog=g.CARTELERIA_CATALOG||[], map=new Map(catalog.filter(p=>p.occamKey).map(p=>[p.occamKey,p]));
  for(const el of document.querySelectorAll('[data-cyd82-print]')){
   const p=map.get(el.dataset.cyd82Print);let label='Consultando…',state='loading';
   if(!p){label='Sin datos';state='unknown';}
   else if(progress.error||!progress.counts){label=progress.error?'Sin verificar':'Consultando…';state='unknown';}
   else if(!printable(p)){label='NO IMPRESO · Por corregir';state='pending';}
   else {const c=currentCount(p);label=c?'IMPRESO · '+number(c):'NO IMPRESO';state=c?'printed':'pending';}
   el.textContent=label;el.dataset.state=state;
  }
  for(const el of document.querySelectorAll('[data-cyd82-family]')){
   const products=catalog.filter(p=>p.occamKey&&classify(p)===el.dataset.cyd82Family&&!p.promotionBlocked), valid=products.filter(printable), total=valid.length, excluded=products.length-total;
   if(progress.error||!progress.counts){el.textContent='% de impresión: '+(progress.error?'Sin verificar':'Consultando…');el.dataset.state='unknown';continue;}
   const printed=valid.filter(p=>currentCount(p)>0).length,pct=total?new Intl.NumberFormat('es-CL',{maximumFractionDigits:1}).format(100*printed/total)+'%':'—';
   el.textContent='% de impresión: '+pct+' · '+number(printed)+'/'+number(total)+(excluded?' · '+number(excluded)+' por corregir':'');el.dataset.state=printed===total&&total?'printed':printed?'partial':'pending';
  }
 }
 async function refreshProgress(force=false){
  const local=localProfile();if(!local)return;if(progress.local!==local)resetProgress(local);
  if(progress.pending){if(!force)return progress.pending;await progress.pending;if(progress.local!==local||localProfile()!==local)return;return refreshProgress(true);}
  if(!force&&progress.loaded&&Date.now()-progress.loaded<45000){paintProgress();return;}
  const generation=progress.generation;
  progress.pending=(async()=>{try{const data=await g.CYD54_ACCESS.getJSON('/api/carteleria/impresion/local');if(localProfile()!==local||progress.generation!==generation)return;
   if(data.local!==local||!Array.isArray(data.receipts))throw new Error('Datos de impresión no válidos');
   progress.counts=new Map(data.receipts.map(r=>[r.key+'|'+r.fingerprint,Number(r.count)]));progress.error=false;progress.loaded=Date.now();
  }catch(e){if(progress.generation===generation){progress.error=true;progress.loaded=Date.now();}}finally{if(progress.generation===generation){progress.pending=null;paintProgress();}}})();
  return progress.pending;
 }
 function scheduleProgress(){if(!localProfile())return;queueMicrotask(()=>{if(document.querySelector('[data-cyd82-family],[data-cyd82-print]')){paintProgress();void refreshProgress();}});}
 function printMark(p){if(!localProfile()||!p?.occamKey)return '';return '<strong class="cyd82-print" data-cyd82-print="'+esc(p.occamKey)+'" data-state="loading">Consultando…</strong>';}
 function familyMark(type){return localProfile()?'<span class="cyd82-family" data-cyd82-family="'+esc(type)+'" data-state="loading">% de impresión: Consultando…</span>':'';}
 if(typeof g.addEventListener==='function'){
  g.addEventListener('cyd61-profile',()=>resetProgress(localProfile()));
  g.addEventListener('focus',()=>{if(document.querySelector('[data-cyd82-family],[data-cyd82-print]'))void refreshProgress(true);});
 }
 function picker(rows,selected='all',attribute='data-cyd55-type'){
  if(!/^data-[a-z0-9-]+$/.test(attribute))throw new Error('Selector de listas no válido.');const c=counts(rows);scheduleProgress();
  const card=(type,title,tag,lists,art)=>{
   const changes=changedRows(rows,type).map(promotion),changed=changes.length,available=changes.filter(p=>p.change.printable!==false),unprintable=changed-available.length,printed=available.filter(p=>p.change.printedAt).length,pending=available.length-printed,done=changed>0&&pending===0;
   return `<div class="cyd62-list-option"><button type="button" class="cyd55-list-choice ${type}${selected===type?' is-selected':''}" ${attribute}="${type}" aria-pressed="${selected===type}" aria-label="${tag}: ${title}"><span class="cyd55-list-title">${title}</span><span class="cyd55-list-art ${type}" aria-hidden="true">${art}</span><span class="cyd55-list-bottom"><strong>${tag}</strong><b>${number(c[type])} productos</b></span>${familyMark(type)}<small>${lists}</small></button><button type="button" class="cyd62-bell cyd62-list-bell ${done?'is-printed':pending?'is-ringing':'is-empty'}" data-cyd62-family="${type}" aria-label="${esc(title)}: ${number(pending)} pendientes, ${number(printed)} impresos"><span>${bell}<span data-cyd68-bell-label>${done?(unprintable?'Sin imprimibles pendientes':'Cambios impresos'):'Cambios de precio'}</span><small data-cyd68-bell-summary>${changed?number(printed)+' impresos · '+number(pending)+' pendientes'+(unprintable?' · '+number(unprintable)+' por corregir':''):'Sin cambios'}</small></span><strong>${number(done?printed:pending)}</strong></button></div>`;
  };
  return `<section class="cyd55-list-picker" aria-label="Selecciona la lista"><div class="cyd55-picker-head"><h2>Selecciona la lista</h2><button type="button" class="cyd55-all-lists${selected==='all'?' is-selected':''}" ${attribute}="all" aria-pressed="${selected==='all'}">Todas las listas · ${number(c.all)}</button></div><div class="cyd55-list-options">${card('red','EDLP','Cartel rojo','EDLP · EDLP Extensión · EDLP MMPP','<b>BARATO</b><em>todos los días</em>')}${card('yellow','Lista Promocional','Cartel amarillo','Bodegazo 3 · Lista 4 · Tráfico 3','<em>Ahora más</em><b>BARATO</b>')}</div></section>`;
 }
 let currentPreview=null;
 function showDialog(title,subtitle,body,returnTo,options={}){
  const previous=options.preservePrevious?currentPreview:null;
  if(previous)previous.hidden=true;else currentPreview?.remove();
  const panel=document.createElement('div');currentPreview=panel;panel.className='cyd55-preview'+(options.compact?' cyd77-precise':'');
  panel.innerHTML='<section role="dialog" aria-modal="true" aria-label="'+esc(title)+'"><header><div><h2>'+esc(title)+'</h2><p>'+esc(subtitle)+'</p></div><button class="btn ghost" type="button">'+esc(options.closeLabel||'Cerrar')+'</button></header>'+body+'</section>';
  document.body.appendChild(panel);
  const button=panel.querySelector('button');
  const close=()=>{panel.remove();if(currentPreview===panel)currentPreview=previous;if(previous)previous.hidden=false;returnTo?.focus();};
  button.onclick=close;button.focus();
  panel.addEventListener('keydown',event=>{
   if(event.key==='Escape'){event.preventDefault();event.stopPropagation();close();}
   if(event.key==='Tab'){
    const controls=[...panel.querySelectorAll('button:not(:disabled),input:not(:disabled),select:not(:disabled),a[href]')].filter(el=>!el.hidden);
    const first=controls[0],last=controls[controls.length-1];
    if(event.shiftKey&&document.activeElement===first){event.preventDefault();last?.focus();}
    else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first?.focus();}
   }
  });
  return panel;
 }
 function isMobileDevice(){
  return navigator.userAgentData?.mobile===true||/Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent)||(navigator.maxTouchPoints>1&&/Macintosh/.test(navigator.userAgent));
 }
 function pcOnlyNotice(returnTo=document.activeElement){
  return showDialog('Modalidad solo PC','Tu móvil y el PC trabajan con la misma cola de impresión.',
   '<ol class="cyd64-print-steps"><li><strong>En el móvil · captura en sala de ventas</strong><p>Selecciona los carteles que necesitas y envíalos a la cola de impresión del local. Puedes seguir revisando y ajustando esa cola desde tu celular.</p></li><li><strong>En el PC · imprime los carteles</strong><p>Abre la app con el mismo local y presiona <b>Imprimir cola de impresión</b>. Desde el PC se enlaza la selección con la impresora.</p></li></ol>',returnTo,{preservePrevious:true,closeLabel:'Volver a la pantalla anterior'});
 }
 function showPreview(sign,renderSign,returnTo){
  const subtitle=[sign.occamList||sign.campaignName,sign.code?'Ítem '+sign.code:sign.barcode?'UPC '+sign.barcode:''].filter(Boolean).join(' · ');
  const change=sign.priceChange?'<div class="cyd62-preview-change"><strong>'+bell+' Cambio de precio</strong>'+priceSummary(sign.priceChange)+'</div>':'';
  return showDialog(sign.name||'Cartel',subtitle,change+revisionNote(sign)+'<div class="preview-card cyd55-preview-art">'+renderSign(sign)+'</div>',returnTo);
 }
 function bindPriceChanges(host,rows,actions=null){
  const byKey=new Map(rows.map(r=>{const p=promotion(r);return [p.key,p];}));
  for(const button of host.querySelectorAll('[data-cyd62-item]'))button.onclick=()=>{
   const previous=byKey.get(button.dataset.cyd62Item),p=previous?{...previous,change:g.CYD68_ALERTS.change(previous.key,previous.change)}:null;
   if(!p?.change)return;
   const dialog=showDialog(p.name,[p.list,p.item?'Ítem '+p.item:''].filter(Boolean).join(' · '),printState(p)+priceSummary(p.change),button);bindInformation(dialog,rows,actions);
  };
  for(const button of host.querySelectorAll('[data-cyd62-family]'))button.onclick=()=>{
   const type=button.dataset.cyd62Family,items=changedRows(rows,type).map(promotion).sort((a,b)=>a.name.localeCompare(b.name,'es-CL'));
   const selectable=Boolean(actions),selected=new Set();
   const records=new Map((actions?.records?.()||[]).map(row=>[row.key,row]));
   const available=items.filter(item=>{const record=records.get(item.key);return record&&g.CARTELERIA_RULES.validate(record.sign).length===0;});
   const ready=new Set(available.map(item=>item.key));
   const controls=selectable&&items.length?'<div class="cyd64-change-tools"><label><input type="checkbox" data-cyd64-all '+(ready.size?'':'disabled')+'> Seleccionar todos los cambios ('+number(ready.size)+')</label><small>Incluye toda la lista de cambios de esta familia.</small></div>':'';
   const body=items.length?controls+'<ul class="cyd62-change-list">'+items.map(p=>'<li>'+(selectable?'<label class="cyd64-change-select"><input type="checkbox" data-cyd64-change="'+esc(p.key)+'" aria-label="Seleccionar '+esc(p.name)+'" '+(ready.has(p.key)?'':'disabled')+'><strong>'+esc(p.name)+'</strong></label>':'<strong>'+esc(p.name)+'</strong>')+'<small>'+esc([p.list,p.item?'Ítem '+p.item:p.upc?'UPC '+p.upc:''].filter(Boolean).join(' · '))+'</small>'+printState(p)+priceSummary(p.change)+(selectable&&!ready.has(p.key)?'<small>No imprimible · Revisa el motivo en la i.</small>':'')+'</li>').join('')+'</ul>'+(selectable?'<footer class="cyd64-change-footer"><strong data-cyd64-count>0 seleccionados</strong>'+(actions.destinations?.length?'<label>Enviar a local<select data-cyd64-destination aria-label="Local de destino para cambios"><option value="">Seleccionar local</option>'+actions.destinations.map(local=>'<option value="'+esc(local.code)+'">'+esc(local.code)+' · '+esc(local.name)+'</option>').join('')+'</select></label>':'')+'<div><button class="btn ghost" data-cyd64-enqueue disabled>Enviar a cola de impresión</button><button class="btn primary" data-cyd64-print disabled>Imprimir seleccionados</button></div><p data-cyd64-status role="status" aria-live="polite"></p></footer>':''):'<p>Esta familia no tiene cambios de precio registrados.</p>';
   const dialog=showDialog('Cambios de precio · '+familyName[type],number(items.length)+' promociones modificadas',body,button);
   bindInformation(dialog,rows,actions,current=>{records.clear();for(const row of current)records.set(row.key,row);ready.clear();for(const item of items){const row=records.get(item.key);if(row&&g.CARTELERIA_RULES.validate(row.sign).length===0&&g.CYD68_ALERTS.change(row.key,row.sign.priceChange))ready.add(item.key);}for(const key of [...selected])if(!ready.has(key))selected.delete(key);for(const input of dialog.querySelectorAll('[data-cyd64-change]'))input.disabled=!ready.has(input.dataset.cyd64Change);if(selectable)update();});
   if(!selectable||!items.length)return;
   let busy=false;
   const status=dialog.querySelector('[data-cyd64-status]');
   function update(){
    dialog.querySelector('[data-cyd64-count]').textContent=number(selected.size)+' seleccionado'+(selected.size===1?'':'s');
    const all=dialog.querySelector('[data-cyd64-all]');all.checked=ready.size>0&&selected.size===ready.size;all.indeterminate=selected.size>0&&selected.size<ready.size;
    for(const control of dialog.querySelectorAll('[data-cyd64-enqueue],[data-cyd64-print]'))control.disabled=busy||!selected.size;
   }
   dialog.addEventListener('change',event=>{
    if(busy)return;
    if(event.target.matches('[data-cyd64-all]')){selected.clear();if(event.target.checked)ready.forEach(key=>selected.add(key));dialog.querySelectorAll('[data-cyd64-change]').forEach(input=>{input.checked=selected.has(input.dataset.cyd64Change);});}
    if(event.target.matches('[data-cyd64-change]')){const key=event.target.dataset.cyd64Change;if(ready.has(key))event.target.checked?selected.add(key):selected.delete(key);}
    if(event.target.matches('input,select')){status.textContent='';update();}
   });
   dialog.addEventListener('click',async event=>{
    const control=event.target.closest('[data-cyd64-enqueue],[data-cyd64-print]');if(!control||control.disabled||busy)return;
    const printing=control.hasAttribute('data-cyd64-print');
    if(printing&&isMobileDevice()){pcOnlyNotice(control);return;}
    const destination=dialog.querySelector('[data-cyd64-destination]')?.value||'';
    if(!printing&&actions.destinations?.length&&!destination){status.textContent='Selecciona el local que recibirá los carteles.';return;}
    const keys=[...selected],inputs=[...dialog.querySelectorAll('input,select')].map(el=>({el,disabled:el.disabled}));
    busy=true;inputs.forEach(({el})=>{el.disabled=true;});update();status.textContent=printing?'Preparando los carteles seleccionados…':'Actualizando promociones…';
    try{
     if(printing){
      const result=await actions.print(keys);
      status.textContent=result===false?'No se pudo abrir la impresión. Permite las ventanas emergentes e intenta nuevamente.':'Impresión preparada con '+number(keys.length)+' carteles seleccionados.';
     }else{
      await actions.refresh();
      const fresh=new Map(actions.records().map(row=>[row.key,row])),chosen=keys.map(key=>fresh.get(key));
      if(chosen.some(row=>!row||g.CARTELERIA_RULES.validate(row.sign).length))throw new Error('Una promoción cambió o necesita revisión. Actualiza y vuelve a seleccionar.');
      status.textContent=(await actions.enqueue(chosen,destination))||number(chosen.length)+' carteles enviados a la cola de impresión.';
      selected.clear();dialog.querySelectorAll('[data-cyd64-change]').forEach(input=>{input.checked=false;});
     }
    }catch(error){status.textContent=error.message;}
    finally{busy=false;inputs.forEach(({el,disabled})=>{el.disabled=disabled;});update();}
   });
  };
 }
 let active=null;
 function open(bridge){
  active?.dispose();
  const host=bridge.host,state={type:'all',department:'all',category:'all',list:'all',query:'',page:0,size:12,sort:preferredOrder(),selected:new Set(),busy:false,destination:''};
  let rows=[],visible=[],dialog=null,disposed=false;
  const keyMap=()=>new Map(rows.map(r=>[r.key,r])),issues=r=>g.CARTELERIA_RULES.validate(r.sign),ready=r=>issues(r).length===0;
  function status(message,bad=false){const el=host.querySelector('[data-cyd55-status]');if(el){el.textContent=message;el.dataset.kind=bad?'error':'ok';}}
  function closePreview(){dialog?.remove();dialog=null;host.querySelector('[data-cyd55-preview]')?.focus();}
  function dispose(){disposed=true;closePreview();}
  const controller={dispose,get state(){return {...state,selected:new Set(state.selected)};}};active=controller;
  host.innerHTML=(bridge.header?bridge.header():'')+`<section class="screen cyd55-filter"><header class="cyd55-head"><div><h1>Filtro Categorías</h1><p data-cyd55-total></p></div><div class="cyd55-head-actions"><button class="btn ghost" type="button" data-cyd55-refresh>Actualizar</button><button class="btn back-home" type="button" data-cyd55-home>Volver al inicio</button></div></header><div data-cyd55-picker></div><div class="cyd55-filters"><label>Departamento<select data-cyd55-department aria-label="Departamento"></select></label><label>Categoría<select data-cyd55-category aria-label="Categoría"></select></label><label>Lista<select data-cyd55-list aria-label="Lista"></select></label><label class="cyd55-search">Buscar producto<input type="search" data-cyd55-search aria-label="Buscar producto" placeholder="Nombre, ítem o UPC" autocomplete="off"></label></div><div class="cyd55-results-head"><p data-cyd55-results role="status"></p><label class="cyd67-sort">Ordenar por<select data-cyd67-sort aria-label="Ordenar productos"><option value="department">Departamento → Categoría → Producto A–Z</option><option value="name">Producto A–Z</option></select></label><label>Productos por página<select data-cyd55-size aria-label="Productos por página"><option value="10">10</option><option value="12" selected>12</option><option value="15">15</option></select></label><button class="btn ghost" type="button" data-cyd55-clear>Limpiar filtros</button></div><div class="selection-tools cyd57-all-tools"><label><input type="checkbox" data-cyd57-all-check aria-label="Seleccionar todos los productos filtrados"><span data-cyd57-all-label>Seleccionar todos</span></label><small data-cyd57-all-scope></small></div><div class="cyd55-table-wrap"><table class="cyd55-table"><caption class="cyd55-sr">Promociones de las listas vigentes</caption><thead><tr><th><input type="checkbox" data-cyd55-page-check aria-label="Seleccionar todos los productos filtrados"></th><th>Producto</th><th>Departamento / Categoría</th><th>Lista</th><th>Precio vigente</th><th>Cartel</th></tr></thead><tbody data-cyd55-rows></tbody></table></div><nav class="cyd55-pagination" aria-label="Páginas de promociones"><button class="btn ghost" type="button" data-cyd55-prev>← Anterior</button><p data-cyd55-page-label></p><button class="btn ghost" type="button" data-cyd55-next>Siguiente →</button></nav><footer class="cyd55-selection"><div><strong data-cyd55-selection-count>0 seleccionados</strong><span data-cyd55-queue-count></span></div><div class="cyd55-selection-actions"><button class="btn ghost" type="button" data-cyd55-select-result>Seleccionar resultado</button><button class="btn ghost" type="button" data-cyd55-unselect>Quitar selección</button>${bridge.destinations?.length?'<label class="cyd55-destination">Enviar a local<select data-cyd55-destination aria-label="Local de destino"><option value="">Seleccionar local</option>'+bridge.destinations.map(l=>'<option value="'+esc(l.code)+'">'+esc(l.code)+' · '+esc(l.name)+'</option>').join('')+'</select></label>':''}<button class="btn primary" type="button" data-cyd55-enqueue>Enviar a cola de impresión</button>${bridge.onQueue?'<button class="btn ghost" type="button" data-cyd55-queue>Ver cola de impresión</button>':''}</div></footer><p class="cyd55-status" data-cyd55-status role="status"></p></section>`;
  const panel=host.querySelector('.cyd55-filter');
  if(bridge.onChangeLocal)host.querySelector('#changeLocalTop')?.addEventListener('click',bridge.onChangeLocal);
  function options(selector,values,all,current){const el=panel.querySelector(selector);el.innerHTML='<option value="all">'+all+'</option>'+[...new Set(values)].sort(selector==='[data-cyd55-category]'?compareCategories:collator.compare).map(v=>'<option value="'+esc(v)+'">'+esc(v)+'</option>').join('');el.value=current;}
  function selection(){
   panel.querySelector('[data-cyd55-selection-count]').textContent=number(state.selected.size)+' seleccionados';
   const queue=bridge.queueCount?.();panel.querySelector('[data-cyd55-queue-count]').innerHTML=queue===null||queue===undefined?'':'Cola de impresión: <strong data-queue-count>'+number(queue)+'</strong> carteles';
   for(const name of ['enqueue','unselect'])panel.querySelector('[data-cyd55-'+name+']').disabled=state.busy||!state.selected.size;
   const available=visible.filter(ready),chosen=available.filter(r=>state.selected.has(r.key)).length;
   for(const check of panel.querySelectorAll('[data-cyd55-page-check],[data-cyd57-all-check]')){check.checked=available.length>0&&chosen===available.length;check.indeterminate=chosen>0&&chosen<available.length;check.disabled=state.busy||!available.length;}
   panel.querySelector('[data-cyd57-all-label]').textContent='Seleccionar todos ('+number(chosen)+'/'+number(available.length)+')';
   panel.querySelector('[data-cyd57-all-scope]').textContent='Todo el resultado filtrado, en todas las páginas.'+(available.length<visible.length?' '+number(visible.length-available.length)+' con datos por revisar.':'');
   panel.querySelector('[data-cyd55-select-result]').disabled=state.busy||!available.length;
   panel.querySelector('[data-cyd55-select-result]').textContent='Seleccionar todos ('+number(available.length)+')';
  }
  function render(){
   if(disposed||!host.contains(panel))return;
   rows=records(bridge.catalog());const typed=rows.filter(r=>matches(r,state.type));
   if(state.department!=='all'&&!typed.some(r=>r.department===state.department))state.department='all';
   if(state.list!=='all'&&!typed.some(r=>r.list===state.list))state.list='all';
   const categories=typed.filter(r=>(state.department==='all'||r.department===state.department)&&(state.list==='all'||r.list===state.list));
   if(state.category!=='all'&&!categories.some(r=>r.category===state.category))state.category='all';
   options('[data-cyd55-department]',typed.map(r=>r.department),'Todos los departamentos',state.department);options('[data-cyd55-category]',categories.map(r=>r.category),'Todas las categorías',state.category);options('[data-cyd55-list]',typed.map(r=>r.list),'Todas las listas',state.list);
   panel.querySelector('[data-cyd55-picker]').innerHTML=picker(rows,state.type);
   panel.querySelector('[data-cyd55-total]').textContent=number(rows.length)+' promociones en las listas vigentes';
   visible=orderProducts(filter(rows,state),state.sort);state.page=Math.min(state.page,Math.max(0,Math.ceil(visible.length/state.size)-1));
   panel.querySelector('[data-cyd67-sort]').value=state.sort;
   const start=state.page*state.size,pageRows=visible.slice(start,start+state.size),pages=Math.max(1,Math.ceil(visible.length/state.size));
   panel.querySelector('[data-cyd55-results]').textContent=visible.length?'Mostrando '+number(start+1)+'–'+number(start+pageRows.length)+' de '+number(visible.length)+' promociones':'No hay productos con estos filtros';
   panel.querySelector('[data-cyd55-page-label]').textContent='Página '+number(state.page+1)+' de '+number(pages);
   panel.querySelector('[data-cyd55-prev]').disabled=state.page===0;panel.querySelector('[data-cyd55-next]').disabled=state.page+1>=pages;
   panel.querySelector('[data-cyd55-rows]').innerHTML=pageRows.map(r=>`<tr data-cyd55-row="${esc(r.key)}"><td class="cyd55-check-cell"><input type="checkbox" data-cyd55-select="${esc(r.key)}" aria-label="Seleccionar ${esc(r.name)}" ${state.selected.has(r.key)?'checked':''} ${ready(r)?'':'disabled'}></td><td class="cyd55-product"><strong>${esc(r.name||'Sin descripción')}</strong><span>${esc([r.brand,r.size].filter(Boolean).join(' · '))}</span><small>${r.item?'Ítem '+esc(r.item)+' · ':''}UPC ${esc(r.upc)}${r.item?'':' · Sin ítem'}</small>${printMark(r.sign)}</td><td class="cyd55-category"><strong>${esc(r.department)}</strong><span>${esc(r.category)}</span></td><td class="cyd55-list-cell"><span class="cyd55-color-tag ${r.type}">${r.type==='red'?'Cartel rojo':r.type==='yellow'?'Cartel amarillo':'Lista'}</span><small>${esc(r.list)}</small></td><td class="cyd55-price">${r.sign.qty>1?'<span>'+number(r.sign.qty)+' por</span>':''}<strong>${money(r.sign.offer)}</strong>${priceBell(r)}${ready(r)?'':'<small>Revisar datos</small>'}</td><td class="cyd55-preview-cell"><button class="btn ghost" type="button" data-cyd55-preview="${esc(r.key)}" aria-label="Ver cartel de ${esc(r.name)}">Ver cartel</button></td></tr>`).join('')||'<tr><td colspan="6" class="cyd55-empty">Prueba con otra categoría o limpia los filtros.</td></tr>';
   bindPriceChanges(panel,rows,bridge.priceActions);
   selection();
  }
  function changeFilter(action){action();state.page=0;state.selected.clear();render();status('');}
  function preview(key){const row=keyMap().get(key);if(!row)return;closePreview();dialog=showPreview(row.sign,bridge.renderSign,[...host.querySelectorAll('[data-cyd55-preview]')].find(button=>button.dataset.cyd55Preview===key));}
  panel.addEventListener('input',e=>{if(e.target.matches('[data-cyd55-search]'))changeFilter(()=>{state.query=e.target.value;});});
  panel.addEventListener('change',e=>{
   const el=e.target;
   if(el.matches('[data-cyd67-sort]')){
    if(state.busy)return;
    state.sort=el.value==='name'?'name':'department';state.page=0;
    try{localStorage.setItem('carteleria.category-sort.v67',state.sort);}catch{}
    render();status('Orden actualizado. Se conserva la selección de carteles.');return;
   }
   for(const name of ['department','category','list'])if(el.matches('[data-cyd55-'+name+']'))return changeFilter(()=>{state[name]=el.value;if(name!=='category')state.category='all';});
   if(el.matches('[data-cyd55-size]')){state.size=Number(el.value);state.page=0;render();}
   if(el.matches('[data-cyd55-destination]'))state.destination=el.value;
   if(el.matches('[data-cyd55-select]')){el.checked?state.selected.add(el.dataset.cyd55Select):state.selected.delete(el.dataset.cyd55Select);selection();}
   if(el.matches('[data-cyd55-page-check],[data-cyd57-all-check]')){for(const r of visible.filter(ready))el.checked?state.selected.add(r.key):state.selected.delete(r.key);render();}
  });
  panel.addEventListener('click',async e=>{
   const button=e.target.closest('button');if(!button||button.disabled)return;
   if(button.hasAttribute('data-cyd55-type'))return changeFilter(()=>{state.type=button.dataset.cyd55Type;});
   if(button.hasAttribute('data-cyd55-home')){dispose();bridge.onHome();return;}
   if(button.hasAttribute('data-cyd55-queue')){dispose();bridge.onQueue();return;}
   if(button.hasAttribute('data-cyd55-preview'))return preview(button.dataset.cyd55Preview);
   if(button.hasAttribute('data-cyd55-prev')){state.page--;render();return;}
   if(button.hasAttribute('data-cyd55-next')){state.page++;render();return;}
   if(button.hasAttribute('data-cyd55-clear')){panel.querySelector('[data-cyd55-search]').value='';return changeFilter(()=>{Object.assign(state,{type:'all',department:'all',category:'all',list:'all',query:''});});}
   if(button.hasAttribute('data-cyd55-unselect')){state.selected.clear();render();return;}
   if(button.hasAttribute('data-cyd55-select-result')){visible.filter(ready).forEach(r=>state.selected.add(r.key));render();return;}
   if(!button.hasAttribute('data-cyd55-enqueue')&&!button.hasAttribute('data-cyd55-refresh'))return;
   if(button.hasAttribute('data-cyd55-enqueue')&&bridge.destinations?.length&&!state.destination)return status('Elige el local que recibirá los carteles.',true);
   const selectedKeys=[...state.selected],controls=[...panel.querySelectorAll('button,input,select')].map(el=>({el,disabled:el.disabled}));
   state.busy=true;controls.forEach(({el})=>{el.disabled=true;});status('Actualizando promociones…');
   try{
    await bridge.refresh();if(disposed)return;if(button.hasAttribute('data-cyd55-refresh'))await refreshProgress(true);
    rows=records(bridge.catalog());
    if(button.hasAttribute('data-cyd55-enqueue')){
     const map=keyMap(),chosen=selectedKeys.map(key=>map.get(key));
     if(chosen.some(r=>!r||!ready(r)))throw new Error('Una promoción cambió o necesita revisión. Actualiza la selección.');
     const result=await bridge.enqueue(chosen,state.destination);if(disposed)return;
     state.selected.clear();status(result||number(chosen.length)+' carteles enviados a la cola de impresión.');
    }else{const keys=keyMap();for(const key of state.selected)if(!keys.has(key))state.selected.delete(key);status('Promociones actualizadas.');}
   }catch(error){status(error.message,true);}finally{state.busy=false;controls.forEach(({el,disabled})=>{el.disabled=disabled;});if(!disposed)render();}
  });
  render();return controller;
 }
 g.CYD55_CATEGORIES={printMark,refreshProgress,paintProgress,information,revisionNote,classify,matches,records,filter,counts,orderProducts,compareCategories,picker,open,preview:showPreview,priceBell,bindPriceChanges,isMobileDevice,pcOnlyNotice};
})(window);
