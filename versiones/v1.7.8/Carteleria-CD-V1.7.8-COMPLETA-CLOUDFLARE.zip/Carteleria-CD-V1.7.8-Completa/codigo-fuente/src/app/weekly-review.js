(function(g){
 'use strict';
 const DAYS=['Lunes','Martes','Miércoles','Jueves','Viernes','Sábado','Domingo'];
 const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const num=v=>Number(v).toLocaleString('es-CL'),money=v=>'$'+num(v);
 const add=(day,days)=>new Date(new Date(day+'T12:00:00Z').getTime()+days*86400000).toISOString().slice(0,10);
 const monday=day=>add(day,-((new Date(day+'T12:00:00Z').getUTCDay()+6)%7));
 const weekday=day=>DAYS[(new Date(day+'T12:00:00Z').getUTCDay()+6)%7];
 const short=day=>new Intl.DateTimeFormat('es-CL',{day:'2-digit',month:'2-digit',timeZone:'UTC'}).format(new Date(day+'T12:00:00Z'));
 const instant=value=>new Intl.DateTimeFormat('es-CL',{dateStyle:'short',timeStyle:'short',timeZone:'America/Santiago'}).format(new Date(value));
 const labels={on:'Cumple en fecha',late:'Fuera de plazo',missed:'No cumple',today:'Pendiente de hoy',planned:'Programada',inactive:'Sin promociones vigentes'};
 let disposeActive=()=>{};
 const profile=()=>g.CYD54_ACCESS.profile;
 const isPilot=()=>profile()?.role==='store'&&String(profile().market)==='814';
 async function api(path,body){const r=await fetch((g.CYD_API_BASE||location.origin)+path,{method:body?'POST':'GET',cache:'no-store',headers:{'Content-Type':'application/json'},body:body?JSON.stringify(body):undefined});const data=await r.json();if(!r.ok||!data.ok)throw Object.assign(new Error(data.error||'No se pudo actualizar la revisión semanal.'),{status:r.status});return data;}
 function button(label,action,primary=false,extra=''){return '<button type="button" class="cyd69-button'+(primary?' primary':'')+'" data-cyd69-action="'+action+'" '+extra+'>'+label+'</button>';}
 const badge=c=>'<span class="cyd69-badge '+c.status+'">'+esc(c.preservedReview?'Revisada · conservada':labels[c.status])+'</span>';
 function weekControl(data){const week=data.week||monday(data.today);return '<div class="cyd69-week-control">'+button('←','previous',false,'aria-label="Semana anterior" '+(week<=monday(data.activation)?'disabled':''))+'<span><strong>'+short(week)+' al '+short(add(week,6))+'</strong><small>'+week.slice(0,4)+'</small></span>'+button('→','next',false,'aria-label="Semana siguiente" '+(week>=(data.maxWeek||monday(data.today))?'disabled':''))+'</div>';}
 async function preparePrint(products,context=null){
  if(!isPilot())return [];
  const signs=products.filter(p=>p.occamKey&&!p.manual);if(!signs.length)return [];
  const response=await api('/api/semanal/referencias-impresion',{products:signs.map(p=>{const ref=context||p.weeklyReview||null;return {key:p.occamKey,token:JSON.stringify([p.occamKey,p.code,p.barcode,p.qty,p.offer,p.unit]),...(ref?{week:ref.week,categoryKey:ref.key}:{})};})});
  return response.entries;
 }
 function planNotice(data){return data.history?'<p class="cyd69-notice">Historial anterior al reinicio del 16/11/2026. Solo consulta.</p>':data.today<data.restartDate?'<p class="cyd69-notice">La revisión comienza el lunes 16/11/2026. Este nuevo ciclo parte sin revisiones realizadas.</p>':'';}
 function cycleControl(data){
  const cycle=data.cycle||data.rows?.find(r=>r.cycle)?.cycle;if(!cycle)return '';
  const weeks=cycle.weeks.map(w=>{const others=data.rows?.filter(r=>r.cycle?.start===cycle.start).map(r=>r.cycle.weeks.find(v=>v.week===w.week))||[w];return {...w,total:others.reduce((n,x)=>n+(x?.total||0),0),reviewed:others.reduce((n,x)=>n+(x?.reviewed||0),0),products:others.reduce((n,x)=>n+(x?.products||0),0)};});
  const stats=data.rows?{total:data.rows.reduce((n,r)=>n+(r.cycle?.stats.total||0),0),reviewed:data.rows.reduce((n,r)=>n+(r.cycle?.stats.reviewed||0),0)}:cycle.stats;
  const preserved=data.rows?data.rows.reduce((n,r)=>n+(r.cycle?.preservedCount||0),0):(cycle.preservedCount||0);
  const schedule=cycle.policy74?'Revisión de lunes a domingo durante las tres semanas. El plan del mercado 814 comienza el lunes 16/11/2026.':cycle.closed?'Plan anterior cerrado por el reinicio del 16/11/2026. Historial de consulta.':cycle.number===1?'Solo lunes y martes de la primera semana quedan sin categorías. En las semanas 2 y 3 se revisa de lunes a domingo.':'Revisión de lunes a domingo durante las tres semanas.';
  return '<section class="cyd70-cycle" aria-label="Ciclo rotativo de tres semanas"><div class="cyd70-cycle-heading"><strong>Ciclo '+cycle.number+' · '+short(cycle.start)+' al '+short(cycle.end)+'</strong><span>'+stats.reviewed+' / '+stats.total+' categorías revisadas</span></div><div class="cyd70-weeks">'+weeks.map(w=>'<button type="button" class="cyd70-week" data-cyd69-cycle-week="'+w.week+'" aria-pressed="'+(w.week===data.week)+'"><strong>Semana '+w.number+(cycle.closed?' · Historial':' de 3')+'</strong><small>'+short(w.week)+' al '+short(add(w.week,6))+'</small><span>'+w.total+' categorías · '+num(w.products)+' productos</span><small>'+w.reviewed+' / '+w.total+' revisadas</small></button>').join('')+'</div><p>'+schedule+(preserved?' Las '+num(preserved)+' categorías ya revisadas están incluidas en miércoles y jueves, en verde.':'')+'</p><p>Al terminar la semana 3 comienza una nueva vuelta, mientras haya promociones vigentes.</p></section>';
 }
 async function open(bridge){
  if(!isPilot())return bridge.onHome();
  disposeActive();
  const host=bridge.host;host.innerHTML=(bridge.header?bridge.header():'')+'<section class="screen cyd69-weekly" aria-label="Revisión semanal"><div data-cyd69-content></div><p class="cyd69-live" data-cyd69-message role="status" aria-live="polite"></p></section>';
  const root=host.querySelector('.cyd69-weekly'),content=root.querySelector('[data-cyd69-content]'),message=root.querySelector('[data-cyd69-message]');
  let data=null,week='',day='',key=null,family=null,selection=new Set(),listChecks=new Set(),confirmed=false,signature=null,busy=false,requestId=0,disposed=false,page=0;
  const category=()=>data?.categories.find(c=>c.key===key),valid=()=>!disposed&&root.isConnected;
  function dispose(){disposed=true;g.removeEventListener('cyd69-printed',onPrinted);}
  disposeActive=dispose;
  function onPrinted(event){if(event.detail?.local===profile()?.code){if(valid())load(false);else dispose();}}
  g.addEventListener('cyd69-printed',onPrinted);
  const exit=host.querySelector('#changeLocalTop');if(exit&&bridge.onChangeLocal)exit.onclick=()=>{dispose();bridge.onChangeLocal();};
  function note(text,bad=false){message.textContent=text;message.classList.toggle('error',bad);}
  const signs=()=>{const c=category();if(!c)return [];const keys=new Set(c.items.filter(p=>p.family===family).map(p=>p.key));return g.CYD55_CATEGORIES.orderProducts(g.CYD55_CATEGORIES.records(bridge.catalog()).filter(r=>keys.has(r.key)),'name');};
  const ready=row=>g.CARTELERIA_RULES.validate(row.sign).length===0;
  function render(){
   if(!valid()||!data)return;
   root.classList.toggle('is-busy',busy);
   if(!key)renderWeek();else renderCategory();
   for(const control of root.querySelectorAll('button,input,select'))if(busy)control.disabled=true;
  }
  function renderWeek(){
   const weekStart=data.week||monday(data.today),stats=data.stats;
   if(!day||day<weekStart||day>add(weekStart,6))day=weekStart===monday(data.today)?data.today:weekStart;
   const days=Array.from({length:7},(_,i)=>add(weekStart,i)),rows=data.categories.filter(c=>c.day===day);
   content.innerHTML='<div class="cyd69-heading"><div><p class="cyd69-kicker">Plan de revisión · Local '+esc(data.local)+'</p><h1>Revisión semanal</h1><p>Toda la sala en 3 semanas, con menos categorías para revisar cada día.</p></div><div class="cyd69-head-actions">'+weekControl(data)+button('Actualizar','refresh')+button('Volver al inicio','home')+'</div></div>'+
    cycleControl(data)+planNotice(data)+'<div class="cyd69-overview"><div><div class="cyd69-progress-title"><strong>Avance de esta semana</strong><span>'+num(stats.reviewed)+' / '+num(stats.total)+' categorías</span></div><div class="cyd69-track" role="progressbar" aria-label="Categorías revisadas" aria-valuenow="'+stats.reviewed+'" aria-valuemin="0" aria-valuemax="'+Math.max(1,stats.total)+'"><div style="width:'+(stats.total?stats.reviewed/stats.total*100:0)+'%"></div></div></div><div class="cyd69-mini-stats"><span><strong>'+num(stats.onTime)+'</strong>En fecha</span><span><strong>'+num(stats.late)+'</strong>Con atraso</span><span><strong>'+num(stats.missed)+'</strong>Sin cumplir</span></div></div>'+
    '<div class="cyd69-week-root">Semana de revisión</div><div class="cyd69-days" aria-label="Días de revisión">'+days.map(date=>{const cats=data.categories.filter(c=>c.day===date&&c.active!==false),done=cats.filter(c=>c.review).length,missed=cats.filter(c=>c.status==='missed').length,late=cats.filter(c=>c.status==='late').length;return '<button type="button" class="cyd69-day" data-cyd69-day="'+date+'" aria-pressed="'+(date===day)+'"><strong>'+weekday(date)+'</strong><small>'+short(date)+(date===data.today?' · Hoy':'')+'</small><span>'+num(done)+' / '+cats.length+' revisadas</span><div class="cyd69-track"><div style="width:'+(cats.length?done/cats.length*100:0)+'%"></div></div><small class="'+(missed?'missed':late?'late':'')+'">'+(missed?missed+' no cumple':late?late+' fuera de plazo':!cats.length?'Sin categorías':done===cats.length?'Completado':date===data.today?'Para revisar hoy':date>data.today?'Programado':'Completado')+'</small></button>';}).join('')+'</div>'+
    '<div class="cyd69-section-head"><div><h2>'+weekday(day)+' '+short(day)+'</h2><p>'+num(rows.filter(c=>c.active!==false).length)+' categorías · '+num(rows.reduce((n,c)=>n+c.total,0))+' productos</p></div>'+button('Ver cola de impresión ('+(bridge.queueCount?.()||0)+')','queue')+'</div><div class="cyd69-categories">'+rows.map(c=>'<button type="button" class="cyd69-category '+c.status+'" data-cyd69-category="'+c.key+'"><div>'+badge(c)+'</div><small>'+esc(c.department)+'</small><strong>'+esc(c.categoryName)+'</strong><span>'+num(c.total)+' carteles <b>Revisar →</b></span>'+(c.review?'<small>Revisada '+esc(instant(c.review.reviewedAt))+'</small>':'')+(c.latePrints?'<small class="late">Impreso fuera de día · '+num(c.latePrints)+' carteles</small>':'')+'</button>').join('')+'</div>'+
    (!rows.length?'<div class="cyd69-empty">No hay categorías programadas para este día.</div>':'')+
    '<div class="cyd69-legend"><span class="on">● Cumple en fecha</span><span class="missed">● No cumple</span><span class="late">● Regularizada fuera de plazo</span><span>● Programada</span></div><p class="cyd69-footnote">Inicio del reparto: '+short(data.cycle?.firstDay||data.activation)+'. Cada categoría aparece una vez en la lista completa del ciclo. Las ya revisadas siguen en verde y conservan su fecha original de revisión.</p>';
  }
  function familyCard(type,title,subtitle){const c=category(),done=listChecks.has(type)||c.review;return '<button type="button" class="cyd69-family" data-cyd69-family="'+type+'" aria-pressed="'+(family===type)+'"><span><strong>'+title+'</strong><small>'+subtitle+'</small></span>'+(type==='other'?'<div class="cyd69-art other">Otras listas</div>':'<div class="cyd69-art '+type+'">'+(type==='red'?'<b>BARATO</b><em>todos los días</em>':'<em>Ahora más</em><b>BARATO</b>')+'</div>')+'<span><small>'+num(c.counts[type])+' carteles</small><small class="'+(done?'on':'')+'">'+(done?'✓ Revisada':'Abrir lista →')+'</small></span></button>';}
  function renderCategory(){
   const c=category();if(!c){key=null;renderWeek();return;}
   const all=signs(),max=Math.max(0,Math.ceil(all.length/12)-1);page=Math.min(page,max);const rows=all.slice(page*12,page*12+12),todayAllowed=!data.readOnly&&c.day<=data.today&&!!c.signature&&c.active!==false;
   const required=['red','yellow',...(c.counts.other?['other']:[])],complete=required.every(type=>listChecks.has(type));
   content.innerHTML='<div class="cyd69-breadcrumb">'+button('← Semana','back')+'<span>'+weekday(c.day)+' '+short(c.day)+' / '+esc(c.categoryName)+'</span></div><div class="cyd69-heading"><div><p class="cyd69-kicker">'+esc(c.department)+'</p><h1>'+esc(c.categoryName)+'</h1><p>Día asignado: '+weekday(c.day)+' '+short(c.day)+'</p></div>'+badge(c)+'</div>'+
    (c.day<data.today&&!c.review?'<p class="cyd69-notice missed">Esta revisión correspondía al '+weekday(c.day).toLowerCase()+' '+short(c.day)+'. Puedes regularizarla; quedará registrada fuera de plazo.</p>':'')+
    '<div class="cyd69-section-head"><h2>Selecciona la lista</h2>'+button('Actualizar','refresh')+'</div><div class="cyd69-families">'+familyCard('red','EDLP','Cartel Rojo')+familyCard('yellow','Campaña','Cartel Amarillo')+(c.counts.other?familyCard('other','Otras listas','Carteles de la categoría'):'')+'</div>'+
    (!family?'<div class="cyd69-empty">Elige EDLP o Campaña para revisar los productos.</div>':'<div class="cyd69-section-head"><h3>'+({red:'EDLP · Cartel Rojo',yellow:'Campaña · Cartel Amarillo',other:'Otras listas'}[family])+'</h3><label class="cyd69-check"><input type="checkbox" data-cyd69-all '+(all.filter(ready).length&&selection.size===all.filter(ready).length?'checked':'')+'>Seleccionar todos ('+num(all.filter(ready).length)+')</label></div>'+
    (rows.length?'<div class="cyd69-products">'+rows.map(r=>{const receipt=c.prints.filter(p=>p.key===r.key&&p.token===c.items.find(i=>i.key===r.key)?.token).sort((a,b)=>b.printedAt.localeCompare(a.printedAt))[0];return '<div class="cyd69-product"><input type="checkbox" data-cyd69-product="'+esc(r.key)+'" aria-label="Seleccionar '+esc(r.name)+'" '+(selection.has(r.key)?'checked':'')+' '+(!ready(r)?'disabled':'')+'><div><strong>'+esc(r.name)+'</strong><small>'+esc([r.brand,r.size,r.item?'Ítem '+r.item:'UPC '+r.upc].filter(Boolean).join(' · '))+'</small>'+(receipt?'<small class="'+(receipt.late?'late':'on')+'">'+(receipt.late?'Impreso fuera de día · ':'Impreso · ')+esc(instant(receipt.printedAt))+'</small>':'')+(!ready(r)?'<small class="missed">Revisar datos antes de imprimir</small>':'')+'</div><div class="cyd69-product-side"><strong>'+(r.sign.qty>1?num(r.sign.qty)+' × ':'')+money(r.sign.offer)+'</strong>'+button('Ver cartel','preview',false,'data-key="'+esc(r.key)+'"')+'</div></div>';}).join('')+'</div><div class="cyd69-pagination">'+button('← Anterior','prev-page',false,page===0?'disabled':'')+'<span>Página '+(page+1)+' de '+(max+1)+' · '+num(all.length)+' productos</span>'+button('Siguiente →','next-page',false,page===max?'disabled':'')+'</div><div class="cyd69-printbar"><strong>'+num(selection.size)+' seleccionados</strong><div>'+button('Enviar a cola de impresión','enqueue',false,!selection.size||data.readOnly?'disabled':'')+button('Imprimir selección','print',true,!selection.size||data.readOnly?'disabled':'')+'</div></div>':'<div class="cyd69-empty">No hay productos vigentes de esta lista en la categoría.</div>')+
    '<label class="cyd69-check"><input type="checkbox" data-cyd69-list '+(listChecks.has(family)||c.review?'checked':'')+' '+(!todayAllowed||c.review?'disabled':'')+'>Revisé '+({red:'EDLP (Cartel Rojo)',yellow:'Campaña (Cartel Amarillo)',other:'Otras listas'}[family])+(all.length?' en sala.':': sin carteles para esta categoría.')+'</label>')+
    '<section class="cyd69-finish"><div class="cyd69-section-head"><div><h3>Cierre de categoría</h3><p>'+required.map(type=>({red:'EDLP',yellow:'Campaña',other:'Otras listas'}[type])+': '+(listChecks.has(type)||c.review?'✓':'pendiente')).join(' · ')+'</p></div>'+badge(c)+'</div>'+
    (c.review?'<p class="'+(c.status==='on'?'on':'late')+'">Revisada el '+esc(instant(c.review.reviewedAt))+(c.status==='late'?' · No recupera el cumplimiento en el día asignado.':'.')+'</p>':'<label class="cyd69-check"><input type="checkbox" data-cyd69-confirm '+(confirmed?'checked':'')+' '+(!complete||!todayAllowed?'disabled':'')+'>Confirmo que revisé la categoría completa en sala.</label><div class="cyd69-finish-actions"><span class="cyd69-footnote '+(c.day<data.today?'late':'')+'">'+(data.readOnly?'Historial de consulta.':!todayAllowed?'Disponible en su día y con promociones vigentes.':c.day<data.today?'Se guardará fuera de plazo.':'Se guardará con la fecha y hora actuales.')+'</span>'+button('✓ Guardar revisión','complete',true,!complete||!confirmed||!todayAllowed?'disabled':'')+'</div>')+'<p class="cyd69-footnote">La revisión de sala y la impresión de carteles se registran por separado.</p></section>';
  }
  async function load(refreshCatalog=true){
   const id=++requestId;busy=true;if(!data)content.innerHTML='<p>Cargando el plan de revisión semanal…</p>';else render();
   try{
    if(refreshCatalog)await bridge.refresh();
    const next=await api('/api/semanal?'+new URLSearchParams({week}));if(id!==requestId||!valid())return;
    const fresh=next.categories.find(c=>c.key===key);if(signature&&fresh?.signature!==signature&&!fresh?.review){listChecks.clear();confirmed=false;note('La categoría cambió. Revisa nuevamente ambas listas.',true);}
    signature=fresh?.signature||null;data=next;week=next.week||monday(next.today);busy=false;render();
   }catch(error){if(id===requestId&&valid()){busy=false;note(error.message,true);if(data)render();else content.innerHTML=button('Reintentar','refresh')+button('Volver al inicio','home');}}
  }
  root.addEventListener('change',event=>{
   if(busy)return;const el=event.target;
   if(el.matches('[data-cyd69-product]')){el.checked?selection.add(el.dataset.cyd69Product):selection.delete(el.dataset.cyd69Product);}
   else if(el.matches('[data-cyd69-all]')){selection.clear();if(el.checked)signs().filter(ready).forEach(r=>selection.add(r.key));}
   else if(el.matches('[data-cyd69-list]')){if(el.checked)listChecks.add(family);else{listChecks.delete(family);confirmed=false;}}
   else if(el.matches('[data-cyd69-confirm]'))confirmed=el.checked;
   else return;
   render();
  });
  root.addEventListener('click',async event=>{
   if(busy)return;const target=event.target.closest('button');if(!target||target.disabled)return;
   if(target.dataset.cyd69CycleWeek){week=target.dataset.cyd69CycleWeek;day='';key=null;await load();return;}
   if(target.dataset.cyd69Day){day=target.dataset.cyd69Day;render();return;}
   if(target.dataset.cyd69Category){key=target.dataset.cyd69Category;family=null;selection.clear();listChecks.clear();confirmed=false;signature=category()?.signature;page=0;note('');render();return;}
   if(target.dataset.cyd69Family){family=target.dataset.cyd69Family;selection.clear();page=0;render();return;}
   const action=target.dataset.cyd69Action;if(!action)return;
   try{
    if(action==='home'){dispose();bridge.onHome();return;}
    if(action==='queue'){dispose();bridge.onQueue();return;}
    if(action==='back'){key=null;family=null;selection.clear();note('');render();return;}
    if(action==='previous'||action==='next'){week=add(data.week||monday(data.today),action==='previous'?-7:7);day='';key=null;await load();return;}
    if(action==='refresh'){await load();return;}
    if(action==='prev-page'||action==='next-page'){page+=action==='prev-page'?-1:1;render();return;}
    if(action==='preview'){const r=signs().find(p=>p.key===target.dataset.key);if(r)g.CYD55_CATEGORIES.preview(r.sign,bridge.renderSign,target);return;}
    if(action==='print'){
     if(g.CYD55_CATEGORIES.isMobileDevice()){g.CYD55_CATEGORIES.pcOnlyNotice(target);return;}
     const result=await bridge.print([...selection],{week:data.week,key});if(result!==false)note('Impresión preparada. Confirma el resultado al terminar en la impresora.');return;
    }
    if(action==='enqueue'){
     const selected=[...selection],expected=signature;busy=true;render();await bridge.refresh();const next=await api('/api/semanal?'+new URLSearchParams({week:data.week})),fresh=next.categories.find(c=>c.key===key);
     if(fresh?.signature!==expected)throw new Error('La categoría cambió. Actualiza y vuelve a seleccionar.');
     const records=new Map(g.CYD55_CATEGORIES.records(bridge.catalog()).map(r=>[r.key,r])),rows=selected.map(id=>records.get(id));if(rows.some(r=>!r||!ready(r)))throw new Error('Un producto cambió o necesita revisión. Actualiza antes de enviarlo.');
     const response=await bridge.enqueue(rows.map(r=>({...r,sign:{...r.sign,weeklyReview:{week:data.week,key}}})));note(response||'Carteles enviados a la cola de impresión.');selection.clear();busy=false;await load(false);return;
    }
    if(action==='complete'){
     const c=category();busy=true;render();const result=await api('/api/semanal/revisar',{local:data.local,week:data.week,key:c.key,signature,lists:[...listChecks],confirmed});
     note(result.late?'Revisión registrada fuera de plazo. El día original mantiene su incumplimiento.':'Revisión de categoría guardada.');busy=false;await load(false);return;
    }
   }catch(error){busy=false;note(error.message,true);render();if(error.status===409)load();}
  });
  await load();
 }
 async function openReport({host,onBack}){
  if(profile()?.role!=='master')return;
  disposeActive();host.innerHTML='<section class="cyd69-weekly cyd69-report"><div data-cyd69-report></div><p data-cyd69-error role="status" aria-live="polite"></p></section>';
  const root=host.querySelector('.cyd69-report'),content=root.querySelector('[data-cyd69-report]'),error=root.querySelector('[data-cyd69-error]');let data=null,week='',selected=null,busy=false,sequence=0;
  function render(){
   const due=data.rows.reduce((n,r)=>n+r.stats.due,0),on=data.rows.reduce((n,r)=>n+r.stats.onTime,0),late=data.rows.reduce((n,r)=>n+r.stats.late,0),missed=data.rows.reduce((n,r)=>n+r.stats.missed,0);
   const detail=data.rows.find(r=>r.local===selected);
   content.innerHTML='<div class="cyd69-heading"><div><p class="cyd69-kicker">Mercado 814 · '+data.rows.length+' locales</p><h1>Adherencia semanal</h1><p>Rotación de categorías en 3 semanas · Acceso de Administrador</p></div><div class="cyd69-head-actions">'+weekControl(data)+button('Actualizar','refresh')+button('Volver','back-report')+'</div></div>'+
    cycleControl(data)+planNotice(data)+'<div class="cyd69-report-stats"><article><span>Adherencia en fecha</span><strong>'+(due?Math.round(on/due*100)+'%':'—')+'</strong><small>'+on+' de '+due+' categorías de días vencidos</small></article><article><span>Revisadas fuera de plazo</span><strong>'+late+'</strong><small>Regularizadas con atraso</small></article><article><span>Sin revisar</span><strong>'+missed+'</strong><small>No cumplieron su día</small></article></div>'+
    '<div class="cyd69-table-wrap"><table><thead><tr><th>Local</th><th>En fecha</th><th>Con atraso</th><th>No cumple</th><th>Hoy</th><th>Impresión tardía</th><th>Detalle</th></tr></thead><tbody>'+data.rows.map(r=>'<tr><th scope="row">'+esc(r.local)+'<small>'+esc(r.name)+'</small><small>'+esc(r.market)+' · '+esc(r.marketName)+'</small>'+(r.cycle?'<small>Ciclo: '+r.cycle.stats.reviewed+' / '+r.cycle.stats.total+' revisadas</small>':'')+'</th><td><strong>'+(r.stats.adherence===null?'—':r.stats.adherence+'%')+'</strong><small>'+r.stats.onTime+' / '+r.stats.due+' vencidas</small></td><td>'+r.stats.late+'</td><td><span class="cyd69-badge '+(r.stats.missed?'missed':'on')+'">'+r.stats.missed+' pendientes</span></td><td>'+r.stats.todayReviewed+' / '+r.stats.todayTotal+'</td><td>'+r.stats.latePrints+' carteles</td><td>'+button('Ver detalle','detail',false,'data-local="'+esc(r.local)+'"')+'</td></tr>').join('')+'</tbody></table></div><p class="cyd69-footnote">La adherencia exige cumplir el día asignado. Las revisiones tardías se muestran aparte. Los días futuros y anteriores al inicio del plan no se exigen.</p>'+
    (detail?'<div class="cyd69-section-head" style="margin-top:24px"><div><h2>Local '+esc(detail.local)+' · '+esc(detail.name)+'</h2><p>'+detail.stats.reviewed+' / '+detail.stats.total+' categorías revisadas</p></div>'+button('Cerrar detalle','close-detail')+'</div><div class="cyd69-detail-rows">'+detail.categories.map(c=>'<article class="cyd69-detail-row"><div><strong>'+esc(c.categoryName)+'</strong><small>'+esc(c.department)+' · Asignada: '+weekday(c.day)+' '+short(c.day)+'</small><small>'+(c.review?'Revisada: '+esc(instant(c.review.reviewedAt)):'Revisión sin registrar')+' · '+c.printed+' carteles impresos</small>'+(c.latePrints?'<small class="late">Impreso fuera de día · '+c.latePrints+' carteles</small>':'')+'</div>'+badge(c)+'</article>').join('')+'</div>':'');
   if(busy)root.querySelectorAll('button').forEach(b=>b.disabled=true);
  }
  async function load(){const id=++sequence;busy=true;if(data)render();else content.innerHTML='<p>Cargando adherencia semanal…</p>';error.textContent='';try{const next=await api('/api/semanal/resumen?'+new URLSearchParams({week}));if(id!==sequence||!root.isConnected)return;data=next;week=next.week;busy=false;render();}catch(e){if(id===sequence){busy=false;error.textContent=e.message;if(data)render();else content.innerHTML=button('Reintentar','refresh')+button('Volver','back-report');}}}
  root.addEventListener('click',event=>{if(busy)return;const b=event.target.closest('[data-cyd69-action],[data-cyd69-cycle-week]');if(!b||b.disabled)return;if(b.dataset.cyd69CycleWeek){week=b.dataset.cyd69CycleWeek;selected=null;load();return;}switch(b.dataset.cyd69Action){case 'back-report':onBack();break;case 'refresh':load();break;case 'previous':week=add(week,-7);selected=null;load();break;case 'next':week=add(week,7);selected=null;load();break;case 'detail':selected=b.dataset.local;render();break;case 'close-detail':selected=null;render();break;}});
  await load();
 }
 g.CYD69_WEEKLY={isPilot,preparePrint,open,openReport};
})(window);
