(function(g){
 'use strict';
 const esc=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const number=value=>Number(value).toLocaleString('es-CL');
 const date=value=>value?new Intl.DateTimeFormat('es-CL',{dateStyle:'short',timeStyle:'short',timeZone:'America/Santiago'}).format(new Date(value)):'Sin confirmación';
 const catalog=new Map(),tickets=new Map();
 async function api(path,body){
  const response=await fetch((g.CYD_API_BASE||location.origin)+path,{method:body?'POST':'GET',headers:{'Content-Type':'application/json'},cache:'no-store',body:body?JSON.stringify(body):undefined});
  const data=await response.json();if(!response.ok||!data.ok)throw Object.assign(new Error(data.error||'No se pudo actualizar la impresión de alertas.'),{status:response.status});return data;
 }
 function change(key,fallback){return catalog.has(key)?catalog.get(key):fallback;}
 function status(change){if(change?.printable===false)return 'Pendiente de corrección';return change?.printedAt?'Impresa · '+date(change.printedAt):'Pendiente de impresión';}
 function adopt(products){catalog.clear();for(const p of products||[])if(p.occamKey)catalog.set(p.occamKey,p.priceChange?{...p.priceChange,printable:p.printability75?.printable??(g.CARTELERIA_RULES.validate(p).length===0)}:null);update();}
 function familyProgress(type){
  const changes=[...catalog].filter(([key,c])=>c&&c.family===type).map(([,c])=>c);
  const available=changes.filter(c=>c.printable!==false);return {total:changes.length,printed:available.filter(c=>c.printedAt).length,pending:available.filter(c=>!c.printedAt).length,unprintable:changes.length-available.length};
 }
 function update(){
  if(!g.CYD55_CATEGORIES)return;
  for(const button of document.querySelectorAll('[data-cyd62-item]')){
   const c=change(button.dataset.cyd62Item,null);button.classList.toggle('is-printed',!!c?.printedAt&&c.printable!==false);button.classList.toggle('is-ringing',!!c&&(c.printable===false||!c.printedAt));
   button.title=status(c);button.setAttribute('aria-label',(c?.printable===false?'Pendiente de corrección. ':c?.printedAt?'Impresa. ':'Pendiente. ')+(button.dataset.cyd68Name||'Ver cambio de precio'));
  }
  for(const button of document.querySelectorAll('[data-cyd62-family]')){
   const p=familyProgress(button.dataset.cyd62Family);if(!catalog.size)continue;
   const done=p.total>0&&p.pending===0;button.classList.toggle('is-printed',done);button.classList.toggle('is-ringing',p.pending>0);button.classList.toggle('is-empty',p.total===0);
   button.querySelector('[data-cyd68-bell-label]')?.replaceChildren(document.createTextNode(done?(p.unprintable?'Sin imprimibles pendientes':'Cambios impresos'):'Cambios de precio'));
   const count=button.querySelector('strong');if(count)count.textContent=number(done?p.printed:p.pending);
   const summary=button.querySelector('[data-cyd68-bell-summary]');if(summary)summary.textContent=p.total?(number(p.printed)+' impresos · '+number(p.pending)+' pendientes'+(p.unprintable?' · '+number(p.unprintable)+' por corregir':'')):'Sin cambios';
   button.setAttribute('aria-label',(done?'Sin carteles imprimibles pendientes. ':number(p.pending)+' pendientes. ')+number(p.printed)+' de '+number(p.total)+' impresos');
  }
  for(const node of document.querySelectorAll('[data-cyd68-status-key]')){const c=change(node.dataset.cyd68StatusKey,null);node.classList.toggle('is-printed',!!c?.printedAt&&c.printable!==false);node.textContent=status(c);}
 }
 function begin({products,local,popup=null,refresh,weekly=[]}){
  const profile=g.CYD54_ACCESS.profile;
  if(profile?.role!=='store'||profile.code!==String(local))return null;
  const changes=[...new Map(products.filter(p=>p.occamKey&&p.priceChange?.token&&!p.manual).map(p=>[p.occamKey,{key:p.occamKey,token:p.priceChange.token}])).values()];
  const prints=[...new Map(products.filter(p=>p?.occamKey&&!p.manual).map(p=>[p.occamKey,{key:p.occamKey,qty:Number(p.qty),offer:Number(p.offer),unit:Number(p.unit)}])).values()];
  if(!changes.length&&!weekly.length&&!prints.length)return null;
  const ticket={id:crypto.randomUUID(),local:String(local),changes,weekly,prints,popup,refresh,shown:false,cleanup:()=>{}};
  tickets.set(ticket.id,ticket);return ticket;
 }
 function cancel(ticket){if(!ticket)return;ticket.cleanup();tickets.delete(ticket.id);}
 function watch(ticket,target=g){
  if(!ticket)return;
  const after=()=>confirmResult(ticket);target.addEventListener('afterprint',after,{once:true});
  ticket.cleanup=()=>target.removeEventListener('afterprint',after);
 }
 function popupScript(ticket){
  return ticket?"window.addEventListener('afterprint',function(){if(window.opener)window.opener.postMessage({type:'cyd68-print-finished',ticket:"+JSON.stringify(ticket.id)+"},"+JSON.stringify(location.origin)+")});":'';
 }
 g.addEventListener('message',event=>{
  if(event.origin!==location.origin||event.data?.type!=='cyd68-print-finished')return;
  const ticket=tickets.get(event.data.ticket);if(ticket&&event.source===ticket.popup)confirmResult(ticket);
 });
 function confirmResult(ticket){
  if(!ticket||ticket.shown||!tickets.has(ticket.id))return;ticket.cleanup();ticket.shown=true;
  const profile=g.CYD54_ACCESS.profile;if(profile?.role!=='store'||profile.code!==ticket.local){cancel(ticket);return;}
  const active=document.activeElement,panel=document.createElement('div');panel.className='cyd68-confirm';
  panel.innerHTML='<section role="dialog" aria-modal="true" aria-label="Confirmar impresión de carteles"><h2>¿Se imprimieron correctamente?</h2><p>Local '+esc(ticket.local)+(ticket.changes.length?' · '+number(ticket.changes.length)+' alerta(s) de precio':'')+(ticket.weekly.length?' · '+number(ticket.weekly.length)+' cartel(es) de revisión semanal':'')+(ticket.prints.length?' · '+number(ticket.prints.length)+' cartel(es) para adherencia':'')+'</p><p>Confirma cuando los carteles hayan salido de la impresora. Si cancelaste o falló la impresión, mantén los registros pendientes.</p><div class="cyd68-confirm-actions"><button class="btn ghost" data-cyd68-no>No, mantener pendientes</button><button class="btn primary" data-cyd68-yes>Sí, se imprimieron</button></div><p role="status" data-cyd68-confirm-status></p></section>';
  document.body.appendChild(panel);const yes=panel.querySelector('[data-cyd68-yes]'),no=panel.querySelector('[data-cyd68-no]'),message=panel.querySelector('[data-cyd68-confirm-status]');let busy=false;
  function close(){cancel(ticket);panel.remove();if(active?.isConnected)active.focus();}
  no.onclick=close;no.focus();
  panel.addEventListener('keydown',event=>{
   if(event.key==='Escape'&&!busy){event.preventDefault();event.stopPropagation();close();}
   if(event.key==='Tab'){const first=no.disabled?null:no,last=yes.disabled?null:yes;if(!first){event.preventDefault();return;}if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus();}else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus();}}
  });
  yes.onclick=async()=>{
   if(busy)return;busy=true;yes.disabled=no.disabled=true;message.textContent='Guardando impresión del local…';
   try{
    const result=await api('/api/alertas/impresiones',{local:ticket.local,changes:ticket.changes,weekly:ticket.weekly,prints:ticket.prints,ticket:ticket.id});
    for(const entry of ticket.changes){const c=catalog.get(entry.key);if(c?.token===entry.token)c.printedAt=result.printedAt;}
    update();message.textContent='Impresión confirmada. '+number(result.tracked||0)+' carteles considerados para adherencia.'+(ticket.changes.length?' Las alertas de estos carteles quedan verdes.':'')+(result.weeklyConfirmed?' Se registró la impresión semanal.':'')+(result.weeklyLate?' Incluye carteles impresos fuera del día asignado.':'');
    if(result.weeklyConfirmed)g.dispatchEvent(new CustomEvent('cyd69-printed',{detail:{local:ticket.local}}));
    try{await ticket.refresh?.();await g.CYD55_CATEGORIES?.refreshProgress(true);}catch{message.textContent+=' Recarga la vista para actualizar el listado.';}
    cancel(ticket);yes.hidden=true;no.textContent='Volver a la pantalla anterior';no.disabled=false;busy=false;
    no.focus();
   }catch(error){
    message.textContent=error.message;busy=false;yes.disabled=no.disabled=false;
    if(error.status===409){cancel(ticket);yes.hidden=true;no.textContent='Volver y revisar los cambios';try{await ticket.refresh?.();}catch{}}
   }
  };
  try{g.focus();}catch{}
 }
 async function openReport({host,header,onBack,market=null,onChangeLocal}){
  const profile=g.CYD54_ACCESS.profile;if(!['master','market'].includes(profile?.role))return;
  host.innerHTML=(header?header():'')+'<section class="screen cyd68-report"><div class="cyd68-report-head"><div><h1>Impresión de alertas</h1><p>Seguimiento de los cambios de precio vigentes por local.</p></div><button class="btn ghost" data-cyd68-back>Volver</button></div><div class="cyd68-report-filters"><label>Mercado<select data-cyd68-market></select></label><label>Estado<select data-cyd68-filter><option value="all">Todos los locales</option><option value="pending">Sin imprimir</option><option value="partial">Impresión parcial</option><option value="complete">Impresión completa</option></select></label><label>Buscar local<input type="search" data-cyd68-query placeholder="Número o nombre"></label><button class="btn ghost" data-cyd68-refresh>Actualizar</button></div><p data-cyd68-report-status role="status" aria-live="polite">Cargando impresiones…</p><div data-cyd68-report-summary class="cyd68-summary"></div><div class="cyd68-table-wrap"><table><caption>Impresiones confirmadas de las alertas actuales</caption><thead><tr><th>Local</th><th>Estado</th><th>EDLP (Cartel Rojo)</th><th>Campaña (Cartel Amarillo)</th><th>Impresas / Total</th><th>Pendientes</th><th>Última confirmación</th><th>Detalle</th></tr></thead><tbody data-cyd68-report-rows></tbody></table></div><div data-cyd68-report-detail></div><p class="cyd68-note">Verde: no quedan carteles imprimibles pendientes. Rojo: hay carteles disponibles sin confirmar. Los no imprimibles siguen rojos en el detalle como pendientes de corrección y no se suman a los pendientes de impresión. La confirmación la realiza el local después de imprimir. Las impresiones anteriores a esta versión no se consideran confirmadas.</p></section>';
  const root=host.querySelector('.cyd68-report'),marketInput=root.querySelector('[data-cyd68-market]'),filter=root.querySelector('[data-cyd68-filter]'),query=root.querySelector('[data-cyd68-query]'),message=root.querySelector('[data-cyd68-report-status]');let data=null,sequence=0;
  root.querySelector('[data-cyd68-back]').onclick=onBack;const logout=host.querySelector('#changeLocalTop');if(logout&&onChangeLocal)logout.onclick=onChangeLocal;
  const initial=profile.role==='market'?profile.code:market||'all';
  const names=profile.role==='market'?{[profile.code]:profile.marketName}:profile.marketNames;
  marketInput.innerHTML=(profile.role==='master'?'<option value="all">Todos los mercados</option>':'')+Object.entries(names||{}).sort((a,b)=>Number(a[0])-Number(b[0])).map(([code,name])=>'<option value="'+esc(code)+'">'+esc(code)+' · '+esc(name)+'</option>').join('');marketInput.value=initial;
  const state=row=>row.total===0&&!row.unprintable?'empty':row.pending===0?'complete':row.printed===0?'pending':'partial';
  const labels={empty:'Sin alertas',complete:'Sin imprimibles pendientes',pending:'Sin imprimir',partial:'Impresión parcial'};
  function render(){
   const needle=query.value.trim().toLocaleLowerCase('es'),rows=data.rows.filter(r=>(filter.value==='all'||state(r)===filter.value)&&(!needle||[r.local,r.name,r.marketName].join(' ').toLocaleLowerCase('es').includes(needle)));
   root.querySelector('[data-cyd68-report-detail]').innerHTML='';
   const total=data.rows.length,done=data.rows.filter(r=>state(r)==='complete').length,partial=data.rows.filter(r=>state(r)==='partial').length,pending=data.rows.filter(r=>state(r)==='pending').length;
   root.querySelector('[data-cyd68-report-summary]').innerHTML=[['Locales',total],['Completos',done],['Parciales',partial],['Sin imprimir',pending]].map(([label,value])=>'<article><span>'+label+'</span><strong>'+number(value)+'</strong></article>').join('');
   const progress=p=>(p.total?number(p.printed)+' / '+number(p.total):p.unprintable?'Sin imprimibles pendientes':'Sin alertas')+(p.unprintable?'<small>'+number(p.unprintable)+' por corregir</small>':'');
   root.querySelector('[data-cyd68-report-rows]').innerHTML=rows.map(r=>'<tr><th scope="row">'+esc(r.local)+'<small>'+esc(r.name)+'</small><small>'+esc(r.market)+' · '+esc(r.marketName)+'</small></th><td><span class="cyd68-state '+state(r)+'">'+labels[state(r)]+'</span></td><td>'+progress(r.red)+'</td><td>'+progress(r.yellow)+'</td><td>'+number(r.printed)+' / '+number(r.total)+'</td><td>'+number(r.pending)+(r.unprintable?'<small>'+number(r.unprintable)+' por corregir</small>':'')+'</td><td>'+esc(date(r.lastPrintedAt))+'</td><td><button class="btn ghost" data-cyd68-detail="'+esc(r.local)+'">Ver detalle</button></td></tr>').join('')||'<tr><td colspan="8">No hay locales para estos filtros.</td></tr>';
   message.textContent=number(rows.length)+' locales visibles · Actualizado '+date(data.asOf);
  }
  async function load(){const id=++sequence,button=root.querySelector('[data-cyd68-refresh]');button.disabled=true;message.textContent='Actualizando impresiones…';try{const next=await api('/api/alertas/impresiones?'+new URLSearchParams({market:marketInput.value}));if(id!==sequence||!root.isConnected)return;data=next;render();}catch(error){if(id===sequence){data=null;message.textContent=error.message;for(const selector of ['[data-cyd68-report-rows]','[data-cyd68-report-summary]','[data-cyd68-report-detail]'])root.querySelector(selector).innerHTML='';}}finally{if(id===sequence)button.disabled=false;}}
  root.querySelector('[data-cyd68-refresh]').onclick=load;marketInput.onchange=load;filter.onchange=()=>data&&render();query.oninput=()=>data&&render();
  root.addEventListener('click',event=>{
   const info=event.target.closest('[data-cyd75-report-info]');if(info&&data){const p=data.products.find(p=>p.key===info.dataset.cyd75ReportInfo);if(p)g.CYD55_CATEGORIES.information({...p,reportInformation75:true,occamKey:p.key,barcode:p.upc,unit:p.after.regular,offer:p.after.offer,qty:p.after.qty,printability75:{printable:p.printable,reasons:p.reasons},priceChange:{before:p.before,after:p.after,report:p.report,printable:p.printable,reasons:p.reasons,printedAt:data.rows.find(r=>r.local===info.closest('.cyd68-detail')?.dataset.local)?.receipts?.find(r=>r.key===p.key)?.printedAt}},info);return;}
   const button=event.target.closest('[data-cyd68-detail]');if(!button||!data)return;
   const row=data.rows.find(r=>r.local===button.dataset.cyd68Detail);if(!row)return;const receipts=new Map(row.receipts.map(r=>[r.key,r.printedAt])),detail=root.querySelector('[data-cyd68-report-detail]');
   const offer=p=>number(p.qty)+' × $'+number(p.offer);
   detail.innerHTML='<section class="cyd68-detail" data-local="'+esc(row.local)+'"><div class="cyd68-report-head"><h2>Local '+esc(row.local)+' · '+esc(row.name)+'</h2><button class="btn ghost" data-cyd68-close-detail>Cerrar detalle</button></div><div class="cyd68-table-wrap"><table><thead><tr><th>Producto</th><th>Lista</th><th>Cambio</th><th>Impresión</th></tr></thead><tbody>'+data.products.map(p=>'<tr><th scope="row">'+esc(p.name)+'<small>'+(p.item?'Ítem '+esc(p.item):'UPC '+esc(p.upc))+'</small></th><td>'+esc(p.list)+'</td><td>'+offer(p.before)+' → '+offer(p.after)+'</td><td><span class="cyd68-state '+(p.printable===false?'issue':receipts.has(p.key)?'complete':'pending')+'">'+(p.printable===false?'Pendiente de corrección':receipts.has(p.key)?'Impresa':'Pendiente')+'</span><button type="button" class="cyd75-info" data-cyd75-report-info="'+esc(p.key)+'" aria-label="Información de '+esc(p.name)+'"><span aria-hidden="true">i</span></button><small>'+esc(p.printable===false?'No se cuenta como pendiente de impresión':receipts.has(p.key)?date(receipts.get(p.key)):'Sin confirmación')+'</small></td></tr>').join('')+'</tbody></table></div></section>';
   detail.querySelector('[data-cyd68-close-detail]').onclick=()=>{detail.innerHTML='';button.focus();};detail.scrollIntoView?.({block:'start',behavior:'smooth'});
  });
  await load();
 }
 g.CYD68_ALERTS={adopt,change,status,update,begin,cancel,watch,popupScript,openReport};
})(window);
