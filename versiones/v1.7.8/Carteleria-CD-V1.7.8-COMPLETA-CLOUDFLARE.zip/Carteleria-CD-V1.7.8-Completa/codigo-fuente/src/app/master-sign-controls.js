(function(g){
 'use strict';
 const text=v=>String(v??'').trim(),norm=v=>text(v).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toUpperCase();
 const esc=v=>text(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const collator=new Intl.Collator('es-CL',{numeric:true,sensitivity:'base'}),num=v=>Number(v).toLocaleString('es-CL'),money=v=>'$'+num(Math.round(v));
 const key=p=>p.occamKey||'legacy:'+p.campaignId+':'+p.signId;
 function records(catalog){return catalog.map(p=>({key:key(p),raw:p,name:text(p.name),item:text(p.code),upc:text(p.sourceUPC||p.barcode),brand:text(p.brand)||'Sin marca',size:text(p.size),department:text(p.subgrupo)||'Sin departamento',category:[text(p.categoryId),text(p.categoryName)].filter(Boolean).join(' ')||'Sin categoría',list:text(p.occamList||p.campaignName)||'Sin lista',family:g.CYD55_CATEGORIES.classify(p.occamList||p.campaignName),mechanic:p.qty>1?'nx':p.unit>p.offer?'saving':'plain',status:p.promotionBlocked?'blocked':'available',search:norm([p.code,p.barcode,p.sourceUPC,p.sourceProductNbr,p.name,p.brand,p.size,p.subgrupo,p.categoryId,p.categoryName,p.occamList,p.campaignName].join(' '))}));}
 function open(bridge){
  const host=bridge.host;host.innerHTML='<section class="cyd73-signs" aria-label="Carteles y disponibilidad"><div data-cyd73-content></div><div data-cyd73-dialog></div><p data-cyd73-message role="status" aria-live="polite"></p></section>';
  const root=host.querySelector('.cyd73-signs'),content=root.querySelector('[data-cyd73-content]'),dialog=root.querySelector('[data-cyd73-dialog]'),message=root.querySelector('[data-cyd73-message]');
  const state={query:'',list:bridge.initialList||'all',department:'all',category:'all',brand:'all',family:'all',mechanic:'all',status:'all',order:'department',page:0,selected:new Set()};let busy=false,draft=null,lastFocus=null;
  const coverage=()=>bridge.localCount?.()||0,scope=()=>coverage()?'los '+num(coverage())+' locales':'todos los locales';
  const valid=()=>root.isConnected&&host.contains(root),rows=()=>records(bridge.catalog()),note=(value,bad=false)=>{message.textContent=value;message.classList.toggle('error',bad);};
  const filtered=()=>{const tokens=norm(state.query).split(/\s+/).filter(Boolean);return rows().filter(r=>['list','department','category','brand','family','mechanic','status'].every(k=>state[k]==='all'||r[k]===state[k])&&tokens.every(t=>r.search.includes(t))).sort((a,b)=>(state.order==='department'?(collator.compare(a.department,b.department)||collator.compare(a.category,b.category)):0)||collator.compare(a.name,b.name)||collator.compare(a.brand,b.brand)||collator.compare(a.item,b.item)||collator.compare(a.key,b.key));};
  const btn=(label,action,extra='',primary=false)=>'<button type="button" class="cd-btn'+(primary?' primary':'')+'" data-cyd73-action="'+action+'" '+extra+'>'+label+'</button>';
  function select(label,field,values){return '<label>'+label+'<select class="cd-select" data-cyd73-filter="'+field+'" aria-label="'+label+'">'+values.map(([v,l])=>'<option value="'+esc(v)+'" '+(state[field]===v?'selected':'')+'>'+esc(l)+'</option>').join('')+'</select></label>';}
  const options=(all,field,label)=>[['all',label],...[...new Set(all.map(r=>r[field]))].sort(collator.compare).map(v=>[v,v])];
  function render(){
   if(!valid())return;
   const all=rows(),data=filtered(),max=Math.max(0,Math.ceil(data.length/12)-1);state.page=Math.min(state.page,max);const page=data.slice(state.page*12,state.page*12+12),allSelected=data.length&&data.every(p=>state.selected.has(p.key));
   content.innerHTML='<div class="cd-head"><div><h1>Carteles</h1><p>Filtra promociones y controla su disponibilidad para todos los locales.</p></div><div class="cd-actions"><span class="cd-tag" data-cyd73-coverage>Alcance nacional · '+(coverage()?num(coverage())+' locales':'todos los locales')+'</span>'+btn('Actualizar','refresh')+'</div></div>'+
    '<div class="cd-search-row"><label class="cd-search"><span aria-hidden="true">⌕</span><input type="search" data-cyd73-query aria-label="Buscar cartel" placeholder="Buscar por ítem, UPC, descripción, marca o Product Number" value="'+esc(state.query)+'"></label>'+btn('Limpiar filtros','reset')+'</div>'+
    '<div class="cyd73-filters">'+select('Departamento','department',options(all,'department','Todos los departamentos'))+select('Categoría','category',options(all.filter(p=>state.department==='all'||p.department===state.department),'category','Todas las categorías'))+select('Lista','list',options(all,'list','Todas las listas'))+select('Tipo de cartel','family',[['all','Todos los tipos'],['red','EDLP · Cartel Rojo'],['yellow','Campaña · Cartel Amarillo'],['other','Otras listas']])+select('Marca','brand',options(all,'brand','Todas las marcas'))+select('Mecánica','mechanic',[['all','Todas las mecánicas'],['saving','Con ahorro'],['nx','N × $'],['plain','Sin mecánica']])+select('Estado','status',[['all','Todos los estados'],['available','Disponibles'],['blocked','Bloqueados']])+select('Ordenar por','order',[['department','Departamento → Categoría → A–Z'],['name','Producto A–Z']])+'</div>'+
    '<div class="cd-note good"><span aria-hidden="true">✓</span><div>Los carteles bloqueados dejan de estar disponibles para '+scope()+'. El bloqueo se aplica a este cartel de esta lista; puedes desbloquearlo cuando la promoción vuelva.</div></div>'+
    '<div class="cyd73-selection"><label><input type="checkbox" data-cyd73-all '+(allSelected?'checked':'')+' '+(!data.length?'disabled':'')+'>Seleccionar resultados ('+num(data.length)+')</label><span>'+num(state.selected.size)+' seleccionados</span><div>'+btn('Quitar selección','clear',state.selected.size?'':'disabled')+btn('Bloquear seleccionados','block-selected',state.selected.size?'':'disabled',true)+btn('Desbloquear seleccionados','unblock-selected',state.selected.size?'':'disabled')+'</div></div>'+
    '<div class="cd-panel"><div class="cd-panel-head"><div><h2>Carteles de promociones</h2><div class="cd-caption">'+num(data.filter(p=>p.status==='available').length)+' disponibles · '+num(data.filter(p=>p.status==='blocked').length)+' bloqueados en este filtro</div></div><span class="cd-caption">'+num(data.length)+' de '+num(all.length)+' referencias</span></div><div class="cd-table-wrap"><table class="cd-list-table cyd73-table"><thead><tr><th>Producto</th><th>Ítem / UPC</th><th>Departamento / Categoría</th><th>Lista</th><th class="cd-num">Precio</th><th>Estado</th><th>Selección / Acciones</th></tr></thead><tbody>'+page.map(p=>'<tr data-cyd73-row="'+esc(p.key)+'" class="'+(p.status==='blocked'?'cyd73-blocked':'')+'"><td class="cd-promo-name"><strong>'+esc(p.name)+'</strong><span class="cd-sub">'+esc(p.brand)+' · '+esc(p.size)+'</span>'+g.CYD55_CATEGORIES.revisionNote(p.raw)+'</td><td><strong>'+esc(p.item||'Sin ítem')+'</strong><span class="cd-sub">'+esc(p.upc)+'</span></td><td>'+esc(p.department)+'<span class="cd-sub">'+esc(p.category)+'</span></td><td>'+esc(p.list)+'</td><td class="cd-num">'+(p.raw.qty>1?num(p.raw.qty)+' × ':'')+money(p.raw.offer)+'</td><td><span class="cd-tag '+(p.status==='blocked'?'red':'ok')+'">'+(p.status==='blocked'?'Bloqueado':'Disponible')+'</span>'+(p.raw.promotionBlock?'<span class="cd-sub">'+esc(p.raw.promotionBlock.reason)+'</span>':'')+'</td><td><div class="cyd73-row-actions"><label><input type="checkbox" data-cyd73-pick="'+esc(p.key)+'" aria-label="Seleccionar '+esc(p.name)+'" '+(state.selected.has(p.key)?'checked':'')+'>Seleccionar</label>'+btn('Vista previa','preview','data-key="'+esc(p.key)+'"')+btn(p.status==='blocked'?'Desbloquear':'Bloquear',p.status==='blocked'?'unblock':'block','data-key="'+esc(p.key)+'"',p.status!=='blocked')+'</div></td></tr>').join('')+(page.length?'':'<tr><td colspan="7" class="cd-empty">Sin coincidencias. Prueba otros filtros.</td></tr>')+'</tbody></table></div><div class="cd-pager"><span>Página '+num(state.page+1)+' de '+num(max+1)+' · 12 productos por página</span><div class="cd-actions">'+btn('Anterior','previous',!state.page?'disabled':'')+btn('Siguiente','next',state.page===max?'disabled':'')+'</div></div></div>';
   root.setAttribute('aria-busy',String(busy));dialog.querySelectorAll('button,input,select').forEach(e=>e.disabled=busy);if(busy)root.querySelectorAll('button,input,select').forEach(e=>e.disabled=true);
  }
  function close(){draft=null;dialog.innerHTML='';if(lastFocus?.isConnected)lastFocus.focus();}
  function confirm(keys,blocked,focus){
   const products=rows().filter(p=>keys.includes(p.key)&&(p.status==='blocked')!==blocked);if(!products.length){note(blocked?'Los carteles seleccionados ya están bloqueados.':'Los carteles seleccionados ya están disponibles.');return;}
   lastFocus=focus;draft={keys:products.map(p=>p.key),blocked,revision:bridge.revision(),id:g.crypto.randomUUID()};
   dialog.innerHTML='<div class="cd-overlay"><section class="cd-dialog" role="dialog" aria-modal="true" aria-labelledby="cyd73-title"><div class="cd-panel-head"><h2 id="cyd73-title">'+(blocked?'Bloquear':'Desbloquear')+' '+num(products.length)+' cartel(es)</h2>'+btn('Cerrar','cancel')+'</div><div class="cd-dialog-body"><p>'+(blocked?'Dejarán de estar disponibles para '+scope()+', incluidos los carteles que ya estén en una cola de impresión.':'Volverán a estar disponibles para '+scope()+'.')+'</p><ul class="cyd73-summary">'+products.slice(0,5).map(p=>'<li>'+esc(p.name)+' · '+esc(p.list)+'</li>').join('')+(products.length>5?'<li>Y '+num(products.length-5)+' más.</li>':'')+'</ul>'+(blocked?'<label class="cyd73-reason">Motivo del bloqueo<input data-cyd73-reason value="Caída de promoción" maxlength="200" required></label>':'')+'</div><div class="cd-pager"><span>Alcance: '+scope()+'</span><div class="cd-actions">'+btn('Cancelar','cancel')+btn(blocked?'Bloquear para todos':'Desbloquear para todos','apply','',true)+'</div></div></section></div>';
   dialog.querySelector('.cd-dialog')?.scrollIntoView({block:'center',behavior:'auto'});
   (dialog.querySelector('[data-cyd73-reason]')||dialog.querySelector('button'))?.focus();
  }
  root.addEventListener('input',event=>{const el=event.target;if(!el.matches('[data-cyd73-query]')||busy)return;const cursor=el.selectionStart;state.query=el.value;state.page=0;state.selected.clear();render();const input=root.querySelector('[data-cyd73-query]');input.focus();if(cursor!==null)input.setSelectionRange(cursor,cursor);});
  root.addEventListener('change',event=>{
   if(busy)return;const el=event.target;
   if(el.dataset.cyd73Filter){state[el.dataset.cyd73Filter]=el.value;if(el.dataset.cyd73Filter==='department')state.category='all';state.page=0;state.selected.clear();}
   else if(el.hasAttribute('data-cyd73-all')){state.selected=el.checked?new Set(filtered().map(p=>p.key)):new Set();}
   else if(el.dataset.cyd73Pick){el.checked?state.selected.add(el.dataset.cyd73Pick):state.selected.delete(el.dataset.cyd73Pick);}
   else return;render();
  });
  root.addEventListener('keydown',event=>{if(event.key==='Escape'&&!busy)close();});
  root.addEventListener('click',async event=>{
   const b=event.target.closest('[data-cyd73-action]');if(!b||b.disabled||busy)return;const action=b.dataset.cyd73Action;
   try{
    if(action==='cancel'){close();return;}
    if(action==='preview'){bridge.preview(b.dataset.key);return;}
    if(action==='reset'){for(const k of ['department','category','list','brand','family','mechanic','status'])state[k]='all';state.query='';state.order='department';state.page=0;state.selected.clear();note('');render();return;}
    if(action==='clear'){state.selected.clear();render();return;}
    if(action==='previous'||action==='next'){state.page+=action==='previous'?-1:1;render();return;}
    if(action==='block'||action==='unblock'){confirm([b.dataset.key],action==='block',b);return;}
    if(action==='block-selected'||action==='unblock-selected'){confirm([...state.selected],action==='block-selected',b);return;}
    if(action==='refresh'){busy=true;render();await bridge.refresh();state.selected.clear();note('Lista actualizada.');busy=false;render();return;}
    if(action==='apply'&&draft){
     const request={...draft,reason:draft.blocked?text(dialog.querySelector('[data-cyd73-reason]').value):''};if(request.blocked&&!request.reason){dialog.querySelector('[data-cyd73-reason]').focus();return;}
     busy=true;render();const result=await bridge.api('/api/master/carteles/disponibilidad',{method:'POST',body:request});
     await bridge.refresh();state.selected.clear();close();busy=false;render();note(num(result.changed)+' cartel(es) '+(request.blocked?'bloqueados':'desbloqueados')+' para '+scope()+'.');
    }
   }catch(error){busy=false;if(error.status===409){await bridge.refresh().catch(()=>{});close();}render();note(error.message,true);bridge.toast?.(error.message);}
  });
  render();
 }
 g.CYD73_PROMOTIONS={open,records};
})(window);
