/* Períodos de actividad y selección de días independientes. */
(function(g){
 'use strict';
 const esc=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const at=day=>new Date(day+'T12:00:00Z');
 const valid=day=>typeof day==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(day)&&Number.isFinite(at(day).getTime())&&at(day).toISOString().slice(0,10)===day;
 function today(){const parts=Object.fromEntries(new Intl.DateTimeFormat('en-GB',{timeZone:'America/Santiago',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(new Date()).map(part=>[part.type,part.value]));return parts.year+'-'+parts.month+'-'+parts.day;}
 function range(period,selected=[],end=today()){
  if(period==='days'){
   const days=[...new Set(selected)].sort();
   if(!days.length||days.length>366||days.some(day=>!valid(day)||day>end))throw new Error('Selecciona entre 1 y 366 días válidos, hasta hoy.');
   return {from:days[0],to:days[days.length-1],days:days.join(',')};
  }
  if(!['day','week','month'].includes(period))throw new Error('Período no reconocido.');
  const start=at(end);start.setUTCDate(start.getUTCDate()-(period==='month'?29:period==='week'?6:0));
  return {from:start.toISOString().slice(0,10),to:end};
 }
 const dateLabel=day=>new Intl.DateTimeFormat('es-CL',{timeZone:'UTC',day:'2-digit',month:'2-digit',year:'numeric'}).format(at(day));
 function describe(period,selected=[]){
  const query=range(period,selected);
  if(period==='days')return selected.length+' día'+(selected.length===1?'':'s')+' seleccionado'+(selected.length===1?'':'s')+' · '+[...selected].sort().slice(0,3).map(dateLabel).join(' · ')+(selected.length>3?' · y '+(selected.length-3)+' más':'');
  return (period==='day'?'Hoy':period==='month'?'Último mes · últimos 30 días':'Últimos 7 días')+' · '+dateLabel(query.from)+(query.from===query.to?'':' al '+dateLabel(query.to));
 }
 let active=null;
 function chooseDays(initial=[]){
  if(active)active();
  const end=today(),origin=document.activeElement,selected=new Set(initial.filter(day=>valid(day)&&day<=end));
  if(!selected.size)selected.add(end);
  let month=[...selected].sort().at(-1).slice(0,7),done=false;
  const overlay=document.createElement('div');overlay.className='cyd65-date-overlay';
  overlay.innerHTML='<section class="cyd65-date-panel" role="dialog" aria-modal="true" aria-labelledby="cyd65DateTitle"><header><div><h2 id="cyd65DateTitle">Elegir días de actividad</h2><p>Selecciona uno o varios días. Puedes elegir fechas separadas y cambiar de mes.</p></div><button type="button" class="btn ghost" data-cyd65-cancel>Cancelar</button></header><div class="cyd65-calendar-nav"><button type="button" data-cyd65-prev aria-label="Mes anterior">‹</button><label>Mes<input type="month" data-cyd65-month max="'+end.slice(0,7)+'"></label><button type="button" data-cyd65-next aria-label="Mes siguiente">›</button></div><h3 data-cyd65-month-title></h3><div class="cyd65-weekdays" aria-hidden="true">'+['Lun','Mar','Mié','Jue','Vie','Sáb','Dom'].map(day=>'<span>'+day+'</span>').join('')+'</div><div class="cyd65-days" data-cyd65-grid></div><div class="cyd65-date-selection"><strong data-cyd65-count></strong><button type="button" data-cyd65-clear>Quitar selección</button><div data-cyd65-selected></div></div><p role="status" data-cyd65-date-message></p><footer><button type="button" class="btn primary" data-cyd65-apply>Consultar días seleccionados</button></footer></section>';
  document.body.appendChild(overlay);
  return new Promise(resolve=>{
   function close(value=null){if(done)return;done=true;overlay.remove();if(active===cancel)active=null;origin?.focus();resolve(value);}
   const cancel=()=>close();active=cancel;
   function render(){
    const date=at(month+'-01'),last=at(month+'-01');last.setUTCMonth(last.getUTCMonth()+1);last.setUTCDate(0);
    overlay.querySelector('[data-cyd65-month]').value=month;
    overlay.querySelector('[data-cyd65-month-title]').textContent=new Intl.DateTimeFormat('es-CL',{timeZone:'UTC',month:'long',year:'numeric'}).format(date);
    overlay.querySelector('[data-cyd65-next]').disabled=month>=end.slice(0,7);
    const padding=(date.getUTCDay()+6)%7,cells=Array.from({length:padding},()=>'<span></span>');
    for(let day=1;day<=last.getUTCDate();day++){
     const key=month+'-'+String(day).padStart(2,'0');
     cells.push('<button type="button" data-cyd65-day="'+key+'" aria-label="'+esc(dateLabel(key))+'" aria-pressed="'+selected.has(key)+'" '+(key>end?'disabled':'')+'>'+day+'</button>');
    }
    overlay.querySelector('[data-cyd65-grid]').innerHTML=cells.join('');
    overlay.querySelector('[data-cyd65-count]').textContent=selected.size+' día'+(selected.size===1?'':'s')+' seleccionado'+(selected.size===1?'':'s');
    overlay.querySelector('[data-cyd65-selected]').innerHTML=[...selected].sort().map(day=>'<button type="button" data-cyd65-remove="'+day+'" aria-label="Quitar '+esc(dateLabel(day))+'">'+esc(dateLabel(day))+' ×</button>').join('');
    overlay.querySelector('[data-cyd65-clear]').disabled=!selected.size;overlay.querySelector('[data-cyd65-apply]').disabled=!selected.size;
   }
   overlay.addEventListener('click',event=>{
    const button=event.target.closest('button');if(!button||button.disabled)return;
    const day=button.dataset.cyd65Day,remove=button.dataset.cyd65Remove;
    overlay.querySelector('[data-cyd65-date-message]').textContent='';
    if(button.hasAttribute('data-cyd65-cancel'))return close();
    if(button.hasAttribute('data-cyd65-apply'))return close([...selected].sort());
    if(day){if(selected.has(day))selected.delete(day);else if(selected.size<366)selected.add(day);else overlay.querySelector('[data-cyd65-date-message]').textContent='Puedes consultar hasta 366 días a la vez.';}
    if(remove)selected.delete(remove);
    if(button.hasAttribute('data-cyd65-clear'))selected.clear();
    if(button.hasAttribute('data-cyd65-prev')||button.hasAttribute('data-cyd65-next')){const date=at(month+'-01');date.setUTCMonth(date.getUTCMonth()+(button.hasAttribute('data-cyd65-prev')?-1:1));month=date.toISOString().slice(0,7);}
    render();
    if(day)overlay.querySelector('[data-cyd65-day="'+day+'"]').focus();
   });
   overlay.querySelector('[data-cyd65-month]').addEventListener('change',event=>{
    const value=event.target.value;
    if(/^\d{4}-\d{2}$/.test(value)&&valid(value+'-01')&&value<=end.slice(0,7))month=value;
    render();
   });
   overlay.addEventListener('keydown',event=>{
    if(event.key==='Escape'){event.preventDefault();event.stopPropagation();close();}
    if(event.key==='Tab'){
     const controls=[...overlay.querySelectorAll('button:not(:disabled),input:not(:disabled)')],first=controls[0],last=controls.at(-1);
     if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus();}
     else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus();}
    }
   });
   render();overlay.querySelector('[data-cyd65-cancel]').focus();
  });
 }
 g.CYD65_PERIOD={today,range,describe,chooseDays};
})(window);
