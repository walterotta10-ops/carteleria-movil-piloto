/* Cambios de precios publicados por Administrador. No requiere servicios de IA. */
(function(g){
  'use strict';
  const esc=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const norm=value=>String(value??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toUpperCase().replace(/[^A-Z0-9]/g,'');
  const id=value=>String(value??'').trim().replace(/^0+(?=\d)/,'');
  const money=value=>'$'+Number(value).toLocaleString('es-CL');
  const price=value=>value.qty+' × '+money(value.offer);
  function fromRows(matrix){
    if(!Array.isArray(matrix)||matrix.length<2)throw new Error('El archivo debe contener encabezados y al menos un cambio.');
    const headers=matrix[0].map(norm);
    const column=(...names)=>headers.findIndex(value=>names.map(norm).includes(value));
    const item=column('Ítem','Código ítem'),upc=column('UPC','Código de barras','EAN','EAN-13');
    const qty=column('Cantidad','Q'),offer=column('Precio oferta','Precio promoción','Nuevo precio','Precio nuevo');
    const list=column('Lista');
    if(item<0&&upc<0||qty<0||offer<0)throw new Error('Faltan las columnas Ítem o UPC, Cantidad y Precio oferta.');
    const rows=matrix.slice(1).filter(row=>Array.isArray(row)&&row.some(value=>String(value??'').trim()));
    if(!rows.length||rows.length>500)throw new Error('Carga entre 1 y 500 cambios por archivo.');
    return rows.map(row=>({item:item<0?'':String(row[item]??'').trim(),upc:upc<0?'':String(row[upc]??'').trim(),qty:row[qty],offer:row[offer],list:list<0?'':String(row[list]??'').trim()}));
  }
  function open(options){
    const {host,api,refresh,catalog,revision}=options;
    host.innerHTML=`<section class="cyd63-prices" aria-labelledby="cyd63Title">
      <header class="cd-pagehead"><div><p class="cyd63-eyebrow">Administración de promociones</p><h1 id="cyd63Title">Cambios de precios detectados</h1><p>Actualiza el precio y la cantidad de una promoción para todos los locales.</p></div></header>
      <p class="cyd63-status" data-price-status role="status" aria-live="polite">Cargando precios vigentes…</p>
      <div class="cyd63-columns">
        <section class="cd-panel cyd63-card"><h2>Modificar un producto</h2>
          <form data-price-search><label for="cyd63Identifier">Ítem o UPC</label><div class="cyd63-search"><input id="cyd63Identifier" name="identifier" inputmode="numeric" pattern="[0-9]+" maxlength="20" placeholder="Ej. 262035" required><button class="cd-btn" type="submit">Buscar producto</button></div></form>
          <div data-price-product></div>
        </section>
        <section class="cd-panel cyd63-card"><h2>Subir varios cambios</h2><p>Usa un archivo Excel o CSV con las columnas <strong>Ítem o UPC, Cantidad y Precio oferta</strong>. Agrega <strong>Lista</strong> cuando el producto participe en más de una.</p>
          <form data-price-upload><label for="cyd63File">Archivo de cambios · hasta 500 productos</label><input id="cyd63File" type="file" accept=".xlsx,.csv" required><div class="cyd63-actions"><button class="cd-btn" type="button" data-price-template>Descargar plantilla</button><button class="cd-btn primary" type="submit">Revisar archivo</button></div></form>
          <p class="cyd63-help">El precio oferta corresponde al total de la cantidad indicada. Para 2 × $3.000, ingresa cantidad 2 y precio oferta 3000.</p>
        </section>
      </div>
      <p class="cyd63-note">Revisa el cambio antes de publicarlo. Se conserva el precio “antes” de OCCAM y se genera la alerta de modificación. Una carga oficial posterior reemplaza las correcciones de los productos incluidos.</p>
      <div data-price-review></div>
      <section class="cd-panel cyd63-card"><h2>Historial de cambios publicados</h2><div data-price-history></div></section>
      <div data-price-detail></div>
    </section>`;
    const panel=host.querySelector('.cyd63-prices'),productHost=panel.querySelector('[data-price-product]');
    const reviewHost=panel.querySelector('[data-price-review]'),detailHost=panel.querySelector('[data-price-detail]');
    const status=panel.querySelector('[data-price-status]');
    let busy=false,matches=[],searchRevision=null,draft=null;
    const alive=()=>host.contains(panel);
    function message(text,error=false){if(!alive())return;status.textContent=text;status.classList.toggle('is-error',error);}
    function setBusy(value){busy=value;panel.setAttribute('aria-busy',String(value));panel.querySelectorAll('button,input,select').forEach(control=>{control.disabled=value;});}
    function invalidate(){draft=null;reviewHost.innerHTML='';}
    function history(){
      if(!alive())return;
      const rows=(options.history?.()||[]).filter(row=>row.kind==='correction');
      panel.querySelector('[data-price-history]').innerHTML=rows.length?'<div class="cyd63-table"><table><thead><tr><th>Origen</th><th>Fecha</th><th>Detalle</th></tr></thead><tbody>'+rows.map(row=>'<tr><td>'+esc(row.filename)+'</td><td>'+esc(new Date(row.committed_at).toLocaleString('es-CL'))+'</td><td><button class="cd-btn" data-price-history-id="'+esc(row.id)+'" type="button">Ver cambios</button></td></tr>').join('')+'</tbody></table></div>':'<p class="cyd63-help">Los cambios que publiques desde este recuadro aparecerán aquí.</p>';
    }
    function productFields(){
      const selected=productHost.querySelector('[data-price-list]')?.value||matches[0]?.occamKey;
      const product=matches.find(row=>row.occamKey===selected);
      const target=productHost.querySelector('[data-price-fields]');
      if(!product||!target)return;
      target.innerHTML='<div class="cyd63-current"><strong>'+esc(product.name)+'</strong><span>'+esc([product.brand,product.size].filter(Boolean).join(' · '))+'</span><span>'+(product.code?'Ítem '+esc(product.code)+' · ':'')+'UPC '+esc(product.barcode||product.sourceUPC)+'</span><span>Vigente <b>'+price(product)+'</b></span></div><div class="cyd63-new"><label for="cyd63Qty">Nueva cantidad<input id="cyd63Qty" name="qty" type="number" min="1" max="100" step="1" value="'+product.qty+'" required></label><label for="cyd63Offer">Nuevo precio oferta total<input id="cyd63Offer" name="offer" inputmode="numeric" placeholder="Ej. 2050" required></label></div><button class="cd-btn primary" type="submit">Revisar cambio</button>';
    }
    function showProducts(){
      productHost.innerHTML='<form class="cyd63-product-form" data-price-change><label for="cyd63List">Lista a modificar</label><select id="cyd63List" data-price-list>'+matches.map(product=>'<option value="'+esc(product.occamKey)+'">'+esc(product.occamList)+' · '+price(product)+'</option>').join('')+'</select><div data-price-fields></div></form>';
      productFields();
    }
    function changeTable(report){
      return '<div class="cyd63-table"><table><thead><tr><th>Producto / lista</th><th>Precio vigente anterior</th><th>Nuevo precio oferta</th></tr></thead><tbody>'+report.changes.map(change=>'<tr><td><strong>'+esc(change.name)+'</strong><span>'+(change.item?'Ítem '+esc(change.item):'UPC '+esc(change.upc))+' · '+esc(change.list)+'</span></td><td>'+price(change.before)+'</td><td class="cyd63-after">'+price(change.after)+'</td></tr>').join('')+'</tbody></table></div>';
    }
    async function review(changes,filename,baseRevision){
      const result=await api('/api/master/prices/preview',{method:'POST',body:{revision:baseRevision,changes,filename}});
      if(!alive())return;
      draft=result;
      reviewHost.innerHTML='<section class="cd-panel cyd63-card cyd63-review" aria-labelledby="cyd63ReviewTitle"><h2 id="cyd63ReviewTitle" tabindex="-1">Revisar antes de publicar</h2><p>'+result.report.changed+' cambio(s) para todos los locales. '+(result.report.unchanged?result.report.unchanged+' sin cambios. ':'')+(result.report.duplicates?result.report.duplicates+' duplicado(s) omitidos.':'')+'</p>'+changeTable(result.report)+'<div class="cyd63-actions"><button class="cd-btn" type="button" data-price-cancel>Cancelar revisión</button><button class="cd-btn primary" type="button" data-price-publish>Confirmar y publicar cambios</button></div></section>';
      message('Revisión lista. Los precios todavía no se han modificado.');
      panel.querySelector('#cyd63ReviewTitle').focus();
    }
    panel.addEventListener('input',event=>{if(event.target.matches('input')){invalidate();if(event.target.id==='cyd63Identifier'){matches=[];searchRevision=null;productHost.innerHTML='';}}});
    panel.addEventListener('change',event=>{
      if(event.target.matches('input,select'))invalidate();
      if(event.target.matches('[data-price-list]'))productFields();
    });
    panel.addEventListener('submit',async event=>{
      const form=event.target;
      if(!form.matches('[data-price-search],[data-price-change],[data-price-upload]'))return;
      event.preventDefault();if(busy)return;
      const identifier=panel.querySelector('#cyd63Identifier').value.trim();
      const file=panel.querySelector('#cyd63File').files[0];
      const selected=productHost.querySelector('[data-price-list]')?.value;
      const qty=productHost.querySelector('[name="qty"]')?.value,offer=productHost.querySelector('[name="offer"]')?.value;
      invalidate();setBusy(true);
      try{
        if(form.matches('[data-price-search]')){
          message('Buscando la promoción vigente…');await refresh();if(!alive())return;
          searchRevision=revision();
          matches=catalog().filter(product=>product.occamKey&&[product.code,product.barcode,product.sourceUPC].some(value=>value&&id(value)===id(identifier)));
          if(!matches.length)throw new Error('No se encontró ese ítem o UPC en las promociones vigentes.');
          showProducts();message(matches.length>1?'El producto aparece en varias listas. Selecciona la que deseas modificar.':'Producto encontrado. Ingresa la nueva cantidad y el precio oferta.');
        }else if(form.matches('[data-price-change]')){
          if(!selected||!matches.some(product=>product.occamKey===selected))throw new Error('Busca y selecciona el producto antes de modificarlo.');
          message('Revisando el cambio…');
          await review([{identifier,key:selected,qty,offer}],'Cambio de precio · '+identifier,searchRevision);
        }else{
          message('Leyendo y revisando el archivo…');
          const changes=fromRows(await g.CYD_XLSX.read(file));
          await refresh();if(!alive())return;
          await review(changes,file.name,revision());
        }
      }catch(error){message(error.message,true);}finally{setBusy(false);}
    });
    panel.addEventListener('click',async event=>{
      const button=event.target.closest('button');if(!button||busy)return;
      if(button.hasAttribute('data-price-template')){
        const url=URL.createObjectURL(new Blob(['\uFEFFÍtem;UPC;Cantidad;Precio oferta;Lista\r\n'],{type:'text/csv;charset=utf-8'}));
        const anchor=document.createElement('a');anchor.href=url;anchor.download='Plantilla-cambios-de-precios.csv';anchor.click();setTimeout(()=>URL.revokeObjectURL(url),1000);return;
      }
      if(button.hasAttribute('data-price-cancel')){invalidate();message('Revisión cancelada. No se modificaron los precios.');return;}
      if(button.hasAttribute('data-price-close-detail')){detailHost.innerHTML='';return;}
      if(button.hasAttribute('data-price-history-id')){
        setBusy(true);
        try{
          const result=await api('/api/master/prices/detail?id='+encodeURIComponent(button.dataset.priceHistoryId));
          if(alive()){detailHost.innerHTML='<section class="cd-panel cyd63-card" aria-labelledby="cyd63DetailTitle"><h2 id="cyd63DetailTitle" tabindex="-1">Cambios publicados · '+esc(new Date(result.committedAt).toLocaleString('es-CL'))+'</h2>'+changeTable(result.report)+'<button class="cd-btn" type="button" data-price-close-detail>Cerrar detalle</button></section>';panel.querySelector('#cyd63DetailTitle').focus();}
        }catch(error){message(error.message,true);}finally{setBusy(false);}return;
      }
      if(!button.hasAttribute('data-price-publish')||!draft)return;
      setBusy(true);message('Publicando los cambios…');
      try{
        const applied=await api('/api/master/imports/commit',{method:'POST',body:{id:draft.id,revision:draft.revision}});
        invalidate();productHost.innerHTML='';matches=[];searchRevision=null;
        try{await refresh();history();options.onApplied?.(applied);message('Cambios publicados para todos los locales. La campana muestra el precio anterior y el nuevo.');}
        catch{message('Los cambios quedaron publicados. Recarga la página para ver el catálogo actualizado.');}
      }catch(error){message(error.message,true);}finally{setBusy(false);}
    });
    setBusy(true);
    refresh().then(()=>{if(alive()){history();message('Busca un producto o sube un archivo de cambios.');}}).catch(error=>message(error.message,true)).finally(()=>setBusy(false));
  }
  g.CYD63_PRICES={open,fromRows};
})(window);
