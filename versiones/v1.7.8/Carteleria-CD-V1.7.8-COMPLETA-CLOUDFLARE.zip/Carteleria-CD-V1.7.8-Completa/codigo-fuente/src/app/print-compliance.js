(function(g){
 'use strict';
 const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const n=v=>Number(v||0).toLocaleString('es-CL');
 const pct=(printed,total)=>total?Math.round(1000*printed/total)/10:0;
 const percent=(printed,total)=>total?pct(printed,total).toLocaleString('es-CL')+' %':'—';
 const bar=(printed,total)=>'<div class="cyd81-track"><div class="cyd81-bar" style="width:'+pct(printed,total)+'%"></div></div>';
 const money=v=>'$'+n(v);
 async function api(path){const res=await fetch((g.CYD_API_BASE||location.origin)+path,{cache:'no-store'});const data=await res.json();if(!res.ok||!data.ok)throw new Error(data.error||'No se pudo consultar la impresión.');return data;}
 function open({host,onBack=()=>{}}={}){
  if(!host)return;
  const profile=g.CYD54_ACCESS?.profile;
  const state={level:profile?.role==='market'?'stores':'markets',market:profile?.role==='market'?profile.code:null,local:null,summary:null,detail:null,filter:'pending',family:'all',search:'',page:0,loading:true,error:''};
  host.innerHTML='<section class="cyd81"><style>\
   .cyd81{font:14px/1.45 Arial,Helvetica,sans-serif;min-width:0;color:inherit}.cyd81 *{box-sizing:border-box}\
   .cyd81-head{display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;margin:4px 0 18px}\
   .cyd81-head h1{font-size:26px;margin:0;letter-spacing:-.5px}.cyd81-muted{color:#687386}.cyd81-small{font-size:12px}\
   .cyd81-buttons{display:flex;align-items:center;gap:8px;flex-wrap:wrap}.cyd81 button{cursor:pointer;border:1px solid #d9dee7;background:#fff;border-radius:8px;padding:9px 12px;color:#27313d;font:inherit}\
   .cyd81 button:hover{background:#f4f6fa}.cyd81 button:disabled{opacity:.5;cursor:default}\
   .cyd81 button.cyd81-primary{background:#e61e36;color:#fff;border-color:#e61e36}.cyd81 a{color:#dc2037}\
   .cyd81-stats{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin:14px 0 18px}\
   .cyd81-stat{border:1px solid #dce1ea;border-radius:11px;background:#fff;padding:15px}.cyd81-stat strong{display:block;font-size:25px;color:#172034;margin-top:5px}\
   .cyd81-panel{border:1px solid #dde2e9;border-radius:11px;background:#fff;overflow:hidden;margin:16px 0}.cyd81-panel h2{font-size:17px;margin:0;padding:18px}\
   .cyd81-table{overflow:auto}.cyd81 table{width:100%;border-collapse:collapse;font-size:13px;white-space:nowrap}.cyd81 th{padding:12px 14px;background:#f5f6f9;text-align:left;color:#536073;font-size:12px}.cyd81 td{padding:12px 14px;border-top:1px solid #e8ecf2}.cyd81 .cyd81-num{text-align:right;font-variant-numeric:tabular-nums}.cyd81 td.cyd81-desc{white-space:normal;min-width:190px}.cyd81 td.cyd81-desc strong{display:block}\
   .cyd81-track{height:7px;background:#eceff3;border-radius:5px;overflow:hidden;width:100%;margin-top:5px}.cyd81-bar{height:100%;background:#128b61;border-radius:5px}\
   .cyd81-status{background:#fff5df;color:#76500c;padding:11px 13px;border-radius:8px;margin:12px 0}.cyd81-controls{display:flex;gap:10px;flex-wrap:wrap;margin:10px 0}.cyd81-controls select,.cyd81-controls input{font:inherit;min-height:40px;padding:8px;border:1px solid #dce2ea;border-radius:7px;background:#fff}\
   .cyd81-tag{background:#edf7f0;color:#167553;border-radius:5px;padding:3px 7px;font-size:11px}.cyd81-pending{background:#fff1f2;color:#c62637}.cyd81-footer{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:12px 16px}\
   @media(max-width:760px){.cyd81-stats{grid-template-columns:repeat(2,minmax(0,1fr))}.cyd81-head h1{font-size:22px}.cyd81-panel{margin:12px 0}}\
  </style><div data-cyd81-page><p>Consultando cumplimiento de impresión…</p></div></section>';
  const root=host.querySelector('.cyd81'),page=root.querySelector('[data-cyd81-page]');
  const isActive=()=>root.isConnected;
  const row=(label,value,sub='')=>'<div class="cyd81-stat"><span class="cyd81-muted cyd81-small">'+label+'</span><strong>'+value+'</strong><span class="cyd81-muted cyd81-small">'+sub+'</span></div>';
  const stats=t=>'<div class="cyd81-stats">'+row('Cumplimiento',percent(t.printed,t.total),'De la lista vigente')+row('Carteles exigidos',n(t.total))+row('Impresos confirmados',n(t.printed))+row('Pendientes',n(t.pending),t.excluded?n(t.excluded)+' no imprimibles excluidos':'')+'</div>';
  const headers=()=>'<div class="cyd81-head"><div><h1>% de impresión de cartelería</h1><div class="cyd81-muted">Mercados → Locales → Carteles sin imprimir</div></div><div class="cyd81-buttons">'+(state.level!=='markets'?'<button data-cyd81-back>← Volver</button>':'')+'<button data-cyd81-refresh>Actualizar</button></div></div>';
  const note=()=>'<div class="cyd81-status" role="note">Medición iniciada: '+esc(state.summary?.started?new Date(state.summary.started).toLocaleString('es-CL',{timeZone:'America/Santiago'}):'desde la activación')+'. Solo se cuentan carteles confirmados desde esta versión. Las reimpresiones aumentan el contador de cada cartel, pero no el porcentaje. Los envíos sin confirmación no suman.</div>';
  const line=(code,name,total,printed,pending,action,extra='')=>'<tr><td><strong>'+esc(name)+'</strong><div class="cyd81-small cyd81-muted">'+esc(code)+'</div></td><td class="cyd81-num">'+percent(printed,total)+bar(printed,total)+'</td><td class="cyd81-num">'+n(total)+'</td><td class="cyd81-num">'+n(printed)+'</td><td class="cyd81-num">'+n(pending)+'</td><td><button data-cyd81-'+action+'="'+esc(code)+'">'+extra+'Ver detalle ›</button></td></tr>';
  const table=(heading,contents,empty='Sin datos')=>'<div class="cyd81-panel"><h2>'+heading+'</h2><div class="cyd81-table"><table><thead><tr><th>Mercado / local</th><th class="cyd81-num">Adherencia</th><th class="cyd81-num">Exigidos</th><th class="cyd81-num">Impresos</th><th class="cyd81-num">Pendientes</th><th></th></tr></thead><tbody>'+ (contents||'<tr><td colspan="6">'+empty+'</td></tr>')+'</tbody></table></div></div>';
  function paint(){
   if(!isActive())return;
   if(state.loading){page.innerHTML=headers()+'<p>Consultando la base vigente…</p>';return;}
   if(state.error){page.innerHTML=headers()+'<div class="cyd81-status" role="alert">'+esc(state.error)+'</div>';return;}
   const all=state.summary;if(!all){page.innerHTML='<p>No se encontraron datos.</p>';return;}
   if(state.level==='markets'){
    const totals=all.markets.reduce((a,r)=>({total:a.total+r.total,printed:a.printed+r.printed,pending:a.pending+r.pending,excluded:a.excluded+r.excluded}),{total:0,printed:0,pending:0,excluded:0});
    page.innerHTML=headers()+note()+stats(totals)+table('Adherencia por mercado',all.markets.map(m=>line(m.market,m.name+' · '+m.localCount+' locales',m.total,m.printed,m.pending,'market')).join(''));
   }else if(state.level==='stores'){
    const rows=all.rows.filter(r=>r.market===state.market), totals=rows.reduce((a,r)=>({total:a.total+r.total,printed:a.printed+r.printed,pending:a.pending+r.pending,excluded:a.excluded+r.excluded}),{total:0,printed:0,pending:0,excluded:0});
    const name=all.markets.find(m=>m.market===state.market)?.name||state.market;
    page.innerHTML=headers()+note()+'<h2>'+esc(name)+' · Mercado '+esc(state.market)+'</h2>'+stats(totals)+table('Locales del mercado',rows.map(r=>line(r.local,r.name+' · Local '+r.local,r.total,r.printed,r.pending,'local')).join(''));
   }else{
    const d=state.detail;if(!d){page.innerHTML=headers()+'<p>Cargando productos…</p>';return;}
    const records=d.products.filter(p=>p.printable),tot={total:records.length,printed:records.filter(p=>p.printedAt).length,pending:records.filter(p=>!p.printedAt).length,excluded:d.products.length-records.length};
    let filtered=d.products.filter(p=>(state.family==='all'||p.family===state.family)&&(state.filter==='all'||state.filter==='pending'&&!p.printedAt&&p.printable||state.filter==='printed'&&p.printedAt||state.filter==='blocked'&&!p.printable));
    const query=state.search.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();if(query)filtered=filtered.filter(p=>[p.name,p.item,p.upc,p.list].join(' ').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().includes(query));
    const pages=Math.max(1,Math.ceil(filtered.length/50));state.page=Math.min(state.page,pages-1);
    const view=filtered.slice(state.page*50,state.page*50+50);
    const items=view.map(p=>'<tr><td>'+esc(p.item||'—')+'<div class="cyd81-small cyd81-muted">'+esc(p.upc||'')+'</div></td><td class="cyd81-desc"><strong>'+esc(p.name)+'</strong></td><td>'+esc(p.list)+'</td><td class="cyd81-num">'+(p.qty>1?p.qty+' × ':'')+money(p.price)+'</td><td>'+(p.printedAt?'<span class="cyd81-tag">Impreso · '+n(p.printCount||1)+'</span>':p.printable?'<span class="cyd81-tag cyd81-pending">Pendiente</span>':'<span class="cyd81-tag cyd81-pending">Por corregir</span>')+'</td></tr>').join('');
    page.innerHTML=headers()+note()+'<h2>Local '+esc(d.local)+' · '+esc(d.name)+'</h2>'+stats(tot)+'<div class="cyd81-controls"><select data-cyd81-family aria-label="Tipo de cartel"><option value="all">EDLP y Lista Promocional</option><option value="red" '+(state.family==='red'?'selected':'')+'>EDLP · cartel rojo</option><option value="yellow" '+(state.family==='yellow'?'selected':'')+'>Lista Promocional · cartel amarillo</option></select><select data-cyd81-filter aria-label="Estado"><option value="pending">Pendientes</option><option value="printed" '+(state.filter==='printed'?'selected':'')+'>Impresos</option><option value="blocked" '+(state.filter==='blocked'?'selected':'')+'>Por corregir</option><option value="all" '+(state.filter==='all'?'selected':'')+'>Todos</option></select><input data-cyd81-search type="search" placeholder="Buscar ítem, descripción o barra" value="'+esc(state.search)+'"></div><div class="cyd81-panel"><h2>Carteles · '+n(filtered.length)+' resultados</h2><div class="cyd81-table"><table><thead><tr><th>Ítem / UPC</th><th>Producto</th><th>Lista</th><th class="cyd81-num">Precio</th><th>Estado</th></tr></thead><tbody>'+(items||'<tr><td colspan="5">No hay carteles con este filtro.</td></tr>')+'</tbody></table></div><div class="cyd81-footer"><span>Página '+(state.page+1)+' de '+pages+'</span><div class="cyd81-buttons"><button data-cyd81-page="prev" '+(state.page===0?'disabled':'')+'>Anterior</button><button data-cyd81-page="next" '+(state.page>=pages-1?'disabled':'')+'>Siguiente</button></div></div></div>';
   }
  }
  async function loadSummary(){state.loading=true;state.error='';paint();try{state.summary=await api('/api/carteleria/impresion');}catch(e){state.error=e.message;}finally{state.loading=false;paint();}}
  async function loadDetail(local){state.level='detail';state.local=local;state.detail=null;state.filter='pending';state.family='all';state.page=0;state.search='';paint();try{state.detail=await api('/api/carteleria/impresion?local='+encodeURIComponent(local));paint();}catch(e){state.error=e.message;paint();}}
  root.onclick=e=>{const b=e.target.closest('button');if(!b)return;
    if(b.hasAttribute('data-cyd81-refresh')){if(state.level==='detail'&&state.local)loadDetail(state.local);else loadSummary();return;}
    if(b.hasAttribute('data-cyd81-back')){if(state.level==='detail')state.level='stores';else if(state.level==='stores'&&profile?.role==='master')state.level='markets';else{onBack();return;}paint();return;}
    if(b.hasAttribute('data-cyd81-market')){state.market=b.dataset.cyd81Market;state.level='stores';paint();return;}
    if(b.hasAttribute('data-cyd81-local')){loadDetail(b.dataset.cyd81Local);return;}
    if(b.hasAttribute('data-cyd81-page')){state.page=Math.max(0,state.page+(b.dataset.cyd81Page==='next'?1:-1));paint();return;}
  };
  root.onchange=e=>{if(e.target.matches('[data-cyd81-family]')){state.family=e.target.value;state.page=0;paint();}if(e.target.matches('[data-cyd81-filter]')){state.filter=e.target.value;state.page=0;paint();}};
  root.oninput=e=>{if(e.target.matches('[data-cyd81-search]')){const cursor=e.target.selectionStart;state.search=e.target.value;state.page=0;paint();const input=root.querySelector('[data-cyd81-search]');input?.focus();try{input.setSelectionRange(cursor,cursor)}catch{}}};
  loadSummary();
 }
 g.CYD81_COMPLIANCE={open};
})(window);
