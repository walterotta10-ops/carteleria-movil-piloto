/* C&D V1.5. Lector compartido: cámara, foto y UPC/EAN, sin servicios externos. */
(function(g){
 'use strict';
 let libraryPromise=null,active=null;
 const retailFormats=['ean_13','ean_8','upc_a','upc_e'];
 function validGTIN(value){
  if(!/^\d+$/.test(value)||![8,12,13,14].includes(value.length))return false;
  let sum=0;for(let i=value.length-2,weight=3;i>=0;i--,weight=4-weight)sum+=Number(value[i])*weight;
  return (10-sum%10)%10===Number(value[value.length-1]);
 }
 function expandUPCE(code){
  if(!/^[01]\d{7}$/.test(code))return '';
  const d=code.slice(1,7),last=d[5];let body='';
  if('012'.includes(last))body=d.slice(0,2)+last+'0000'+d.slice(2,5);
  else if(last==='3')body=d.slice(0,3)+'00000'+d.slice(3,5);
  else if(last==='4')body=d.slice(0,4)+'00000'+d[4];
  else body=d.slice(0,5)+'0000'+last;
  const upc=code[0]+body+code[7];return validGTIN(upc)?upc:'';
 }
 function result(value,format=''){
  const raw=String(value??'').trim(),kind=String(format).toLowerCase();
  // Conservar los doce dígitos UPC-A; agregar un cero alteraba la búsqueda exacta.
  if(kind==='upc_e'){const expanded=expandUPCE(raw);return expanded?{rawValue:expanded,format:kind,sourceValue:raw}:null;}
  if(retailFormats.includes(kind)&&(!validGTIN(raw)||({ean_13:13,ean_8:8,upc_a:12})[kind]!==raw.length))return null;
  return raw?{rawValue:raw,format:kind}:null;
 }
 function equivalent(a,b){
  a=String(a??'').trim();b=String(b??'').trim();
  if(!a||!b)return false;if(a===b)return true;
  // Solo equivalencias GTIN válidas; nunca corregir un dígito ni adivinar un producto.
  return validGTIN(a)&&validGTIN(b)&&a.padStart(14,'0')===b.padStart(14,'0');
 }
 function accepted(code,mode){return code&&(mode==='mac'||/^\d{1,20}$/.test(code.rawValue));}
 async function loadLibrary(){
  if(g.ZXing?.MultiFormatOneDReader)return g.ZXing;
  if(!libraryPromise)libraryPromise=(async()=>{
   const response=await fetch(location.origin+'/vendor/zxing.min.js?v=v1.5',{credentials:'same-origin',cache:'force-cache'});
   if(!response.ok)throw new Error('No se pudo cargar el lector. Revisa la conexión y vuelve a intentarlo.');
   const source=await response.text();
   await new Promise((resolve,reject)=>{
    const url=URL.createObjectURL(new Blob([source],{type:'application/javascript'})),script=document.createElement('script');
    const finish=()=>{URL.revokeObjectURL(url);script.remove();};
    script.onload=()=>{finish();resolve();};script.onerror=()=>{finish();reject(new Error('No se pudo iniciar el lector. Recarga la página.'));};
    script.src=url;document.head.appendChild(script);
   });
   if(!g.ZXing?.MultiFormatOneDReader)throw new Error('El lector no está disponible. Recarga la página.');
   return g.ZXing;
  })().catch(error=>{libraryPromise=null;throw error;});
  return libraryPromise;
 }
 async function createSoftware(mode){
  const ZX=await loadLibrary(),hints=new Map(),retailHints=new Map();
  hints.set(ZX.DecodeHintType.POSSIBLE_FORMATS,['CODE_128','CODE_39','CODE_93','ITF'].map(name=>ZX.BarcodeFormat[name]));
  hints.set(ZX.DecodeHintType.TRY_HARDER,true);
  retailHints.set(ZX.DecodeHintType.POSSIBLE_FORMATS,['EAN_13','EAN_8','UPC_A','UPC_E'].map(name=>ZX.BarcodeFormat[name]));
  retailHints.set(ZX.DecodeHintType.TRY_HARDER,true);
  const retail=new ZX.MultiFormatOneDReader(retailHints),linear=new ZX.MultiFormatOneDReader(hints),qr=new ZX.QRCodeReader();
  const readers=mode==='mac'?[[qr,hints],[linear,hints]]:[[retail,retailHints],[linear,hints],[qr,hints]];
  if(mode==='mac'&&ZX.DataMatrixReader)readers.push([new ZX.DataMatrixReader(),hints]);
  if(mode==='mac'&&ZX.AztecCodeReader)readers.push([new ZX.AztecCodeReader(),hints]);
  const canvas=document.createElement('canvas'),ctx=canvas.getContext('2d',{willReadFrequently:true});
  if(!ctx)throw new Error('No se pudo preparar la lectura de imágenes. Recarga la página.');
  let disposed=false,frame=0;
  function decode(source,variant,thorough,auxiliary=false){
   const width=Number(source.videoWidth||source.naturalWidth||source.width),height=Number(source.videoHeight||source.naturalHeight||source.height);
   const [portion,angle]=variant,sw=Math.round(width*portion),sh=Math.round(height*(portion===1?1:.60));
   const scale=Math.min(1,(thorough?2048:1600)/Math.max(sw,sh)),w=Math.max(1,Math.round(sw*scale)),h=Math.max(1,Math.round(sh*scale));
   const rad=angle*Math.PI/180,c=Math.abs(Math.cos(rad)),s=Math.abs(Math.sin(rad)),pad=16;
   canvas.width=Math.ceil(w*c+h*s)+pad*2;canvas.height=Math.ceil(w*s+h*c)+pad*2;
   ctx.fillStyle='#fff';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.save();
   ctx.translate(canvas.width/2,canvas.height/2);ctx.rotate(rad);
   ctx.drawImage(source,Math.round((width-sw)/2),Math.round((height-sh)/2),sw,sh,-w/2,-h/2,w,h);ctx.restore();
   const pixels=ctx.getImageData(0,0,canvas.width,canvas.height).data,grey=new Uint8ClampedArray(canvas.width*canvas.height);
   for(let i=0,j=0;i<pixels.length;i+=4,j++)grey[j]=(pixels[i]+2*pixels[i+1]+pixels[i+2])>>>2;
   const luminance=new ZX.RGBLuminanceSource(grey,canvas.width,canvas.height);
   const binarizers=[ZX.HybridBinarizer];if(thorough||frame%3===0)binarizers.push(ZX.GlobalHistogramBinarizer);
   for(const Binarizer of binarizers){
    const bitmap=new ZX.BinaryBitmap(new Binarizer(luminance));
    const selected=mode==='mac'?readers:auxiliary?readers.slice(1):readers.slice(0,1);
    for(const [reader,options] of selected){
     try{const decoded=reader.decode(bitmap,options),found=result(decoded.getText(),ZX.BarcodeFormat[decoded.getBarcodeFormat()]);if(accepted(found,mode))return [found];}
     catch{/* Un fotograma sin código legible es normal durante el enfoque. */}
     finally{reader.reset();}
    }
   }
   return [];
  }
  // Alternar área y ángulo conserva detalle y cubre etiquetas inclinadas y verticales.
  const variants=[[1,0],[1,90],[.90,0],[.80,-7],[.80,7],[.90,-14],[1,0],[.90,14],[1,-7],[1,7],[.80,90],[1,-14],[1,14]];
  return {
   async detect(source,{thorough=false}={}){
    if(disposed)return [];
    if(!(source.videoWidth||source.naturalWidth||source.width)||!(source.videoHeight||source.naturalHeight||source.height))return [];
    frame++;
    const attempts=thorough?variants:[variants[(frame-1)%variants.length]];
    for(const variant of attempts){if(disposed)return [];const found=decode(source,variant,thorough);if(found.length)return found;if(thorough)await new Promise(resolve=>setTimeout(resolve,0));}
    // Dar prioridad a EAN/UPC. Probar los demás formatos sin frenar cada fotograma.
    if(mode!=='mac'&&(thorough||frame%6===0))for(const variant of thorough?variants.slice(0,3):attempts){if(disposed)return [];const found=decode(source,variant,thorough,true);if(found.length)return found;if(thorough)await new Promise(resolve=>setTimeout(resolve,0));}
    return [];
   },
   dispose(){disposed=true;readers.forEach(([reader])=>reader.reset());canvas.width=canvas.height=0;}
  };
 }
 async function create({mode='item'}={}){
  const formats=mode==='mac'?['qr_code','code_128','data_matrix','aztec','code_39']:retailFormats.concat(['code_128','code_39','itf','qr_code']);
  let native=null,software=null,softwarePromise=null,disposed=false,frames=0,nativeErrors=0;
  if(typeof g.BarcodeDetector==='function'&&typeof g.BarcodeDetector.getSupportedFormats==='function'){
   try{const supported=await g.BarcodeDetector.getSupportedFormats(),usable=formats.filter(f=>supported.includes(f));if(usable.length)native=new g.BarcodeDetector({formats:usable});}catch{/* Continuar con el lector incorporado. */}
  }
  async function getSoftware(){
   if(!softwarePromise)softwarePromise=createSoftware(mode).then(reader=>{if(disposed)reader.dispose();else software=reader;return reader;}).catch(error=>{softwarePromise=null;throw error;});
   return softwarePromise;
  }
  if(!native)await getSoftware();
  return {
   async detect(source,{thorough=false}={}){
    if(disposed)return [];frames++;
    if(native&&!thorough){
     let nativeFailed=false;
     try{const found=(await native.detect(source)).map(code=>result(code.rawValue,code.format)).filter(code=>accepted(code,mode));if(disposed)return [];nativeErrors=0;if(found.length)return found;}
     catch{nativeFailed=true;if(++nativeErrors>=3)native=null;}
     // No desactivar permanentemente el lector nativo cuando la cámara aún está enfocando.
     if(native&&!nativeFailed&&(frames<4||frames%2===1))return [];
    }
    try{const reader=software||await getSoftware();return disposed?[]:reader.detect(source,{thorough});}
    catch(error){if(native)return [];throw error;}
   },
   dispose(){disposed=true;native=null;software?.dispose();}
  };
 }
 const esc=value=>String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const current=s=>active===s&&!s.closed;
 function stopCamera(s){
  s.cameraAttempt++;clearTimeout(s.timer);s.timer=null;s.running=false;
  s.stream?.getTracks().forEach(track=>track.stop());s.stream=null;
  if(s.video)s.video.srcObject=null;
  s.root.querySelector('[data-scanner-torch]').hidden=true;s.root.querySelector('[data-scanner-zoom]').hidden=true;
 }
 function close(){
  const s=active;if(!s)return;s.closed=true;active=null;stopCamera(s);s.reader?.dispose();
  if(s.fileUrl)URL.revokeObjectURL(s.fileUrl);s.root.remove();
  if(s.previousFocus?.isConnected)s.previousFocus.focus({preventScroll:true});
 }
 function sessionReader(s){
  if(!s.readerPromise)s.readerPromise=create({mode:s.mode}).then(reader=>{s.reader=reader;if(!current(s))reader.dispose();return reader;}).catch(error=>{s.readerPromise=null;throw error;});
  return s.readerPromise;
 }
 async function finish(s,code){
  if(!current(s))return;
  const raw=String(code.rawValue||'').trim();
  if(s.mode==='mac'&&!/^(?:[0-9a-f]{12}|(?:[0-9a-f]{2}[:-]){5}[0-9a-f]{2})$/i.test(raw)){s.status.textContent='El código no contiene una MAC válida. Apunta a la etiqueta de la impresora.';return false;}
  if(s.mode!=='mac'&&!/^\d{1,20}$/.test(raw))return false;
  close();try{await s.onResult(raw);}catch(error){g.alert('El código se leyó, pero no se pudo completar la búsqueda. '+(error.message||'Vuelve a buscar el código.'));}return true;
 }
 async function cameraOptions(s,track){
  const live=()=>current(s)&&s.running&&s.stream?.getVideoTracks()[0]===track;
  let caps={};try{caps=track.getCapabilities?.()||{};}catch{}
  if(caps.focusMode?.includes('continuous'))try{await track.applyConstraints({advanced:[{focusMode:'continuous'}]});}catch{}
  if(!live())return;
  const torch=s.root.querySelector('[data-scanner-torch]'),zoom=s.root.querySelector('[data-scanner-zoom]'),slider=zoom.querySelector('input');
  torch.hidden=!caps.torch;torch.setAttribute('aria-pressed','false');torch.textContent='Encender luz';
  torch.onclick=async()=>{const enable=torch.getAttribute('aria-pressed')!=='true';try{await track.applyConstraints({advanced:[{torch:enable}]});if(live()){torch.setAttribute('aria-pressed',String(enable));torch.textContent=enable?'Apagar luz':'Encender luz';}}catch{if(live())s.status.textContent='Esta cámara no permite cambiar la luz. Prueba con otra cámara.';}};
  zoom.hidden=!(Number.isFinite(caps.zoom?.min)&&caps.zoom.max>caps.zoom.min);
  if(!zoom.hidden){
   slider.min=String(caps.zoom.min);slider.max=String(caps.zoom.max);slider.step=String(caps.zoom.step||.1);slider.value=String(track.getSettings?.().zoom||caps.zoom.min);
   const label=zoom.querySelector('output');label.textContent=Number(slider.value).toFixed(1)+'×';
   slider.oninput=()=>{label.textContent=Number(slider.value).toFixed(1)+'×';};
   slider.onchange=async()=>{try{await track.applyConstraints({advanced:[{zoom:Number(slider.value)}]});}catch{if(current(s))s.status.textContent='No se pudo aplicar el zoom. Mantén la etiqueta enfocada.';}};
  }
  try{
   const devices=(await navigator.mediaDevices.enumerateDevices()).filter(d=>d.kind==='videoinput');if(!live())return;
   const select=s.root.querySelector('[data-scanner-camera]');select.parentElement.hidden=devices.length<2;
   select.innerHTML=devices.map((d,i)=>'<option value="'+esc(d.deviceId)+'">'+esc(d.label||'Cámara '+(i+1))+'</option>').join('');
   select.value=track.getSettings?.().deviceId||'';select.onchange=()=>startCamera(s,select.value);
  }catch{/* La selección manual es opcional; no interrumpir la lectura. */}
 }
 function cameraError(error){
  if(error.name==='NotAllowedError'||error.name==='SecurityError')return 'Permite el acceso a la cámara en este navegador. También puedes usar Leer desde foto.';
  if(error.name==='NotFoundError')return 'No se encontró una cámara. Puedes usar Leer desde foto.';
  if(error.name==='NotReadableError')return 'La cámara está ocupada. Cierra la otra aplicación y pulsa Reiniciar cámara, o usa una foto.';
  return error.message&&/lector|lectura/.test(error.message)?error.message:'No se pudo abrir la cámara. Pulsa Reiniciar cámara o usa Leer desde foto.';
 }
 async function startCamera(s,deviceId=''){
  if(!current(s))return;stopCamera(s);const attempt=s.cameraAttempt;s.imageAttempt++;s.imageBusy=false;
  s.file.disabled=false;s.root.querySelector('[data-scanner-photo]').disabled=false;
  s.status.textContent='Abriendo cámara…';s.lastValue='';s.repeats=0;
  const valid=()=>current(s)&&attempt===s.cameraAttempt;
  try{
   if(!navigator.mediaDevices?.getUserMedia)throw new Error('La lectura de cámara necesita HTTPS. Puedes usar Leer desde foto.');
   const video={...(deviceId?{deviceId:{exact:deviceId}}:{facingMode:{ideal:'environment'}}),width:{ideal:1920},height:{ideal:1080}};
   let stream;
   try{stream=await navigator.mediaDevices.getUserMedia({video,audio:false});}
   catch(error){if(!valid())return;if(error.name!=='OverconstrainedError')throw error;stream=await navigator.mediaDevices.getUserMedia({video:deviceId?{deviceId:{exact:deviceId}}:{facingMode:'environment'},audio:false});}
   if(!valid()){stream.getTracks().forEach(track=>track.stop());return;}
   s.stream=stream;s.video.srcObject=stream;await s.video.play();if(!valid())return;
   s.running=true;await sessionReader(s);if(!valid())return;
   const track=stream.getVideoTracks()[0];cameraOptions(s,track).catch(()=>{});
   s.status.textContent='Buscando código… Mantén visibles todas las barras y un borde blanco a cada lado.';
   const began=Date.now();
   const scan=async()=>{
    if(!valid()||!s.running||s.imageBusy)return;
    try{
     const found=await s.reader.detect(s.video);if(!valid())return;
     if(found.length){
      const code=found[0];s.repeats=s.lastValue===code.rawValue?s.repeats+1:1;s.lastValue=code.rawValue;
      if(s.repeats>=2){if(await finish(s,code))return;}
      else s.status.textContent='Código detectado. Mantén el teléfono quieto un instante…';
     }else if(Date.now()-began>7000){s.status.textContent='Si cuesta enfocar, separa un poco el teléfono, prueba otra cámara o usa Leer desde foto.';}
    }catch(error){if(valid())s.status.textContent=cameraError(error);}
    if(valid()&&s.running)s.timer=setTimeout(scan,140);
   };scan();
  }catch(error){if(valid()){stopCamera(s);s.status.textContent=cameraError(error);}}
 }
 async function readPhoto(s,file){
  if(!current(s)||!file)return;
  stopCamera(s);const attempt=++s.imageAttempt;s.imageBusy=true;
  const valid=()=>current(s)&&attempt===s.imageAttempt;
  s.root.querySelector('[data-scanner-photo]').disabled=true;
  s.status.textContent='Leyendo foto…';
  if(s.fileUrl)URL.revokeObjectURL(s.fileUrl);s.fileUrl=URL.createObjectURL(file);
  const image=new Image();image.decoding='async';
  try{
   await new Promise((resolve,reject)=>{image.onload=resolve;image.onerror=()=>reject(new Error('No se pudo abrir la foto. Usa una imagen JPG, PNG o una foto de la cámara.'));image.src=s.fileUrl;});
   if(!valid())return;
   await sessionReader(s);if(!valid())return;
   const found=await s.reader.detect(image,{thorough:true});if(!valid())return;
   if(found.length){if(await finish(s,found[0]))return;}
   else s.status.textContent='No se pudo leer el código en esa foto. Toma otra con todas las barras enfocadas o ingresa el número manualmente.';
  }catch(error){if(valid())s.status.textContent=error.message||'No se pudo leer la foto. Prueba con otra imagen.';}
  finally{if(valid()){s.imageBusy=false;s.file.value='';s.root.querySelector('[data-scanner-photo]').disabled=false;if(s.fileUrl){URL.revokeObjectURL(s.fileUrl);s.fileUrl=null;}}}
 }
 function open({mode='item',onResult}={}){
  close();
  const title=mode==='mac'?'Escanear código de impresora':'Escanear ítem o UPC',previousFocus=document.activeElement;
  document.body.insertAdjacentHTML('beforeend',`<div class="camera-scanner" id="cameraScanner" role="dialog" aria-modal="true" aria-labelledby="scannerTitle"><div class="camera-card"><div class="camera-head"><strong id="scannerTitle">${title}</strong><button id="closeCameraScanner" type="button" aria-label="Cerrar cámara">×</button></div><div class="scanner-viewport"><video id="scannerVideo" playsinline webkit-playsinline muted autoplay></video><div class="camera-target" aria-hidden="true"></div></div><p>${mode==='mac'?'Apunta al código que contiene la MAC de la impresora.':'Centra todas las barras y deja un borde blanco a cada lado. No es necesario pegar el teléfono a la etiqueta.'}</p><div id="scannerStatus" class="scanner-status" role="status" aria-live="polite">Preparando cámara…</div><label class="scanner-camera" hidden>Cámara<select data-scanner-camera aria-label="Seleccionar cámara"></select></label><div class="scanner-controls"><button class="btn" data-scanner-torch type="button" hidden>Encender luz</button><button class="btn" data-scanner-restart type="button">Reiniciar cámara</button><button class="btn" data-scanner-photo type="button">Leer desde foto</button></div><label class="scanner-zoom" data-scanner-zoom hidden>Zoom<input type="range" aria-label="Zoom de cámara"><output></output></label><input class="scanner-file" data-scanner-file type="file" accept="image/*" capture="environment" tabindex="-1"><button class="btn back-home" id="cancelScanner" type="button">Volver e ingresar código</button></div></div>`);
  const root=document.getElementById('cameraScanner'),s={root,mode,onResult:onResult||(()=>{}),previousFocus,video:root.querySelector('video'),status:root.querySelector('#scannerStatus'),file:root.querySelector('[data-scanner-file]'),cameraAttempt:0,imageAttempt:0,reader:null,stream:null,closed:false};
  active=s;s.video.muted=true;
  root.querySelector('#closeCameraScanner').onclick=close;root.querySelector('#cancelScanner').onclick=close;
  root.querySelector('[data-scanner-restart]').onclick=()=>startCamera(s,root.querySelector('[data-scanner-camera]').value);
  root.querySelector('[data-scanner-photo]').onclick=()=>s.file.click();s.file.onchange=()=>readPhoto(s,s.file.files?.[0]);
  root.addEventListener('keydown',event=>{
   if(event.key==='Escape'){event.preventDefault();close();}
   if(event.key==='Tab'){const controls=[...root.querySelectorAll('button,input:not([type=file]),select')].filter(el=>!el.disabled&&!el.hidden&&!el.closest('[hidden]'));if(!controls.length)return;const first=controls[0],last=controls[controls.length-1];if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus();}else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus();}}
  });
  root.querySelector('#closeCameraScanner').focus();startCamera(s);return {close};
 }
 g.addEventListener('pagehide',close);
 document.addEventListener('visibilitychange',()=>{const s=active;if(s&&document.hidden){stopCamera(s);if(!s.imageBusy)s.status.textContent='Cámara pausada. Pulsa Reiniciar cámara para continuar o usa una foto.';}});
 g.CYD66_BARCODE={create,open,close,equivalent,validGTIN,expandUPCE};
})(window);
