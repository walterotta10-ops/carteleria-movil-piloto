/* Especificaciones compartidas por catálogo, validación y carteles impresos. */
function createSpecificationCore75(){
 'use strict';
 const text=v=>String(v??'').trim();
 const present=v=>!!text(v)&&!['SIN DESCRIPCION','SIN DESCRIPCIÓN','SIN MARCA','SIN INFORMACION','N/A','S/D'].includes(text(v).toUpperCase());
 function size(value){
  const match=/^(\d+(?:[.,]\d+)?)\s*(CC|ML|LTS?|L|GRS?|G|KGS?|MTS?|METROS?|M|UNIDADES?|UNIDS?|UNDS?|UN)$/i.exec(text(value));
  if(!match)return null;const n=Number(match[1].replace(',','.')),u=match[2].toUpperCase();if(!Number.isFinite(n)||n<=0)return null;
  if(['CC','ML'].includes(u))return {amount:n/1000,label:'LT',quantity:n,unit:u};
  if(['L','LT','LTS'].includes(u))return {amount:n,label:'LT',quantity:n,unit:'LT'};
  if(['G','GR','GRS'].includes(u))return {amount:n/1000,label:'KG',quantity:n,unit:'GR'};
  if(['KG','KGS'].includes(u))return {amount:n,label:'KG',quantity:n,unit:'KG'};
  if(['M','MT','MTS','METRO','METROS'].includes(u))return {amount:n,label:'MT',quantity:n,unit:'MT'};
  return {amount:n,label:'UN',quantity:n,unit:'UN'};
 }
 const barcode=value=>text(value).replace(/^0+(?=\d)/,'');
 function repair(product,lookup,checkedAt){
  if(!product||product.manual)return product;
  const p={...product},changes=[],candidates=(lookup?.find(p.barcode)||[]).filter(r=>(!p.code||text(r.item)===text(p.code))&&[p.barcode,p.sourceUPC].some(upc=>barcode(upc)===barcode(r.upc)));
  const row=candidates.length===1?candidates[0]:null;
  if(row){
   for(const [field,source,label] of [['name','descripcion','descripción'],['brand','marca','marca']])if(!present(p[field])&&present(row[source])){p[field]=text(row[source]);changes.push(label);}
   if(!size(p.size)&&size(row.unidad)){const measure=size(row.unidad);p.size=measure.quantity+measure.unit;changes.push('medida');}
  }
  const recovered=new Set();if(present(p.name))recovered.add('Falta descripción');if(present(p.brand))recovered.add('Falta marca');if(size(p.size)){recovered.add('Falta tamaño');recovered.add('Unidad o cantidad de medida sin verificar');}
  p.dataIssues=(p.dataIssues||[]).filter(issue=>!recovered.has(issue));
  p.specificationCheck75={checkedAt,source:changes.length?'Maestra compartida aprobada':'Catálogo vigente',updatedAt:changes.length?row.updated_at||null:null,recovered:changes,measureRecognized:!!size(p.size)};
  const qty=Number(p.qty),regular=Number(p.unit),offer=Number(p.offer);
  p.priceStatus75=qty===1&&regular>0&&regular===offer?'normal':qty>0&&regular>0&&offer>regular*qty?'inconsistent':'promotion';
  return p;
 }
 return {size,present,repair};
}
