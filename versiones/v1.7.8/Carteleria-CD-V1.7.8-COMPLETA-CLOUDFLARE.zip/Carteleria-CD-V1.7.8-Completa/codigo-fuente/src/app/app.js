(()=>{const f=window.CARTELERIA_RULES;if(!f)throw new Error("Falta cartel-rules.js. No se habilita impresi\xF3n.");const k=(window.CARTELERIA_CATALOG||[]).map(e=>({...e,...f.calc(e)})),Ye="v39-cola-compartida-y-uso",I=document.getElementById("app"),we=document.getElementById("printRoot"),R="carteleria.rf.mobile.mac",ae=window.CYD_API_BASE||location.origin,a={local:localStorage.getItem("carteleria.local")||"",itemCode:"",product:null,queue:[],mobileMac:localStorage.getItem(R)||"",selectedLayout:new Set,layoutZoom:1};function q(){return window.matchMedia("(max-width: 760px)").matches}const s=(e="")=>String(e).replace(/[&<>"']/g,t=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"})[t]),y=window.CARTELERIA_SYNC.create({apiUrl:ae+"/api/cola",storage:localStorage,onChange(e){let migrate=false;a.queue=e.map(t=>{const p=f.canonical(t,k);if(!f.validate(p).length&&["code","signId","campaignId"].some(key=>String(p[key])!==String(t[key]))){migrate=true;return {...p,qid:y.newId()}}return p});if(migrate)queueMicrotask(()=>{if(a.local)y.replace(a.queue)});try{localStorage.setItem(ge(),JSON.stringify(a.queue))}catch{}V(),document.querySelectorAll("[data-queue-count]").forEach(t=>t.textContent=a.queue.length)},onStatus:Be}),S=window.CARTELERIA_USAGE.create({apiUrl:ae,storage:localStorage,session:sessionStorage});function Be(){const e=y.status,t=document.getElementById("queueSyncStatus");t&&(t.textContent=e.message+(e.pending?` \xB7 ${e.pending} cambio(s) pendiente(s)`:""),t.dataset.kind=e.kind)}I.addEventListener("click",event=>{
 if(event.target.closest("[data-cyd-exit]")){C();return;}
 if(event.target.closest("[data-sync-queue]"))y.sync();
 if(event.target.closest("[data-open-queue]"))cyd80Enter(E);
}),window.setInterval(()=>{if(!a.local||document.hidden)return;if(cyd80QueueView()||y.status.pending)y.sync();S.flush()},15e3),window.addEventListener("focus",()=>{a.local&&(cyd80SyncNeeded(),S.start(a.local))}),window.addEventListener("online",()=>{a.local&&cyd80SyncNeeded(),S.flush()}),document.addEventListener("visibilitychange",()=>{!document.hidden&&a.local&&(cyd80SyncNeeded(),S.start(a.local))});let pe=0;for(const e of["pointerdown","keydown"])document.addEventListener(e,()=>{a.local&&Date.now()-pe>6e4&&(pe=Date.now(),S.start(a.local))},{passive:!0});window.addEventListener("storage",e=>{e.key?.startsWith(window.CARTELERIA_SYNC.PREFIX)&&y.reload({sync:cyd80QueueView()})});function ge(){return`carteleria.queue.${a.local||"sin-local"}`}function N(){if(y.local===a.local)return;let e=[];try{const t=JSON.parse(localStorage.getItem(ge())||"[]");Array.isArray(t)&&(e=t)}catch{}try{y.select(a.local,e,{sync:false})}catch{a.queue=e.map(n=>f.canonical(n,k)),window.alert("No se pudo guardar en este navegador. Revisa que permita almacenamiento antes de continuar.")}}function Y(){return f.auditQueue(a.queue)}async function Z(){if(window.CYD55_CATEGORIES.isMobileDevice()){window.CYD55_CATEGORIES.pcOnlyNotice();return false;}try{await cyd53Refresh(true)}catch(error){window.alert("No se puede imprimir sin verificar la promoción vigente. "+error.message);return false}const e=a.local;if(!await y.sync()&&y.status.kind!=="setup")return window.alert("No se pudo actualizar la cola de impresión del local. Conecta internet y presiona Actualizar antes de imprimir."),!1;if(a.local!==e)return!1;if(N(),!a.queue.length)return window.alert("No hay carteles en la cola de impresión."),!1;const n=Y();if(n.length){const o=n.slice(0,8).map(c=>`\xCDtem ${c.code}: ${c.error}`).join(`
`);return window.alert(`DATOS POR REVISAR: ${n.length} dato(s) por revisar.
${o}${n.length>8?`
...`:""}
Retira o corrige estos \xEDtems antes de imprimir.`),!1}return!0}function _(){window.CYD_EVENTS?.record(a.local,"queue_change",a.queue.length+" carteles en cola de impresión");try{y.replace(a.queue)}catch(e){a.queue=y.items.map(t=>f.canonical(t,k)),window.alert(e.code==="queue_limit"?e.message:"No se pudo guardar este cambio en el navegador. Intenta nuevamente.")}}function Xe(e){return e==="nx"?"Lleva m\xE1s, paga menos":e==="offer"?"Ahora m\xE1s barato":"Precio normal"}function w(){return`
      <header class="topbar">
        <div class="brand">
          <span class="brand-mark" aria-hidden="true">\u25C6</span>
          <span class="brand-text"><strong>Nuevo C&amp;D</strong><small>Carteler\xEDa \xB7 V1.7.8 SBA</small></span>
        </div>
        <div class="topbar-actions">
          <button class="local-badge" id="changeLocalTop" type="button">${CYD_IS_MARKET(a.local)?"Jefe de mercado \xB7 "+s(a.local):"Local "+s(a.local)}</button>
          <button class="local-badge topbar-exit" data-cyd-exit type="button">Salir</button>
        </div>
      </header>
      <div class="queue-sync-bar"><span id="queueSyncStatus" data-kind="${s(y.status.kind)}" role="status">${s(y.status.message)}</span><div><button type="button" data-sync-queue>Actualizar</button><button type="button" data-open-queue>Ver cola de impresión (<span data-queue-count>${a.queue.length}</span>)</button></div></div>
    `}const CYD_PROFILE=()=>window.CYD54_ACCESS.profile;
const CYD_IS_MARKET=code=>CYD_PROFILE()?.role==='market'&&CYD_PROFILE().code===String(code);
const CYD_IS_STORE=code=>CYD_PROFILE()?.role==='store'&&CYD_PROFILE().code===String(code);
if(a.local&&!CYD_IS_STORE(a.local)&&!CYD_IS_MARKET(a.local)){a.local="";localStorage.removeItem("carteleria.local");}
function x(){window.CYD54_ACCESS.logout();}
// C&D V50 — Modalidad manual. La maestra únicamente identifica artículos, no entrega precios.
let manualRecords=null,manualLookup=null,manualSelected=null;
async function loadManual(force=false){
 const profile=window.CYD54_ACCESS.profile,local=profile.role==='store'?profile.code:'';
 const data=await window.CYD56_PRODUCTS.catalog(local,force);
 manualRecords=data.records;manualLookup={get:key=>data.lookup.find(key)};return manualLookup;
}
window.addEventListener('cyd56-products-changed',()=>{manualLookup=null;});
function manualMoney(n){return '$'+Math.round(n).toLocaleString('es-CL')}
function renderManual(){++cyd80Navigation;
  if(!a.local)return x();N();manualSelected=null;
  I.innerHTML=`${w()}<section class="screen manual-screen">
   <div class="search-card"><div class="search-head"><h2>Cartelería Manual</h2><div class="manual-head-actions"><button class="btn cyd56-yellow" id="manualNewProduct" type="button">Ingresar datos de producto</button><button class="btn back-home" id="manualBack" type="button">Volver al inicio</button></div></div>
   <p>La maestra entrega ítem, UPC, descripción, marca y unidad de medida. <strong>Quien crea el cartel es responsable de ingresar el precio y la promoción.</strong></p>
   <label for="manualItem">Ítem o código de barras</label>
   <div class="search-row"><input id="manualItem" type="text" inputmode="numeric" autocomplete="off" placeholder="Ingresar ítem o UPC"/><button class="btn search" id="manualFind" type="button">Buscar</button></div>
   ${q()?'<button class="btn scan-item-btn" id="manualScan" type="button">▣ Escanear ítem o UPC</button>':''}
   <div id="manualStatus" role="status"></div><div id="manualChoices"></div>
   <div id="manualForm" hidden>
    <div class="manual-product" id="manualProduct"></div>
    <div class="manual-fields"><label>Precio que se imprimirá ($)<input id="manualPrice" type="number" inputmode="numeric" min="1" step="1" placeholder="Ej. 3950"></label>
    <label>Precio antes ($) — opcional<input id="manualBefore" type="number" inputmode="numeric" min="1" step="1" placeholder="Sin precio anterior"></label>
    <label>Cantidad de productos<input id="manualQty" type="number" inputmode="numeric" min="1" max="20" step="1" value="1"></label></div>
    <p class="manual-note">Cantidad 1: precio normal o con ahorro. Cantidad 2–20: promoción Nx por el precio total ingresado. El ahorro se calcula solo si indicas el precio anterior unitario.</p>
    <div id="manualSummary" role="status"></div>
    <button class="btn primary" id="manualAdd" type="button">Enviar a cola de impresión</button>
   </div></div>
   <section class="queue-section"><div class="section-title"><h2>Cola de impresión compartida</h2><span class="count">${a.queue.length}</span></div><button class="btn print" id="manualQueue" type="button">Ver cola de impresión</button></section>
  </section>`;
  document.getElementById('manualBack').onclick=z;
  document.getElementById('changeLocalTop').onclick=C;
  document.getElementById('manualQueue').onclick=E;
  document.getElementById('manualFind').onclick=findManual;
  document.getElementById('manualScan')?.addEventListener('click',()=>$e('manual'));
  document.getElementById('manualNewProduct').onclick=()=>window.CYD56_PRODUCTS.open({local:a.local,onSaved:async result=>{manualLookup=null;await loadManual(true);const input=document.getElementById('manualItem');if(!input)return;input.value=result.product.item;await findManual();const status=document.getElementById('manualStatus');if(status)status.textContent=result.message;}});
  document.getElementById('manualItem').addEventListener('keydown',event=>{if(event.key==='Enter'){event.preventDefault();findManual()}});
  for(const id of ['manualPrice','manualBefore','manualQty'])document.getElementById(id).addEventListener('input',manualPreview);
  document.getElementById('manualAdd').onclick=addManual;
  loadManual(true).then(()=>{const status=document.getElementById('manualStatus');if(status)status.textContent=`Maestra disponible: ${manualRecords.length.toLocaleString('es-CL')} artículos.`}).catch(e=>{const status=document.getElementById('manualStatus');if(status)status.textContent=e.message});
}
async function findManual(fromScan=false){
 const status=document.getElementById('manualStatus'),choices=document.getElementById('manualChoices'),form=document.getElementById('manualForm');
 if(!status)return;
 manualSelected=null;form.hidden=true;choices.innerHTML='';
 const key=document.getElementById('manualItem').value.trim();
 if(!/^\d{1,20}$/.test(key)){status.textContent='Ingresa un ítem o código de barras válido.';return}
 status.textContent='Buscando artículo…';let map;
 try{map=await loadManual()}catch(e){status.textContent=e.message;return}
 const matches=map.get(key)||[];
 if(!matches.length){status.textContent=(fromScan===true?'Código leído correctamente: '+key+'. ':'')+(CYD_PROFILE()?.features?.fleje?'Artículo no encontrado. En Ingresar datos de producto puedes subir una foto del fleje.':'Artículo no encontrado. Usa Ingresar datos de producto para completar la maestra.');return}
 const distinct=[...new Map(matches.map(r=>[JSON.stringify([r.item,r.upc,r.descripcion,r.marca]),r])).values()];
 if(distinct.length===1){selectManual(distinct[0]);return}
 status.textContent=`Se encontraron ${distinct.length} registros. Selecciona el ítem y UPC correctos:`;
 choices.innerHTML=distinct.map((r,i)=>`<button type="button" class="manual-choice" data-manual-choice="${i}"><strong>${s(r.descripcion)}</strong><small>Ítem ${s(r.item)} · UPC ${s(r.upc)} · ${s(r.marca)}</small></button>`).join('');
 choices.querySelectorAll('[data-manual-choice]').forEach(b=>b.onclick=()=>selectManual(distinct[Number(b.dataset.manualChoice)]));
}
function selectManual(record){
 manualSelected=record;
 document.getElementById('manualStatus').textContent='Artículo seleccionado desde la maestra. Los precios los decides tú.';
 document.getElementById('manualChoices').innerHTML='';
 document.getElementById('manualForm').hidden=false;
 document.getElementById('manualProduct').innerHTML=`<strong>${s(record.descripcion)}</strong><span>Marca: ${s(record.marca)}${record.unidad?" · "+s(record.unidad):""}</span><small>Ítem ${s(record.item)} · UPC ${s(record.upc)}</small>`;
 document.getElementById('manualPrice').value='';document.getElementById('manualBefore').value='';document.getElementById('manualQty').value='1';manualPreview();
}
function manualValues(){
 const price=Number(document.getElementById('manualPrice').value),rawBefore=document.getElementById('manualBefore').value.trim(),before=rawBefore?Number(rawBefore):0,qty=Number(document.getElementById('manualQty').value);
 const errors=[];
 if(!Number.isSafeInteger(price)||price<=0)errors.push('Ingresa un precio mayor que cero.');
 if(rawBefore&&(!Number.isSafeInteger(before)||before<=0))errors.push('El precio antes debe ser un número positivo.');
 if(!Number.isSafeInteger(qty)||qty<1||qty>20)errors.push('La cantidad debe estar entre 1 y 20.');
 if(before&&price>before*qty)errors.push('El precio actual supera el precio antes por la cantidad seleccionada.');
 return {price,before,qty,errors};
}
function manualPreview(){
 const node=document.getElementById('manualSummary');if(!node||!manualSelected)return;
 const v=manualValues();if(v.errors.length){node.textContent=v.errors.join(' ');return}
 const savings=v.before*v.qty-v.price;
 node.innerHTML=`<strong>${v.qty>1?v.qty+'x':''}${manualMoney(v.price)}</strong> · ${v.qty>1?'Promoción '+v.qty+'x':v.before?'Cartel con ahorro':'Precio normal'}${v.before?' · Antes unitario '+manualMoney(v.before)+(savings>0?' · Ahorro '+manualMoney(savings):''):''}`;
}
function addManual(){
 if(!manualSelected){window.alert('Primero selecciona un artículo.');return}
 const v=manualValues();if(v.errors.length){window.alert(v.errors.join('\n'));return}
 const row=manualSelected;
 const entry={manual:true,qid:y.newId(),signId:'MANUAL-'+String(row.item)+'-'+Date.now(),campaignId:'MANUAL',code:String(row.item),barcode:String(row.upc||''),name:String(row.descripcion),brand:String(row.marca||''),offer:v.price,unit:v.before,qty:v.qty,price:v.qty>1?v.qty+'x'+manualMoney(v.price):manualMoney(v.price),campaignName:'CARTELERÍA MANUAL',size:String(row.unidad||'')};
 const issues=f.validate(entry);if(issues.length){window.alert('No se agregó el cartel: '+issues.join('; '));return}
 a.queue.push(entry);_();renderManual();document.getElementById('manualStatus').textContent='Cartel manual enviado a la cola de impresión compartida. Abre la cola de impresión para imprimir.';
}

function z(){++cyd80Navigation;if(CYD_PROFILE()?.role==='master')return cyd53MasterOpen();if(!a.local)return x();I.innerHTML=`${w()}<section class="screen mode-screen">
      <h1>\xBFQu\xE9 deseas hacer?</h1><p>${CYD_IS_MARKET(a.local)?"Acceso de jefe de mercado. Revisa promociones y uso de los locales.":"Elige c\xF3mo revisar tus promociones. Tu cola de impresión se guarda para abrirla en el PC."}</p>
      <div class="mode-grid">
        <button type="button" class="mode-tile" id="modeItem"><span class="mode-emoji">\u25A3</span><strong>Ingresar o escanear \xEDtem</strong><small>Buscar un cartel por c\xF3digo o escanearlo</small></button>
        <button type="button" class="mode-tile" id="modeLayout"><span class="mode-emoji">\u25A6</span><strong>Layout panor\xE1mico promociones</strong><small>Recorrer zonas, revisar categor\xEDas e imprimir</small></button>
        <button type="button" class="mode-tile" id="modeCategories"><span class="mode-emoji">☷</span><strong>Filtro Categorías</strong><small>Departamento, categoría y cartel rojo o amarillo</small></button>
        <button type="button" class="mode-tile" id="modeManual"><span class="mode-emoji">✎</span><strong>Cartelería Manual</strong><small>Busca el ítem en la maestra y carga tú los precios</small></button>
        ${CYD_IS_MARKET(a.local)?'<button type="button" class="mode-tile usage-mode-tile" id="modeUsage"><span class="mode-emoji">\u25A5</span><strong>Uso por local</strong><small>Jefe de mercado \xB7 accesos y carteles por d\xEDa o semana</small></button>':""}
        ${CYD_IS_MARKET(a.local)?'<button type="button" class="mode-tile" id="modeAlertPrint"><span class="mode-emoji">♧</span><strong>Impresión de alertas</strong><small>Locales con alertas impresas y pendientes</small></button>':""}
        ${CYD_IS_MARKET(a.local)?'<button type="button" class="mode-tile" id="modeCompliance"><span class="mode-emoji">▤</span><strong>% de impresión de cartelería</strong><small>Adherencia por local y listado de carteles pendientes</small></button>':""}
        ${window.CYD69_WEEKLY.isPilot()?'<button type="button" class="mode-tile" id="modeWeekly"><span class="mode-emoji">☑</span><strong>Revisión semanal</strong><small>Plan diario por categorías · Cumplimiento y revisión en sala</small></button>':""}
      </div></section>`,document.getElementById("modeItem").onclick=()=>cyd80Enter(E),document.getElementById("modeLayout").onclick=()=>cyd80Enter(()=>F()),document.getElementById("modeCategories").onclick=()=>cyd80Enter(cyd55OpenCategories),document.getElementById("modeManual").onclick=renderManual,document.getElementById("changeLocalTop").onclick=C,document.getElementById("modeUsage")?.addEventListener("click",()=>S.render({app:I,header:w,onBack:z,onChangeLocal:C,access:a.local,onAlerts:cyd68OpenReport})),document.getElementById("modeAlertPrint")?.addEventListener("click",cyd68OpenReport),document.getElementById("modeCompliance")?.addEventListener("click",cyd81OpenCompliance),document.getElementById("modeWeekly")?.addEventListener("click",cyd69OpenWeekly)}
function cyd68OpenReport(){return window.CYD68_ALERTS.openReport({host:I,header:w,onBack:z,onChangeLocal:C});}
function cyd81OpenCompliance(){I.innerHTML=w()+'<section class="screen"><div id="cyd81MarketCompliance"></div></section>';document.getElementById("changeLocalTop").onclick=C;window.CYD81_COMPLIANCE.open({host:document.getElementById("cyd81MarketCompliance"),onBack:z});}
const ne=[{name:"Abarrotes",icon:"\u{1F35A}",groups:["Arroz","Pastas","Aceites","Pur\xE9 y legumbres","Dressing","Harina","T\xE9 y hierbas","Leche en polvo y saborizantes","Mermeladas y miel","Cereales","Galletas","Conservas de pescado","Conservas de mariscos","Sopas y caldos","Sal y condimentos","Platos instant\xE1neos","Az\xFAcar","Conservas de frutas y verduras","Salsas y queso rallado","Postres listos","Caf\xE9","Endulzantes","Caramelos","Chocolates","Vinagre y suced\xE1neos","Sabores de Am\xE9rica","Reposter\xEDa","Colaci\xF3n","C\xF3ctel y frutos secos","Snacks"]},{name:"Bebestibles",icon:"\u{1F964}",groups:["Aguas","Bebidas","Jugos l\xEDquidos","Jugos en polvo","Energ\xE9ticas e isot\xF3nicas"]},{name:"Licores",icon:"\u{1F377}",groups:["Vinos","Cervezas","Licores"]},{name:"Perfumer\xEDa",icon:"\u{1F9F4}",groups:["Champ\xFA","Coloraci\xF3n","Afeitado y depilaci\xF3n","Desodorantes","Ba\xF1o y spa","Jabones","Higiene bucal","Puericultura","Alimentos y f\xF3rmulas para beb\xE9","Higiene femenina","Incontinencia","Pa\xF1ales"]},{name:"Limpieza",icon:"\u{1F9FC}",groups:["Papel higi\xE9nico","Servilletas y pa\xF1uelos","Limpiadores de piso","Guantes y pa\xF1os h\xFAmedos","Accesorios de piso","Ambientales y plaguicidas","Suavizantes","Detergentes","Wipes","Limpiadores de ba\xF1o","Esponjas y virutillas","Toalla de papel","Pulidores y antigrasas","Limpiavidrios","Lavaloza","Bolsas de basura","Blanqueamiento","Ceras","Tratamiento de ropa","Lustramuebles y calzado"]},{name:"L\xE1cteos y refrigerados",icon:"\u{1F95B}",groups:["L\xE1cteos","Leches blancas","Leches saborizadas","Pan industrial","Leche condensada y manjar","Hora del t\xE9","Huevos","Crema","Vegetales fr\xEDos"]},{name:"Fiambrer\xEDa y Deli",icon:"\u{1F9C0}",groups:["Fiambrer\xEDa","Fiambres y quesos","Deli","Quesos","Fiambres"]},{name:"Carnes y pollos",icon:"\u{1F969}",groups:["Carnes","Pollos","Asistido carnes","Carnes congeladas"]},{name:"Congelados",icon:"\u{1F9CA}",groups:["Congelados","Congelados carnes","Congelados l\xE1cteos"]},{name:"Panader\xEDa",icon:"\u{1F35E}",groups:["Panader\xEDa","Pan a granel","Hornos de pollo"]},{name:"Mascotas",icon:"\u{1F43E}",groups:["Alimento perro","Alimento gato","Accesorios mascotas"]},{name:"Hogar y cocina",icon:"\u{1F3E0}",groups:["Decoraci\xF3n hogar","Ferreter\xEDa","Autom\xF3vil","Envolturas y protecci\xF3n","Jugueter\xEDa","Librer\xEDa","Cumplea\xF1os","Sartenes","Bater\xEDas y cacerolas","Moldes","Cajas organizadoras","Accesorios ba\xF1o","Accesorios lavado","Frascos","Textil mesa","Utensilios","Accesorios mesa y cocina","Herm\xE9ticos","Termos y botellas","Tazones","Cristaler\xEDa","Loza"]},{name:"Textil",icon:"\u{1F455}",groups:["Mujer","Hombre","Infantil","Pijamas","Ropa ni\xF1a","Ropa ni\xF1o","Beb\xE9 ni\xF1a","Beb\xE9 ni\xF1o","Bodys beb\xE9","Ropa interior hombre","Ropa interior","Calcetines","Calzado mujer","Calzado hombre","Calzado infantil","Ropa interior ni\xF1a","Ropa interior ni\xF1o","Ropa interior beb\xE9","Set de cama","Frazadas","Plumones","S\xE1banas","Cojines, alfombras y bajadas","Toallas a granel"]},{name:"Otros y electr\xF3nica",icon:"\u{1F6D2}",groups:["Audio","Peque\xF1os electrodom\xE9sticos","Liquidaci\xF3n"]}],O=e=>String(e||"").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/[^a-z0-9]/g,""),be=ne.flatMap(e=>e.groups),fe={vino:"Vinos",vinos:"Vinos",cerveza:"Cervezas",cervezas:"Cervezas",licores:"Licores",licor:"Licores",bebida:"Bebidas",bebidas:"Bebidas",agua:"Aguas",aguamineral:"Aguas",arroz:"Arroz",jabon:"Jabones",jabonestocador:"Jabones",shampoo:"Champ\xFA",papelhigienico:"Papel higi\xE9nico",detergente:"Detergentes",lavalozas:"Lavaloza",fiambres:"Fiambres",fiambreria:"Fiambrer\xEDa",quesos:"Quesos",lacteos:"L\xE1cteos",frio:"L\xE1cteos",mascotas:"Accesorios mascotas",textil:"Ropa interior",pae:"Peque\xF1os electrodom\xE9sticos"};function oe(e){const t=String(e.categoryName||"").trim(),n=O(t);if(fe[n])return fe[n];const o=be.find(c=>O(c)===n);return o||t||"Sin clasificar"}const re=e=>k.filter(t=>O(oe(t))===O(e)),se=e=>e.groups.flatMap(re);function Ce(){const e=new Set(be.map(O)),t=[...new Set(k.map(oe).filter(n=>!e.has(O(n))))];return t.length?[...ne,{name:"Por clasificar",icon:"\u{1F4CB}",groups:t}]:ne}function M(e=null,t=null){if(!a.local)return x();N();const n=k.length,o=Ce(),c=o.find(r=>r.name===e),d=t?re(t):[],g=d.filter(r=>a.selectedLayout.has(String(r.signId||r.code))).length;I.innerHTML=`${w()}<section class="screen panorama-screen">
      <div class="panorama-head"><button class="btn back-home" id="layoutBack">\u2190 ${t?"Categor\xEDas":c?"Plano":"Men\xFA"}</button>
      <div><h1>Layout panor\xE1mico promociones</h1><p>Plano tipo \xB7 ${n} carteles cargados \xB7 sin referencia a un local espec\xEDfico</p></div></div>
      ${c?t?`<div class="panorama-breadcrumb">${s(c.name)} \u203A ${s(t)} \xB7 ${d.length} carteles</div>
       <div class="selection-tools"><label><input type="checkbox" id="selectAllLayout" ${d.length&&g===d.length?"checked":""}> Seleccionar todos (${g}/${d.length})</label><button class="btn primary" id="sendLayoutQueue" ${g?"":"disabled"}>Agregar ${g} a cola de impresión</button></div>
       <div class="layout-product-list">${d.map(r=>`<label class="layout-product"><input type="checkbox" data-sign="${s(String(r.signId||r.code))}" ${a.selectedLayout.has(String(r.signId||r.code))?"checked":""}><span><strong>${s(r.name)}</strong><small>${s(r.brand||"")} \xB7 \xCDtem ${s(r.code)} \xB7 ${s(r.listName||r.campaignName||"")}</small></span><b>${s(r.price||"")}</b></label>`).join("")||"<p>No hay carteles cargados en esta categor\xEDa todav\xEDa.</p>"}</div>
       <p class="panorama-hint">Puedes seleccionar carteles y agregarlos a la cola de impresión. No se imprimen autom\xE1ticamente.</p>`:`<div class="panorama-breadcrumb">${s(c.name)} \xB7 ${se(c).length} carteles</div>
        <div class="category-grid">${[...c.groups,...new Set(se(c).map(oe).filter(r=>!c.groups.includes(r)))].map(r=>`<button class="category-tile" data-group="${s(r)}"><strong>${s(r)}</strong><span>${re(r).length} carteles</span></button>`).join("")}</div>`:`<div class="panorama-tools"><span>Vista superior de zonas</span><div><button class="btn" id="zoomOut">\u2212</button><strong id="layoutZoomPercent">${Math.round(a.layoutZoom*100)}%</strong><button class="btn" id="zoomIn">+</button></div></div>
      <div class="panorama-viewport" id="occamViewport" tabindex="0" aria-label="Mapa desplazable de subgrupos"><div class="panorama-map" id="panoramaMap" style="zoom:${a.layoutZoom}">
        <div class="panorama-entrance">ZONAS DE PROMOCIONES</div>
        ${o.map(r=>`<button class="panorama-zone" data-zone="${s(r.name)}"><span class="zone-icon">${r.icon}</span><strong>${s(r.name)}</strong><span>${se(r).length} carteles</span></button>`).join("")}
      </div></div><p class="panorama-hint">Toca una zona para abrir sus categor\xEDas. En celular, usa dos dedos para ampliar o reducir; en PC, usa + y \u2212.</p>`}
      <div class="layout-queue-bar"><span>Cola de impresi\xF3n: <strong data-queue-count>${a.queue.length}</strong></span><button class="btn primary" id="goToQueue">Ver cola de impresión</button></div>
    </section>`,document.getElementById("changeLocalTop").onclick=C,document.getElementById("layoutBack").onclick=()=>t?M(e):c?M():z(),document.getElementById("goToQueue").onclick=E;const h=document.querySelector(".panorama-viewport");if(h){let r=0,p=a.layoutZoom;const i=m=>Math.hypot(m[0].clientX-m[1].clientX,m[0].clientY-m[1].clientY);h.addEventListener("touchstart",m=>{m.touches.length===2&&(r=i(m.touches),p=a.layoutZoom)},{passive:!0}),h.addEventListener("touchmove",m=>{if(m.touches.length===2&&r>0){m.preventDefault(),a.layoutZoom=Math.max(.6,Math.min(2.8,p*i(m.touches)/r));const $=document.getElementById("panoramaMap");$&&($.style.transform=`scale(${a.layoutZoom})`);const v=document.getElementById("layoutZoomPercent");v&&(v.textContent=`${Math.round(a.layoutZoom*100)}%`)}},{passive:!1}),h.addEventListener("touchend",m=>{m.touches.length<2&&(r=0)},{passive:!0})}document.getElementById("zoomIn")?.addEventListener("click",()=>{a.layoutZoom=Math.min(2.8,Math.round((a.layoutZoom+.2)*10)/10),M()}),document.getElementById("zoomOut")?.addEventListener("click",()=>{a.layoutZoom=Math.max(.6,Math.round((a.layoutZoom-.2)*10)/10),M()}),document.querySelectorAll("[data-zone]").forEach(r=>r.onclick=()=>M(r.dataset.zone)),document.querySelectorAll("[data-group]").forEach(r=>r.onclick=()=>M(e,r.dataset.group)),document.querySelectorAll("[data-sign]").forEach(r=>r.onchange=()=>{r.checked?a.selectedLayout.add(r.dataset.sign):a.selectedLayout.delete(r.dataset.sign),M(e,t)});const L=document.getElementById("selectAllLayout");L&&(L.onchange=()=>{d.forEach(r=>{const p=String(r.signId||r.code);L.checked?a.selectedLayout.add(p):a.selectedLayout.delete(p)}),M(e,t)});const u=document.getElementById("sendLayoutQueue");u&&(u.onclick=()=>{const r=d.filter(i=>a.selectedLayout.has(String(i.signId||i.code))),p=r.flatMap(i=>f.validate(i).map(m=>`\xCDtem ${i.code}: ${m}`));if(p.length){window.alert(`No es posible agregar carteles con datos incompletos:
`+p.slice(0,10).join(`
`));return}r.forEach(i=>a.queue.push({...i,qid:y.newId()})),_(),r.forEach(i=>a.selectedLayout.delete(String(i.signId||i.code))),E()})}const j=(window.CARTELERIA_OCCAM_SBA||[]).filter(e=>e.formato==="SBA"),B=new Set,X=e=>String(e||"").trim()||"Sin clasificar",Ae=[...new Set(j.map(e=>X(e.subgrupo)))].sort((e,t)=>e.localeCompare(t,"es")),ke=new Map(k.filter(e=>e.occamKey).map(e=>[`${e.campaignId}:${e.signId}`,e])),ve=e=>ke.get(`${e.matchCampaignId}:${e.matchSignId}`),ie=e=>{const t=ve(e);return t?f.validate(t):["Ficha t\xE9cnica no encontrada"]},he=e=>e.filter(t=>ie(t).length===0).length,D=(e,t)=>X(e)===X(t);function cyd57EnqueueRows(rows){const m=rows.filter(b=>B.has(b.layoutId)).map(b=>({row:b,sign:ve(b)})),$=m.filter(({sign:b})=>!b||f.validate(b).length),v=m.filter(({sign:b})=>b&&f.validate(b).length===0);if(!v.length){window.alert("No se agregaron carteles: "+$.slice(0,5).map(({row:b,sign:l})=>"\xCDtem "+b.codigo+": "+(l?f.validate(l).join("; "):"Ficha no encontrada")).join(`
`));return}v.forEach(({sign:b})=>a.queue.push({...b,qid:y.newId()})),v.forEach(({row:b})=>B.delete(b.layoutId)),_(),$.length&&window.alert(`${v.length} carteles agregados a la cola de impresión. ${$.length} pendientes (NO agregados):
`+$.slice(0,8).map(({row:b,sign:l})=>"\xCDtem "+b.codigo+": "+(l?f.validate(l).join("; "):"Ficha no encontrada")).join(`
`)),E()}function F(e=null,t=null){if(!a.local)return x();N();const filteredRows=window.CYD55_CATEGORIES.orderProducts(j.filter(row=>window.CYD55_CATEGORIES.matches(row,a.layoutListType||'all')),'department'),filteredGroups=Ae.filter(group=>filteredRows.some(row=>D(row.subgrupo,group)));const n=e?filteredRows.filter(i=>D(i.subgrupo,e)):filteredRows,o=[...new Set(n.map(i=>X(i.categoria)))].sort(window.CYD55_CATEGORIES.compareCategories),c=o.length>=4,d=e?c&&!t?null:t?n.filter(i=>D(i.categoria,t)):n:null,g=(d||[]).filter(i=>B.has(i.layoutId)).length,h=i=>Number.isFinite(i)?"$"+Math.round(i).toLocaleString("es-CL"):"Precio sin verificar",L=e?`${s(e)} \xB7 ${n.length} productos`:"";const departmentRows=e?n.filter(row=>ie(row).length===0):[],departmentChosen=departmentRows.filter(row=>B.has(row.layoutId)).length;I.innerHTML=`${w()}<section class="screen panorama-screen">
      <div class="panorama-head"><button class="btn back-home" id="layoutBack">\u2190 ${d?"Volver":e?"Departamentos":"Men\xFA"}</button>
        <div><h1>Layout panor\xE1mico promociones</h1><p>Listas SBA · ${filteredRows.length} productos · Departamento y Categoría · Productos A–Z</p></div></div>
      ${window.CYD55_CATEGORIES.picker(j,a.layoutListType||'all','data-layout-list-type')}
      ${e?`<div class="selection-tools"><label><input type="checkbox" id="selectAllDepartment" ${departmentRows.length&&departmentChosen===departmentRows.length?'checked':''} ${departmentRows.length?'':'disabled'}> Seleccionar todo el departamento (${departmentChosen}/${departmentRows.length})</label>${departmentRows.length<n.length?`<small>${n.length-departmentRows.length} con datos por revisar</small>`:""}<button class="btn primary" id="sendDepartment" ${departmentChosen?'':'disabled'}>Enviar ${departmentChosen} a cola de impresión</button></div>`:''}
      ${e?d===null?`<div class="panorama-breadcrumb">${L} \u203A Categor\xEDas</div>
      <div class="category-grid">${o.map(i=>`<button class="category-tile" data-category="${s(i)}"><strong>${s(i)}</strong><span>${n.filter(m=>D(m.categoria,i)).length} productos \xB7 ${he(n.filter(m=>D(m.categoria,i)))} imprimibles</span></button>`).join("")}</div>`:`<div class="panorama-breadcrumb">${L}${t?" \u203A "+s(t):""} \xB7 ${d.length} productos</div>
      <div class="selection-tools"><label><input type="checkbox" id="selectAllOccam" ${d.length&&g===d.length?"checked":""}> Seleccionar todos (${g}/${d.length})</label><button class="btn primary" id="sendOccam" ${g?"":"disabled"}>Enviar ${g} a cola de impresión</button></div>
      <div class="layout-product-list">${d.map(i=>`<div class="layout-product"><input type="checkbox" id="layout-select-${s(i.layoutId)}" data-occam="${s(i.layoutId)}" ${B.has(i.layoutId)?"checked":""}><label for="layout-select-${s(i.layoutId)}"><strong>${s(i.nombre||"Sin descripci\xF3n")}</strong><small>${s(i.marca)} \xB7 ${s(i.contenido)} \xB7 Producto ${s(i.codigo)} \xB7 ${s(i.mecanica)} \xB7 ${s(i.categoria)}</small>${window.CYD55_CATEGORIES.revisionNote(i)}<small>${ie(i).length?"Pendiente: "+s(ie(i).join("; ")):"\u2713 Listo para enviar a imprimir"} ${window.CYD55_CATEGORIES.printMark(ve(i))}</small></label><span class="layout-row-actions"><span class="cyd62-row-price"><b>${i.cantidad>1?i.cantidad+" × ":""}${h(i.precioPromo)}</b>${window.CYD55_CATEGORIES.priceBell(i)}</span><button class="btn ghost" type="button" data-layout-preview="${s(i.layoutId)}">Ver cartel</button></span></div>`).join("")}</div>
      <p class="panorama-hint">Fichas construidas con OCCAM SBA. Los registros con datos inconsistentes se bloquean para evitar errores de impresi\xF3n.</p>`:`<div class="panorama-tools"><span>Agrupadores por departamento</span><div><button class="btn" id="zoomOut">\u2212</button><strong id="layoutZoomPercent">${Math.round(a.layoutZoom*100)}%</strong><button class="btn" id="zoomIn">+</button></div></div>
      <div class="panorama-viewport" id="occamViewport" tabindex="0" aria-label="Mapa desplazable de departamentos"><div class="panorama-map" id="panoramaMap" style="zoom:${a.layoutZoom}">
      <div class="panorama-entrance">DEPARTAMENTOS DE PROMOCIONES SBA</div>
      ${filteredGroups.map(i=>`<button class="panorama-zone" data-subgroup="${s(i)}"><strong>${s(i)}</strong><span>${filteredRows.filter(m=>D(m.subgrupo,i)).length} productos \xB7 ${he(filteredRows.filter(m=>D(m.subgrupo,i)))} imprimibles</span></button>`).join("")}</div></div>
      `}
      <div class="layout-queue-bar"><span>Cola de impresión: <strong data-queue-count>${a.queue.length}</strong></span><button class="btn primary" id="goToQueue">Ver cola de impresión</button></div></section>`,document.getElementById("changeLocalTop").onclick=C,document.querySelectorAll("[data-layout-list-type]").forEach(button=>button.onclick=()=>{a.layoutListType=button.dataset.layoutListType;B.clear();F();}),document.getElementById("layoutBack").onclick=()=>{d?c&&t?F(e):F():e?F():z()},document.getElementById("goToQueue").onclick=E,document.querySelectorAll("[data-subgroup]").forEach(i=>i.onclick=()=>F(i.dataset.subgroup)),document.querySelectorAll("[data-category]").forEach(i=>i.onclick=()=>F(e,i.dataset.category));window.CYD55_CATEGORIES.bindPriceChanges(I,j,cyd64PriceActions());const departmentCheck=document.getElementById('selectAllDepartment');if(departmentCheck){departmentCheck.indeterminate=departmentChosen>0&&departmentChosen<departmentRows.length;departmentCheck.onchange=()=>{departmentRows.forEach(row=>departmentCheck.checked?B.add(row.layoutId):B.delete(row.layoutId));F(e,t);};}const u=document.getElementById("occamViewport"),r=document.getElementById("panoramaMap");function p(i,m,$){const v=Math.max(.65,Math.min(2.6,Math.round(i*100)/100));if(!u||!r||v===a.layoutZoom)return;const b=a.layoutZoom,l=u.getBoundingClientRect(),P=(m===void 0?l.left+l.width/2:m)-l.left,te=($===void 0?l.top+l.height/2:$)-l.top,Ge=(u.scrollLeft+P)/b,Ue=(u.scrollTop+te)/b;a.layoutZoom=v,r.style.zoom=String(v),document.getElementById("layoutZoomPercent").textContent=Math.round(v*100)+"%",u.scrollLeft=Ge*v-P,u.scrollTop=Ue*v-te}if(document.getElementById("zoomIn")?.addEventListener("click",()=>p(a.layoutZoom+.2)),document.getElementById("zoomOut")?.addEventListener("click",()=>p(a.layoutZoom-.2)),u){let i=0,m=1;const $=l=>Math.hypot(l[0].clientX-l[1].clientX,l[0].clientY-l[1].clientY);u.addEventListener("touchstart",l=>{l.touches.length===2&&(i=$(l.touches),m=a.layoutZoom)},{passive:!0}),u.addEventListener("touchmove",l=>{if(l.touches.length===2&&i){l.preventDefault();const P=(l.touches[0].clientX+l.touches[1].clientX)/2,te=(l.touches[0].clientY+l.touches[1].clientY)/2;p(m*$(l.touches)/i,P,te)}},{passive:!1}),u.addEventListener("touchend",l=>{l.touches.length<2&&(i=0)},{passive:!0}),u.addEventListener("wheel",l=>{(l.ctrlKey||l.metaKey)&&(l.preventDefault(),p(a.layoutZoom*(l.deltaY>0?.9:1.1),l.clientX,l.clientY))},{passive:!1});let v=null;u.addEventListener("pointerdown",l=>{l.pointerType==="mouse"&&l.button===0&&!l.target.closest("button")&&(v={x:l.clientX,y:l.clientY,left:u.scrollLeft,top:u.scrollTop},u.setPointerCapture(l.pointerId),u.classList.add("is-dragging"))}),u.addEventListener("pointermove",l=>{v&&(u.scrollLeft=v.left-(l.clientX-v.x),u.scrollTop=v.top-(l.clientY-v.y))});const b=()=>{v=null,u.classList.remove("is-dragging")};u.addEventListener("pointerup",b),u.addEventListener("pointercancel",b),u.addEventListener("keydown",l=>{const P={ArrowLeft:[-90,0],ArrowRight:[90,0],ArrowUp:[0,-90],ArrowDown:[0,90]};P[l.key]&&(l.preventDefault(),u.scrollBy({left:P[l.key][0],top:P[l.key][1],behavior:"smooth"}))})}document.querySelectorAll('[data-layout-preview]').forEach(button=>button.onclick=event=>{event.preventDefault();event.stopPropagation();const row=j.find(row=>row.layoutId===button.dataset.layoutPreview),sign=row&&ve(row);if(!sign){window.alert('No se encontró la ficha del cartel.');return;}window.CYD55_CATEGORIES.preview(sign,poster=>J({...poster,...(CYD_IS_MARKET(a.local)?{suppressLocal:true}:{})},'preview'),button);});document.querySelectorAll("[data-occam]").forEach(i=>i.onchange=()=>{i.checked?B.add(i.dataset.occam):B.delete(i.dataset.occam),F(e,t)}),document.getElementById("selectAllOccam")?.addEventListener("change",i=>{d.forEach(m=>{i.target.checked?B.add(m.layoutId):B.delete(m.layoutId)}),F(e,t)}),document.getElementById("sendOccam")?.addEventListener("click",()=>cyd57EnqueueRows(d));document.getElementById('sendDepartment')?.addEventListener('click',()=>cyd57EnqueueRows(departmentRows));}function E(){if(!a.local)return x();N();y.sync();I.innerHTML=`
      ${w()}
      <section class="screen">
        <div class="search-card">
          <div class="search-head">
            <h2>Ingresar \xEDtem</h2>
            <button class="btn back-home" id="backHome" type="button">Volver a inicio</button>
          </div>
          <form id="searchForm" class="search-row" autocomplete="off">
            <input id="itemInput" inputmode="numeric" pattern="[0-9]*" placeholder="Ingresar \xEDtem" value="${s(a.itemCode)}">
            <button class="btn search" type="submit">Buscar</button>
          </form>
          ${q()?'<button class="btn scan-item-btn" id="scanItemBtn" type="button">\u25A3 Escanear \xEDtem</button>':""}
          <div id="searchStatus"></div>
        </div>

        <section id="previewArea"></section>

        <section class="queue-section">
          <div class="section-title">
            <div class="queue-title-group">
              <h2>Cola de impresi\xF3n</h2>
              <span class="count">${a.queue.length}</span>
            </div>
            <button class="btn print print-inline" id="printBtn" type="button" ${a.queue.length?"":"disabled"}>
              Imprimir cola de impresión
            </button>
          </div>
          <div id="queueList"></div>
          <button class="btn clear-queue-bottom" id="clearQueue" type="button" ${a.queue.length?"":"disabled"}>
            Borrar toda la cola de impresión
          </button>
        </section>
      </section>
    `,document.getElementById("searchForm").addEventListener("submit",t=>{t.preventDefault(),ye()}),q()&&document.getElementById("scanItemBtn")?.addEventListener("click",()=>$e("item")),document.getElementById("backHome").addEventListener("click",z),document.getElementById("changeLocalTop").addEventListener("click",C),document.getElementById("printBtn").addEventListener("click",le),document.getElementById("clearQueue").addEventListener("click",()=>{a.queue.length&&window.confirm("\xBFBorrar todos los carteles de la cola de impresi\xF3n?")&&(a.queue=[],_(),V(),H())}),H(),V()}function C(){y.stop(),a.selectedLayout.clear(),B.clear(),a.local="",a.itemCode="",a.product=null,a.queue=[],localStorage.removeItem("carteleria.local"),x()}let itemSearchGeneration=0;
async function ye(fromScan=false){
 const input=document.getElementById('itemInput');if(!input)return;
 const t=input.value.trim(),generation=++itemSearchGeneration,scanned=fromScan===true;
 a.itemCode=t;window.CYD_EVENTS?.record(a.local,'search','Búsqueda de código '+t);a.product=null;
 const o=document.getElementById('searchStatus');
 if(!t){o.innerHTML='';H();return;}
 let n=k.filter(c=>String(c.code)===t||window.CYD66_BARCODE.equivalent(c.barcode,t)||String(c.sourceProductNbr||'')===t),known=[];
 if(!n.length&&/^\d{8,20}$/.test(t)){
  o.innerHTML='<div class="status">'+(scanned?'Código leído: '+s(t)+'. ':'')+'Buscando producto…</div>';H();
  try{known=(await loadManual()).get(t)||[];}catch{/* La búsqueda de promociones sigue disponible si no carga la maestra. */}
  if(generation!==itemSearchGeneration||!o.isConnected)return;
  const items=new Set(known.map(row=>String(row.item)));
  n=k.filter(c=>items.has(String(c.code)));
 }
 if(!n.length){
  o.innerHTML='<div class="status error">'+(scanned?'Código leído correctamente: '+s(t)+'. ':'')+(known.length?'Producto encontrado en la maestra, sin una promoción disponible en las listas vigentes.':'No hay un cartel disponible para este código en las listas vigentes.')+'</div>'+(known.length?'<button class="btn" id="searchManualFromCode" type="button">Crear cartel manual</button>':'');
  document.getElementById('searchManualFromCode')?.addEventListener('click',async()=>{renderManual();const field=document.getElementById('manualItem');if(field){field.value=t;await findManual(scanned);}});H();return;
 }
 if(n.length===1){a.product=n[0];o.innerHTML='<div class="status ok">✓ Producto encontrado <small>Ítem '+s(a.product.code)+' · '+s(a.product.brand||'')+'</small></div>';H();return;}
 // Un código puede tener varias campañas válidas: conservar la selección de cartel.
 o.innerHTML='<div class="status ok">Se encontraron '+n.length+' carteles para el ítem '+s(t)+'. Selecciona el que necesitas:</div>'+
 '<div class="item-matches">'+n.map((p,i)=>'<button class="item-match" type="button" data-match-index="'+i+'"><strong>'+s(p.name||'')+' · '+s(f.calc(p).price)+'</strong><small>'+s(p.brand||'')+' · '+s(p.listName||p.campaignName||'')+'</small><small>Cartel '+s(p.signId||'sin ID')+' · Campaña '+s(p.campaignId||'sin ID')+'</small></button>').join('')+'</div>';
 o.querySelectorAll('[data-match-index]').forEach(btn=>btn.addEventListener('click',()=>{
  const selected=n[Number(btn.dataset.matchIndex)];if(!selected)return;a.product=selected;
  o.innerHTML='<div class="status ok">✓ Cartel seleccionado <small>Ítem '+s(selected.code)+' · Cartel '+s(selected.signId||'')+' · '+s(selected.brand||'')+'</small></div>';H();
 }));H();
}function Je(e){return"$"+Math.round(Number(e||0)).toLocaleString("es-CL")}function Le(e){const t=String(e.name||"").trim(),n=String(e.size||"").trim();return!n||t.toUpperCase().includes(n.toUpperCase())?t:`${t} ${n}`}function Me(e){return f.unitMeasurePrice(e)}function Fe(e){return e.categoryId&&e.categoryName?`${e.categoryId} - ${e.categoryName}`:"CATEGOR\xCDA SIN CONFIRMAR"}function Pe(e){return e.campaignName||(f.mechanic(e)==="normal"?"LISTA 3 BARATO TODOS LOS DIAS":"LISTA 3 SBA - AHORA MAS BARATO")}function Re(e){if(!(f.savingAmount(e)>0))return"";if(f.mechanic(e)==="offer"){const t=f.calc(e),n=t.before,o=t.saving.replace(/^Ahorro\s*:?[ ]*/i,"");return`<div class="promo-strip offer-strip"><svg class="promo-strip-bg" viewBox="0 0 100 20" preserveAspectRatio="none" aria-hidden="true"><rect x="0" y="0" width="100" height="20" fill="#000"/></svg><span>Normal: ${s(n)}</span><span>Ahorro: ${s(o)}</span></div>`}if(f.mechanic(e)==="nx"){const t=f.calc(e),n=t.unitLabel.replace(/^P\.\s*unitario\s*:?[ ]*/i,""),o=t.saving.replace(/^Ahorro\s*:?[ ]*/i,"");return`<div class="promo-strip nx-strip"><svg class="promo-strip-bg" viewBox="0 0 100 20" preserveAspectRatio="none" aria-hidden="true"><rect x="0" y="0" width="100" height="20" fill="#000"/></svg><span>P. unitario: ${s(n)}</span><span>Ahorro: ${s(o)}</span></div>`}return""}function qe(e){const t=f.calc(e).price;if(f.mechanic(e)==="nx")return`<div class="price nx-main-price">${s(t)}</div>`;const n=t.replace(/^\$/,"");return`<div class="price standard-main-price"><span class="currency">$</span><span class="price-amount">${s(n)}</span></div>`}function Te(e){return f.validity(e)||"Vigencia: SIN DATOS \u2014 NO IMPRIMIR"}function J(e,t="preview"){const n=f.validate(e);if(n.length)return`<article class="poster-blocked">Datos por revisar · ${s(f.reference(e))}<small>${s(n.join("; "))}</small></article>`;const o=Me(e);return`
      <article class="poster ${t} ${f.mechanic(e)}">
        <div class="poster-inner">
          <div class="price-block">
            ${qe(e)}
            <div class="payment-line">pagando con todo medio de pago</div>
            ${Re(e)}
          </div>

          <div class="product-block">
            <div class="product-name">${s(Le(e))}</div>
            <div class="product-brand">${s(e.brand||"")}</div>
            ${o?`<div class="unit-price">${s(o)}</div>`:""}
          </div>

          <div class="poster-bottom">
            <div class="barcode-zone">
              ${Ne(e.barcode||e.code)}
              <div class="barcode-number">${s(e.barcode||e.code)}</div>
              ${e.barcodeOrigin==="ITEM_INTERNAL"?`<div class="footer-info">EAN interno de referencia \xB7 \xCDtem ${s(e.code)}</div>`:""}
              <div class="footer-info">${e.manual?"Cartelería manual":"Destacado: "+s(Pe(e))}${e.code?" &nbsp; Item: "+s(e.code):""}</div>
              ${e.manual?"":`<div class="footer-info">Categoría: ${s(Fe(e))}</div>`}
              ${e.suppressLocal?"":`<div class="footer-info local-line">Local: ${s(a.local)}</div>`}
            </div>
            ${e.manual?"":`<div class="validity">${s(Te(e))}</div>`}
          </div>
        </div>
      </article>
    `}function Ne(e){const t=String(e||"").replace(/\D/g,"");if(t.length!==13)return xe(t);const n={0:"0001101",1:"0011001",2:"0010011",3:"0111101",4:"0100011",5:"0110001",6:"0101111",7:"0111011",8:"0110111",9:"0001011"},o={0:"0100111",1:"0110011",2:"0011011",3:"0100001",4:"0011101",5:"0111001",6:"0000101",7:"0010001",8:"0001001",9:"0010111"},c={0:"1110010",1:"1100110",2:"1101100",3:"1000010",4:"1011100",5:"1001110",6:"1010000",7:"1000100",8:"1001000",9:"1110100"},d={0:"LLLLLL",1:"LLGLGG",2:"LLGGLG",3:"LLGGGL",4:"LGLLGG",5:"LGGLLG",6:"LGGGLL",7:"LGLGLG",8:"LGLGGL",9:"LGGLGL"},g=Number(t[0]);let h="101";for(let r=1;r<=6;r++){const p=Number(t[r]);h+=d[g][r-1]==="L"?n[p]:o[p]}h+="01010";for(let r=7;r<=12;r++)h+=c[Number(t[r])];h+="101";const L=1.05;let u="";for(let r=0;r<h.length;r++)if(h[r]==="1"){const p=r<3||r>=45&&r<50||r>=92;u+=`<rect x="${(r*L).toFixed(2)}" y="0" width="${L.toFixed(2)}" height="${p?28:24}"/>`}return`<svg class="barcode" viewBox="0 0 100 28" role="img" aria-label="C\xF3digo de barras ${s(t)}">${u}</svg>`}function xe(e){const t=String(e||"").replace(/\D/g,"");let n="",o=3;for(let c=0;c<t.length*3+12;c++){const g=(Number(t[c%Math.max(t.length,1)]||1)+c)%3+1;if(c%2===0&&(n+=`<rect x="${o}" y="1" width="${g}" height="${18+c%3*2}"/>`),o+=g+1,o>94)break}return`<svg class="barcode" viewBox="0 0 100 24">${n}</svg>`}function H(){const e=document.getElementById("previewArea");if(e){if(!a.product){e.innerHTML="";return}e.innerHTML=`
      <div class="preview-block">
        ${J(a.product,"preview")}
        ${f.validate(a.product).length?`<div class="status error">No se puede imprimir: ${s(f.validate(a.product).join("; "))}</div>`:""}
        <button class="btn add" id="addQueue" type="button" ${f.validate(a.product).length?"disabled":""}>Agregar a cola de impresión</button>
      </div>
    `,document.getElementById("addQueue").addEventListener("click",()=>{if(f.validate(a.product).length)return window.alert("Cartel con datos por revisar.");a.queue.push({...a.product,qid:y.newId()}),_(),a.product=null,a.itemCode="";const t=document.getElementById("itemInput");t&&(t.value="",t.focus());const n=document.getElementById("searchStatus");n&&(n.innerHTML=""),H(),V()})}}function V(){const e=document.getElementById("queueList"),t=document.querySelector(".count"),n=document.getElementById("printBtn"),o=document.getElementById("clearQueue");if(e){if(t&&(t.textContent=a.queue.length),n&&(n.disabled=!a.queue.length||Y().length>0,n.textContent=Y().length?`Revisar ${Y().length} dato(s)`:"Imprimir cola de impresión"),o&&(o.disabled=!a.queue.length),!a.queue.length){e.innerHTML='<div class="empty-queue">La cola de impresión est\xE1 vac\xEDa.</div>';return}e.innerHTML=a.queue.map((c,d)=>`
      <div class="queue-item">
        <div class="queue-mini">${J(c,"mini")}</div>
        <div class="queue-copy">
          <strong>${s(c.price)}</strong>
          <span>${s(f.reference(c))}</span>
          <small>${s(c.name)}</small>
        </div>
        <button class="remove" data-index="${d}" type="button" aria-label="Eliminar de la cola de impresión">\xD7</button>
      </div>
    `).join(""),e.querySelectorAll(".remove").forEach(c=>c.addEventListener("click",()=>{a.queue.splice(Number(c.dataset.index),1),_(),V()}))}}
function G(){window.CYD66_BARCODE.close();}
function U(value=''){return String(value).toUpperCase().replace(/[^0-9A-F]/g,'').slice(0,12);}
function $e(mode='item'){
 return window.CYD66_BARCODE.open({mode,onResult:async value=>{
  if(mode==='mac'){const mac=U(value);a.mobileMac=mac;localStorage.setItem(R,mac);Ee(mac);}
  else if(mode==='manual'){const input=document.getElementById('manualItem');if(input){input.value=value;await findManual(true);}}
  else{const input=document.getElementById('itemInput');if(input){input.value=value;a.itemCode=value;await ye(true);}}
 }});
}
function ce(){const e=document.getElementById("mobileMacInput"),t=U(e?.value||"");if(e&&(e.value=t),t.length===12){a.mobileMac=t,localStorage.setItem(R,t);const o=document.getElementById("mobileRFStatus");return o&&(o.className="rf-status ok",o.textContent=`\u2713 Impresora guardada: ${t}`),t}const n=document.getElementById("mobileRFStatus");return n&&(n.className="rf-status error",n.textContent="La MAC debe tener 12 caracteres hexadecimales."),""}function Ee(e=""){if(!a.queue.length)return E();const t=U(e||a.mobileMac||localStorage.getItem(R)||"");t.length===12&&(a.mobileMac=t,localStorage.setItem(R,t)),I.innerHTML=`
      ${w()}
      <section class="screen print-choice-screen mobile-rf-screen">
        <div class="print-choice-card rf-setup-card">
          <div class="print-choice-top">
            <div>
              <span class="print-choice-kicker">Modo m\xF3vil \xB7 Local ${s(a.local)}</span>
              <h2>Impresora Port\xE1til (RF)</h2>
              <p>En m\xF3vil no se solicita IP. Identifica la Zebra por su c\xF3digo MAC.</p>
            </div>
            <button class="btn back-home" id="backMobileRF" type="button">Volver</button>
          </div>

          <div class="rf-form-grid">
            <label class="rf-field">
              <span>Cartel a imprimir</span>
              <select id="rfItemSelect">
                ${a.queue.map((n,o)=>`<option value="${o}">${s(f.reference(n))} · ${s(n.price)} \xB7 ${s(n.name)}</option>`).join("")}
              </select>
            </label>

            <label class="rf-field">
              <span>MAC de impresora Zebra</span>
              <input id="mobileMacInput" autocomplete="off" autocapitalize="characters" maxlength="17" placeholder="Ej. 6095325D07AA" value="${s(t)}">
            </label>
            <div class="mobile-mac-actions">
              <button class="btn scan-item-btn" id="scanMacBtn" type="button">\u25A3 Escanear MAC</button>
              <button class="btn ghost" id="saveMacBtn" type="button">Guardar MAC</button>
            </div>
          </div>

          <div class="rf-proof-box">
            <strong>Formato RF aprobado</strong>
            <span>58 mm de ancho \xFAtil \xB7 2 flejes de 35 mm por cartel.</span>
            <span>Esta versi\xF3n m\xF3vil no modifica el funcionamiento actual de PC.</span>
          </div>

          <div id="mobileRFStatus" class="rf-status ${t?"ok":""}">${t?`\u2713 Impresora guardada: ${s(t)}`:"Escanea o escribe la MAC de la impresora."}</div>

          <div class="rf-actions rf-actions-main">
            <button class="btn print" id="prepareMobileRF" type="button">Preparar impresi\xF3n m\xF3vil</button>
          </div>
          <div id="mobilePrintInfo" class="mobile-print-info"></div>
        </div>
      </section>`,document.getElementById("changeLocalTop").addEventListener("click",C),document.getElementById("backMobileRF").addEventListener("click",()=>{const n=document.getElementById("mobileMacInput"),o=U(n?.value||a.mobileMac||"");o.length===12&&(a.mobileMac=o,localStorage.setItem(R,o)),E()}),document.getElementById("scanMacBtn").addEventListener("click",()=>$e("mac")),document.getElementById("saveMacBtn").addEventListener("click",ce),document.getElementById("mobileMacInput").addEventListener("change",ce),document.getElementById("mobileMacInput").addEventListener("input",n=>{const o=U(n.target.value);o.length===12&&(a.mobileMac=o,localStorage.setItem(R,o))}),document.getElementById("prepareMobileRF").addEventListener("click",async()=>{if(!await Z())return;const n=ce();if(!n)return;const o=Se(),c=document.getElementById("mobilePrintInfo");c&&(c.innerHTML=`<strong>Listo para conexi\xF3n m\xF3vil</strong><span>\xCDtem ${s(o?.code||"")} \xB7 Zebra ${s(n)}</span><span>El ZPL de los 2 flejes ya est\xE1 preparado. El siguiente paso es enlazar el canal Android \u2192 Zebra sin tocar la versi\xF3n PC.</span>`)})}async function le(){await Z()&&(I.innerHTML=`
      ${w()}
      <section class="screen print-choice-screen">
        <div class="print-choice-card">
          <div class="print-choice-top">
            <div>
              <span class="print-choice-kicker">Cola de impresi\xF3n \xB7 ${a.queue.length} cartel${a.queue.length===1?"":"es"}</span>
              <h2>Selecciona d\xF3nde imprimir</h2>
              <p>Elige el tipo de impresora que vas a utilizar.</p>
            </div>
            <button class="btn back-home" id="backToQueue" type="button">Volver a la cola de impresión</button>
          </div>

          <div class="printer-options">
            <button class="printer-option letter-option" id="printLetter" type="button">
              <span class="printer-option-icon" aria-hidden="true">\u25A3</span>
              <span class="printer-option-copy">
                <strong>Impresora Tama\xF1o 1/4 Carta</strong>
                <small>${q()?"Env\xEDo remoto al PC del local \xB7 selecciona la impresora por IP":"Impresora fija \xB7 mantiene la configuraci\xF3n actual de impresi\xF3n"}</small>
              </span>
              <span class="printer-option-arrow" aria-hidden="true">\u203A</span>
            </button>

            <button class="printer-option rf-option" id="printRF" type="button" ${CYD_PROFILE()?.features?.rf?'':'hidden disabled'}>
              <span class="printer-option-icon" aria-hidden="true">\u25A4</span>
              <span class="printer-option-copy">
                <strong>Impresora Port\xE1til (RF)</strong>
                <small>${q()?"Modo m\xF3vil \xB7 MAC Zebra \xB7 flujo RF en prueba":"Impresi\xF3n desde equipo port\xE1til \xB7 configuraci\xF3n RF por puente local"}</small>
              </span>
              <span class="printer-option-arrow" aria-hidden="true">\u203A</span>
            </button>
          </div>
        </div>
      </section>
    `,document.getElementById("changeLocalTop").addEventListener("click",C),document.getElementById("backToQueue").addEventListener("click",E),document.getElementById("printLetter").addEventListener("click",Qe),document.getElementById("printRF").addEventListener("click",Ve))}function de(){return`carteleria.carta.ip.${a.local||"sin-local"}`}function ue(e=""){return String(e).trim().replace(/\s+/g,"")}function Ie(e=""){const n=ue(e).split(".");return n.length===4&&n.every(o=>/^\d{1,3}$/.test(o)&&Number(o)>=0&&Number(o)<=255)}function ze(){const e=[];for(let t=0;t<a.queue.length;t+=4)e.push(a.queue.slice(t,t+4));return e.map((t,n)=>`
      <section class="print-page ${n<e.length-1?"page-break":""}">
        ${[0,1,2,3].map(o=>`
          <div class="print-cell">
            ${t[o]?J(t[o],"print"):""}
          </div>
        `).join("")}
      </section>
    `).join("")}function Oe(e){const t=ze(),n=String(e||"").replace(/<\/style/gi,"<\\/style");return`<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Carteler\xEDa \xB7 Local ${s(a.local)}</title>
  <style>${n}</style>
  <style>
    html,body{margin:0!important;padding:0!important;background:#fff!important}
    #remoteInfo{display:none!important}
    @media screen{#printRoot{display:block!important}}
  </style>
</head>
<body>
  <div id="app"></div>
  <div id="printRoot">${t}</div>
  <script>
    window.addEventListener('load', function(){
      setTimeout(function(){ window.print(); }, 350);
    });
    window.addEventListener('afterprint', function(){
      setTimeout(function(){ window.close(); }, 400);
    });
  <\/script>
</body>
</html>`}function W(e,t=""){const n=document.getElementById("letterRemoteStatus");n&&(n.className=`rf-status ${t}`.trim(),n.textContent=e)}async function je(){if(!await Z())return;const e=a.local,t=document.getElementById("letterPrinterIp"),n=document.getElementById("sendLetterRemote"),o=ue(t?.value||"");if(!Ie(o)){W("Ingresa una IP v\xE1lida de la impresora Tama\xF1o Carta.","error"),t?.focus();return}localStorage.setItem(de(),o),n&&(n.disabled=!0),W(`Enviando ${a.queue.length} cartel${a.queue.length===1?"":"es"} al local ${a.local}\u2026`,"working");try{const c=await fetch("styles.css",{cache:"no-store"});if(!c.ok)throw new Error(`No se pudo preparar el formato Carta (CSS ${c.status})`);const d=await c.text();if(a.local!==e)throw new Error("Cambiaste de local. Vuelve a elegir la cola de impresión.");if(!d.includes("@media print")||!d.includes(".print-cell"))throw new Error("La hoja de estilos de impresi\xF3n no es v\xE1lida");const g={kind:"carta_html",version:"v23",local:String(a.local),printer_ip:o,cantidad:a.queue.length,html:Oe(d)},h=await fetch(`${ae}/trabajo`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({local:String(a.local),printer_ip:o,contenido:JSON.stringify(g)})}),L=await h.json().catch(()=>({}));if(!h.ok||!L.ok)throw new Error(L.error||`HTTP ${h.status}`);S.print(g.local,g.cantidad,"carta_remota"),W(`\u2713 Trabajo enviado al local ${a.local} \xB7 impresora ${o}`,"ok");const u=document.getElementById("letterRemoteInfo");u&&(u.innerHTML=`<strong>Enviado correctamente</strong><span>El PC del local ${s(a.local)} recibir\xE1 la cola de impresión y la enviar\xE1 a la impresora ${s(o)}.</span><span>La cola de impresión del tel\xE9fono se mantiene para permitir una reimpresi\xF3n si fuera necesario.</span>`)}catch(c){W(`No se pudo enviar la impresi\xF3n: ${c.message||"error de conexi\xF3n"}`,"error")}finally{n&&(n.disabled=!1)}}function De(){if(!a.queue.length)return E();const e=localStorage.getItem(de())||"";I.innerHTML=`
      ${w()}
      <section class="screen print-choice-screen mobile-letter-screen">
        <div class="print-choice-card rf-setup-card">
          <div class="print-choice-top">
            <div>
              <span class="print-choice-kicker">Tama\xF1o Carta \xB7 Local ${s(a.local)}</span>
              <h2>Enviar a impresora del local</h2>
              <p>Indica la IP de la impresora. El tel\xE9fono env\xEDa la cola de impresión a Cloudflare y el PC del local la imprime autom\xE1ticamente.</p>
            </div>
            <button class="btn back-home" id="backMobileLetter" type="button">Volver</button>
          </div>

          <div class="rf-form-grid letter-remote-grid">
            <label class="rf-field">
              <span>IP impresora Tama\xF1o Carta</span>
              <input id="letterPrinterIp" inputmode="decimal" autocomplete="off" placeholder="Ej. 22.117.224.123" value="${s(e)}">
            </label>
          </div>

          <div class="rf-proof-box">
            <strong>Destino remoto</strong>
            <span>Local ${s(a.local)} identifica el PC receptor. La IP identifica cu\xE1l impresora instalada en ese PC debe usar.</span>
            <span>La \xFAltima IP usada queda guardada en este tel\xE9fono para este local.</span>
          </div>

          <div id="letterRemoteStatus" class="rf-status">Listo para enviar ${a.queue.length} cartel${a.queue.length===1?"":"es"}.</div>

          <div class="rf-actions rf-actions-main">
            <button class="btn print" id="sendLetterRemote" type="button">Enviar impresi\xF3n Tama\xF1o Carta</button>
          </div>

          <div id="letterRemoteInfo" class="rf-pending-box letter-remote-info">
            <strong>Formato conservado</strong>
            <span>4 carteles por hoja y desplazamiento de 10 mm hacia arriba, igual a la impresi\xF3n Carta ya aprobada.</span>
          </div>
        </div>
      </section>`,document.getElementById("changeLocalTop").addEventListener("click",C),document.getElementById("backMobileLetter").addEventListener("click",le),document.getElementById("sendLetterRemote").addEventListener("click",je),document.getElementById("letterPrinterIp").addEventListener("change",t=>{const n=ue(t.target.value);t.target.value=n,Ie(n)&&localStorage.setItem(de(),n)})}function ee(e){return`carteleria.rf.${e}.${a.local||"sin-local"}`}function T(e=""){return String(e).normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/[\^~]/g," ").replace(/[^\x20-\x7E]/g," ").replace(/\s+/g," ").trim()}function He(e){const o=T(Le(e)).slice(0,30),c=T(e.brand||"").slice(0,18),d=T(e.size||"").slice(0,12),g=T(e.price||""),h=T(e.code||""),L=T(a.local||""),u=T(e.note||e.saving||e.unitLabel||"").slice(0,38),r=String(e.barcode||"").replace(/\D/g,""),p=`^XA
^PW464
^LL280
^LH0,0
^FO16,18^GB432,2,2^FS
^FO16,48^A0N,30,30^FB432,1,0,C,0^FDPRECIO / PROMO^FS
^FO12,92^A0N,82,74^FB440,1,0,C,0^FD${g}^FS
^FO16,220^A0N,19,19^FB432,1,0,C,0^FDPAGANDO CON TODO MEDIO DE PAGO^FS
^FO16,258^GB432,2,2^FS
^XZ`;let i="";r.length>=8&&r.length<=14&&(i=`^FO52,154^BY2,2,54^BCN,54,Y,N,N^FD${r}^FS`);const m=`^XA
^PW464
^LL280
^LH0,0
^FO16,14^A0N,26,24^FB432,1,0,L,0^FD${o}^FS
^FO16,46^A0N,21,20^FD${c}${d?"  "+d:""}^FS
${u?`^FO16,76^A0N,18,18^FB432,2,2,L,0^FD${u}^FS`:""}
^FO16,122^A0N,18,18^FD${h?"Item "+h+"   ":""}Local ${L}^FS
${i}
^XZ`;return p+`
`+m}function A(e,t=""){const n=document.getElementById("rfStatus");n&&(n.className=`rf-status ${t}`.trim(),n.textContent=e)}function Se(){const e=document.getElementById("rfItemSelect"),t=Number(e?e.value:0);return a.queue[t]||a.queue[0]||null}function me(){const e=(document.getElementById("rfPrinterIp")?.value||"").trim(),t=(document.getElementById("rfPrinterId")?.value||"").trim().toUpperCase().replace(/[^0-9A-F]/g,"");return e&&localStorage.setItem(ee("ip"),e),t&&localStorage.setItem(ee("id"),t),{ip:e,id:t}}async function Ze(){A("Comprobando puente RF\u2026","working");try{const e=await fetch("http://127.0.0.1:8787/health",{method:"GET",cache:"no-store"});if(!e.ok)throw new Error(`HTTP ${e.status}`);const t=await e.json();A(t&&t.ok?"\u2713 Puente RF conectado":"Puente RF respondi\xF3, pero no est\xE1 listo.",t&&t.ok?"ok":"error")}catch{A("No se detecta el puente RF. Ejecuta rf-print-bridge.ps1 en este PC y vuelve a probar.","error")}}async function _e(){const e=Se()?.qid;if(!await Z())return;const t=a.queue.find(d=>d.qid===e),n=a.local;if(!t){A("No hay un cartel seleccionado.","error");return}const{ip:o,id:c}=me();if(!/^\d{1,3}(\.\d{1,3}){3}$/.test(o)){A("Ingresa la IP de la impresora RF.","error");return}if(c&&!/^[0-9A-F]{12}$/.test(c)){A("El c\xF3digo de impresora debe tener 12 caracteres hexadecimales.","error");return}A(`Enviando \xEDtem ${t.code} a la RF\u2026`,"working");try{const d=await fetch("http://127.0.0.1:8787/print",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({ip:o,port:9100,printerId:c,local:a.local,item:t.code,zpl:He(t)})}),g=await d.json().catch(()=>({}));if(!d.ok||!g.ok)throw new Error(g.error||`HTTP ${d.status}`);S.print(n,1,"rf"),A(`\u2713 \xCDtem ${t.code} enviado a ${o}:9100`,"ok")}catch(d){A(`No se pudo imprimir por RF: ${d.message||"error de conexi\xF3n"}`,"error")}}function Ve(){if(!a.queue.length)return E();const e=localStorage.getItem(ee("ip"))||"",t=localStorage.getItem(ee("id"))||"";I.innerHTML=`
      ${w()}
      <section class="screen print-choice-screen">
        <div class="print-choice-card rf-setup-card">
          <div class="print-choice-top">
            <div>
              <span class="print-choice-kicker">Impresora Port\xE1til (RF) \xB7 Local ${s(a.local)}</span>
              <h2>Prueba directa Zebra</h2>
              <p>Formato RF: cada cartel se imprime en 2 flejes consecutivos. El primero lleva la promo/precio y el segundo los datos del producto.</p>
            </div>
            <button class="btn back-home" id="backToPrintOptions" type="button">Volver</button>
          </div>

          <div class="rf-form-grid">
            <label class="rf-field">
              <span>Cartel a imprimir</span>
              <select id="rfItemSelect">
                ${a.queue.map((n,o)=>`<option value="${o}">\xCDtem ${s(n.code)} \xB7 ${s(n.price)} \xB7 ${s(n.name)}</option>`).join("")}
              </select>
            </label>

            <label class="rf-field">
              <span>IP impresora RF</span>
              <input id="rfPrinterIp" inputmode="decimal" placeholder="Ej. 23.117.226.10" value="${s(e)}">
            </label>

            <label class="rf-field">
              <span>C\xF3digo impresora / MAC (opcional para esta prueba)</span>
              <input id="rfPrinterId" autocomplete="off" maxlength="17" placeholder="Ej. 6095325D07AA" value="${s(t)}">
            </label>
          </div>

          <div class="rf-proof-box">
            <strong>Formato piloto RF</strong>
            <span>58 mm de ancho \xFAtil \xB7 2 flejes de 35 mm por cartel \xB7 separaci\xF3n f\xEDsica sugerida de 5 mm \xB7 ZPL por TCP 9100.</span>
            <span>La impresi\xF3n Tama\xF1o Carta no se modifica.</span>
          </div>

          <div id="rfStatus" class="rf-status">Primero comprueba que el puente RF est\xE9 activo.</div>

          <div class="rf-actions rf-actions-main">
            <button class="btn ghost" id="testRFBridge" type="button">Probar puente RF</button>
            <button class="btn print" id="sendRFPrint" type="button">Imprimir 1 cartel RF (2 flejes)</button>
          </div>

          <div class="rf-actions">
            <button class="btn back-home" id="backToQueueFromRF" type="button">Volver a la cola de impresión</button>
          </div>
        </div>
      </section>
    `,document.getElementById("changeLocalTop").addEventListener("click",C),document.getElementById("backToPrintOptions").addEventListener("click",le),document.getElementById("backToQueueFromRF").addEventListener("click",E),document.getElementById("testRFBridge").addEventListener("click",Ze),document.getElementById("sendRFPrint").addEventListener("click",_e),document.getElementById("rfPrinterIp").addEventListener("change",me),document.getElementById("rfPrinterId").addEventListener("change",me)}async function Qe(){if(!await Z())return;const weekly=await window.CYD69_WEEKLY.preparePrint(a.queue);const e=a.local,t=a.queue.length,n=[],ticket=window.CYD68_ALERTS.begin({products:a.queue,local:e,weekly,refresh:()=>cyd53Refresh(true)});for(let o=0;o<a.queue.length;o+=4)n.push(a.queue.slice(o,o+4));we.innerHTML=n.map((o,c)=>`
      <section class="print-page ${c<n.length-1?"page-break":""}">
        ${[0,1,2,3].map(d=>`
          <div class="print-cell">
            ${o[d]?J(o[d],"print"):""}
          </div>
        `).join("")}
      </section>
    `).join(""),window.CYD68_ALERTS.watch(ticket),window.print(),S.print(e,t,"carta_pc")}let cyd53LastRefresh=0,cyd80RefreshPromise=null,cyd80Navigation=0;
function cyd80QueueView(){return !!document.getElementById('queueList')||!!document.querySelector('.print-choice-screen');}
function cyd80SyncNeeded(){if(cyd80QueueView()||y.status.pending)return y.sync();}
async function cyd80Enter(render){
 const generation=++cyd80Navigation;
 if(!window.CYD_CATALOG_REVISION){
  I.innerHTML=w()+'<section class="screen"><p role="status">Cargando promociones…</p><button class="btn back-home" data-cyd80-back>Volver al inicio</button></section>';
  I.querySelector('[data-cyd80-back]').onclick=z;
 }
 try{await cyd53Refresh(true);if(generation===cyd80Navigation)render();}
 catch(error){if(generation!==cyd80Navigation)return;
  I.innerHTML=w()+'<section class="screen"><p role="status" data-cyd80-error></p><button class="btn primary" data-cyd80-retry>Reintentar</button><button class="btn back-home" data-cyd80-back>Volver al inicio</button></section>';
  I.querySelector('[data-cyd80-error]').textContent=error.message;
  I.querySelector('[data-cyd80-retry]').onclick=()=>cyd80Enter(render);I.querySelector('[data-cyd80-back]').onclick=z;
 }
}
async function cyd53Refresh(force=false){
 if(cyd80RefreshPromise)return cyd80RefreshPromise;
 if(!force&&window.CYD_CATALOG_REVISION&&Date.now()-cyd53LastRefresh<60000)return;
 cyd80RefreshPromise=(async()=>{
 const version=await window.CYD54_ACCESS.getJSON('/api/catalogo/version'),stamp=version.revision+'|'+version.day+'|'+(version.printRevision||0)+'|'+(version.specificationRevision||0);
 if(window.CYD_CATALOG_REVISION&&window.CYD_CATALOG_STAMP===stamp){cyd53LastRefresh=Date.now();return;}
 const data=await window.CYD54_ACCESS.getJSON('/api/catalogo');if(!Array.isArray(data.catalog)||!Array.isArray(data.layout))throw new Error('El catálogo recibido está incompleto. Vuelve a actualizar.');
 window.CYD68_ALERTS.adopt(data.catalog);window.CARTELERIA_CATALOG=data.catalog;window.CARTELERIA_OCCAM_SBA=data.layout;
 k.splice(0,k.length,...data.catalog.map(p=>({...p,...f.calc(p)})));j.splice(0,j.length,...data.layout);ke.clear();for(const p of k.filter(p=>p.occamKey))ke.set(`${p.campaignId}:${p.signId}`,p);Ae.splice(0,Ae.length,...[...new Set(j.map(p=>X(p.subgrupo)))].sort((x,y)=>x.localeCompare(y,'es')));
 a.queue=a.queue.map(p=>f.canonical(p,k));window.CYD_CATALOG_STAMP=data.revision+'|'+(data.day||version.day)+'|'+(data.printRevision??version.printRevision??0)+'|'+(data.specificationRevision??version.specificationRevision??0);window.CYD_CATALOG_REVISION=data.revision;cyd53LastRefresh=Date.now();
 })().finally(()=>{cyd80RefreshPromise=null;});return cyd80RefreshPromise;
}

function cyd53PrintHTML(products,css,suppressLocal=true,ticket=null){
 const pages=[];for(let i=0;i<products.length;i+=4){const items=products.slice(i,i+4);pages.push(`<section class="print-page ${i+4<products.length?'page-break':''}">${[0,1,2,3].map(n=>`<div class="print-cell">${items[n]?J({...items[n],suppressLocal},'print'):''}</div>`).join('')}</section>`);}
 return `<!doctype html><html lang="es"><head><meta charset="utf-8"><title></title><style>${String(css).replace(/<\/style/gi,'<\\/style')}</style><style>html,body{margin:0!important;padding:0!important;background:#fff!important}@media screen{#printRoot{display:block!important}}</style></head><body><div id="app"></div><div id="printRoot">${pages.join('')}</div><script>${window.CYD68_ALERTS.popupScript(ticket)}window.addEventListener('load',function(){setTimeout(function(){window.print()},350)});<\/script></body></html>`;
}


function cyd64PriceActions(){
 const profile=CYD_PROFILE(),isMarket=CYD_IS_MARKET(a.local);
 return {refresh:()=>cyd53Refresh(true),records:()=>window.CYD55_CATEGORIES.records(k),enqueue:cyd55Enqueue,print:cyd64PrintChanges,destinations:isMarket?profile.locals.map(code=>({code,name:profile.stores?.[code]?.name||'Local '+code})):null};
}
async function cyd64PrintChanges(keys,weeklyContext=null){
 if(window.CYD55_CATEGORIES.isMobileDevice()){window.CYD55_CATEGORIES.pcOnlyNotice();return false;}
 const popup=window.open('','_blank');if(!popup)throw new Error('Permite las ventanas emergentes para imprimir los cambios seleccionados.');
 const local=a.local;let ticket=null;
 try{
  popup.document.write('<p>Preparando los cambios de precios seleccionados…</p>');
  await cyd53Refresh(true);
  const products=keys.map(key=>k.find(product=>product.occamKey===key));
  if(!products.length||products.some(product=>!product||f.validate(product).length))throw new Error('Una promoción cambió o necesita revisión. Actualiza y vuelve a seleccionar.');
  if(a.local!==local)throw new Error('Cambiaste de local. Vuelve a seleccionar los carteles.');
  const response=await fetch('styles.css?v=v1.7.8',{cache:'no-store'});if(!response.ok)throw new Error('No se pudo cargar el formato de impresión.');
  const css=await response.text();
  if(!css.includes('@media print')||!css.includes('.print-cell'))throw new Error('El formato de impresión no está disponible. Reintenta.');
  const weekly=await window.CYD69_WEEKLY.preparePrint(products,weeklyContext);
  ticket=window.CYD68_ALERTS.begin({products,local,popup,weekly,refresh:()=>cyd53Refresh(true)});
  popup.document.open();popup.document.write(cyd53PrintHTML(products,css,CYD_IS_MARKET(local),ticket));popup.document.close();
  if(CYD_IS_STORE(local))S.print(local,products.length,'carta_pc');
  return true;
 }catch(error){window.CYD68_ALERTS.cancel(ticket);popup.close();throw error;}
}
async function cyd55Enqueue(records,destination){
 const isMarket=CYD_IS_MARKET(a.local),profile=CYD_PROFILE();

   const signs=records.map(r=>r.sign);
   if(isMarket){
    if(!profile.locals.includes(destination))throw new Error('Elige un local de tu mercado.');
    const response=await fetch(ae+'/api/cola?local='+encodeURIComponent(destination),{cache:'no-store'}),queue=await response.json();
    if(!response.ok||!queue.ok)throw new Error(queue.error||'No se pudo abrir la cola de impresión del local.');
    if(queue.items.length+signs.length>1000)throw new Error('La cola de impresión admite 1.000 carteles. Envía la selección en partes.');
    const saved=await fetch(ae+'/api/cola?local='+encodeURIComponent(destination),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:y.newId(),add:signs.map(sign=>({...sign,qid:y.newId()})),remove:[]})}),data=await saved.json();
    if(!saved.ok||!data.ok)throw new Error(data.error||'No se pudieron enviar los carteles.');
    window.CYD_EVENTS?.record(destination,'queue_change',signs.length+' carteles agregados por jefe de mercado '+profile.code);
    return signs.length+' carteles enviados a la cola de impresión del local '+destination+'.';
   }
   if(a.queue.length+signs.length>1000)throw new Error('La cola de impresión admite 1.000 carteles. Envía la selección en partes.');
   signs.forEach(sign=>a.queue.push({...sign,qid:y.newId()}));_();
   if(await y.sync())return signs.length+' carteles enviados a tu cola de impresión.';
   return signs.length+' carteles guardados en este equipo; se enviarán cuando vuelva la conexión.';
}

function cyd55OpenCategories(){
 if(!a.local)return x();
 const isMarket=CYD_IS_MARKET(a.local),profile=window.CYD54_ACCESS.profile;
 if(!isMarket)N();
 window.CYD55_CATEGORIES.open({
  host:I,header:w,catalog:()=>k,refresh:()=>cyd53Refresh(true),onHome:z,onChangeLocal:C,
  queueCount:()=>isMarket?null:a.queue.length,onQueue:isMarket?null:E,
  destinations:isMarket?profile.locals.map(code=>({code,name:profile.stores?.[code]?.name||'Local '+code})):null,
  renderSign:sign=>J({...sign,suppressLocal:isMarket},'preview'),
  enqueue:cyd55Enqueue,priceActions:cyd64PriceActions()
 });
}

function cyd69OpenWeekly(){
 if(!window.CYD69_WEEKLY.isPilot())return z();
 N();return window.CYD69_WEEKLY.open({host:I,header:w,catalog:()=>k,refresh:()=>cyd53Refresh(true),onHome:z,onQueue:E,onChangeLocal:C,queueCount:()=>a.queue.length,renderSign:sign=>J(sign,'preview'),enqueue:cyd55Enqueue,print:cyd64PrintChanges});
}

function cyd53MasterOpen(){
 a.local='';y.stop();
 window.CYD_MASTER.open({app:I,renderSign:J,printHTML:cyd53PrintHTML,logout(){window.CYD54_ACCESS.logout();}});
}

if(CYD_PROFILE()?.role==='master'){cyd53MasterOpen()}else a.local?(a.local=a.local.replace(/^0+(?=\d)/,""),N(),z(),S.start(a.local)):x()})();
