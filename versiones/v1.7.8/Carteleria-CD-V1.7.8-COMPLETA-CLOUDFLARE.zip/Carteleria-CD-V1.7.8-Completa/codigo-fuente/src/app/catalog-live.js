(async function(){
 const root=document.getElementById('app');window.CYD_API_BASE=location.origin;
 // El menú, el uso por local y Cartelería Manual no necesitan cargar promociones.
 window.CARTELERIA_CATALOG=[];window.CARTELERIA_OCCAM_SBA=[];
 window.CYD_CATALOG_REVISION=0;window.CYD_CATALOG_STAMP='';
 try{await window.CYD54_ACCESS.loadScript('app.js');}
 catch(error){
  root.innerHTML='<section class="landing"><h1>Cartelería C&D</h1><p role="status"></p><button class="btn primary" data-retry>Reintentar</button><button class="btn ghost" data-exit>Volver al acceso</button></section>';
  root.querySelector('p').textContent=error.message;
  root.querySelector('[data-retry]').onclick=()=>location.reload();root.querySelector('[data-exit]').onclick=()=>window.CYD54_ACCESS.logout();
 }
})();
