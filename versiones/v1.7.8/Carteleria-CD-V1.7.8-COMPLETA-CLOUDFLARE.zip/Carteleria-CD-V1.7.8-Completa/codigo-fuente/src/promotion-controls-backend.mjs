// V1.5. Disponibilidad nacional de un cartel concreto, sin alterar sus precios.
const cyd73key=p=>p.occamKey||'legacy:'+p.campaignId+':'+p.signId;
function cyd73catalog(catalog,state){
  const blocks=state.promotionBlocks||{};
  return catalog.map(p=>{const block=blocks[cyd73key(p)];return block?{...p,promotionBlocked:true,promotionBlock:block}:p;});
}
async function cyd73change(req,env,principal){
  if(principal.profile.role!=='master')cyd53error('Solo Administrador puede bloquear o desbloquear promociones.',403);
  const body=await cyd53body(req,1500000);
  if(!Array.isArray(body.keys)||!body.keys.length||body.keys.length>5000||body.keys.some(key=>typeof key!=='string'||!key||key.length>300)||typeof body.blocked!=='boolean'||!Number.isSafeInteger(body.revision))cyd53error('Selecciona los carteles y actualiza la lista antes de confirmar.');
  const id=String(body.id||'');if(!/^[A-Za-z0-9._:-]{8,128}$/.test(id))cyd53error('La operación no tiene una referencia válida.');
  const reason=String(body.reason||'').replace(/\s+/g,' ').trim();if(body.blocked&&(!reason||reason.length>200))cyd53error('Escribe un motivo de bloqueo de hasta 200 caracteres.');
  await cyd53init(env);
  const requestHash=await cyd54sha(JSON.stringify([[...new Set(body.keys)].sort(),body.blocked,reason]));
  const applied=await env.DB.prepare('SELECT revision,changed,request_hash FROM carteleria_promotion_audit73 WHERE id=?').bind(id).first();
  if(applied){if(applied.request_hash!==requestHash)cyd53error('Esa referencia pertenece a otro cambio. Actualiza y vuelve a confirmar.',409);return cyd54json({ok:true,alreadyApplied:true,revision:applied.revision,changed:applied.changed,scope:'all_stores',affectedStores:principal.profile.locals.length});}
  const current=await cyd53state(env);if(body.revision!==current.revision)cyd53error('La lista cambió en otro equipo. Actualiza antes de bloquear o desbloquear.',409);
  const keys=[...new Set(body.keys)],catalog=cyd53catalog(current.state),known=new Set(catalog.map(cyd73key));
  if(keys.some(key=>!known.has(key)))cyd53error('Un cartel ya no está en la lista vigente. Actualiza la vista.',409);
  const state=JSON.parse(JSON.stringify(current.state)),blocks={...(state.promotionBlocks||{})},changed=[],now=new Date().toISOString();
  for(const key of keys){if(Boolean(blocks[key])===body.blocked)continue;if(body.blocked)blocks[key]={reason,updatedAt:now,updatedBy:'Administrador'};else delete blocks[key];changed.push(key);}
  if(!changed.length)return cyd54json({ok:true,revision:current.revision,changed:0,scope:'all_stores',affectedStores:principal.profile.locals.length});
  state.promotionBlocks=blocks;state.promotionBlockOperation=id;
  const encoded=JSON.stringify(state);if(new TextEncoder().encode(encoded).length>1700000)cyd53error('El cambio supera el tamaño disponible de la lista. Reduce el motivo y vuelve a intentar.',413);
  const revision=current.revision+1;
  await env.DB.batch([
    env.DB.prepare('INSERT OR IGNORE INTO carteleria_promo_versions53 (revision,data,saved_at) SELECT revision,data,updated_at FROM carteleria_promos53 WHERE id=1 AND revision=?').bind(current.revision),
    env.DB.prepare('UPDATE carteleria_promos53 SET data=?,revision=?,updated_at=? WHERE id=1 AND revision=?').bind(encoded,revision,now,current.revision),
    env.DB.prepare("INSERT OR IGNORE INTO carteleria_promotion_audit73 (id,action,keys,reason,revision,changed,occurred_at,actor,request_hash) SELECT ?,?,?,?,?,?,?,?,? WHERE EXISTS (SELECT 1 FROM carteleria_promos53 WHERE id=1 AND revision=? AND json_extract(data,'$.promotionBlockOperation')=?)").bind(id,body.blocked?'block':'unblock',JSON.stringify(changed),body.blocked?reason:'Promoción reactivada',revision,changed.length,now,'Administrador',requestHash,revision,id)
  ]);
  const saved=await env.DB.prepare('SELECT revision,changed FROM carteleria_promotion_audit73 WHERE id=?').bind(id).first();if(!saved)cyd53error('Otra carga modificó las promociones. Actualiza y vuelve a confirmar.',409);
  return cyd54json({ok:true,revision:saved.revision,changed:saved.changed,blocked:body.blocked,scope:'all_stores',affectedStores:principal.profile.locals.length});
}
function cyd73queueBlocked(entry,blocks){
  if(!entry||entry.manual===true)return false;
  const campaign=String(entry.campaignId||''),sign=String(entry.signId||'');
  if(blocks['legacy:'+campaign+':'+sign])return true;
  if(!campaign.startsWith('OCCAM53:')||!sign.startsWith(campaign+':'))return false;
  const pn=sign.slice(campaign.length+1);return /^\d{1,20}$/.test(pn)&&!!blocks[CYD53_E.norm(campaign.slice(8))+'|'+pn];
}
async function cyd73queue(req,env,ctx,principal,url){
  cyd54scope(principal,url.searchParams.get('local'));
  if(!['GET','POST'].includes(req.method))return CYD54_BASE.fetch(req,env,ctx);
  // Conserva la operación original para mantener los reintentos idempotentes.
  // Las referencias guardadas no quedan disponibles mientras dure el bloqueo.
  const response=await CYD54_BASE.fetch(req,env,ctx);if(!response.ok)return response;
  const result=await response.json();if(!Array.isArray(result.items))return cyd54json(result,response.status);
  // La sincronización frecuente consulta solo el mapa de bloqueos, sin reconstruir el catálogo.
  await cyd53init(env);const row=await env.DB.prepare("SELECT json_extract(data,'$.promotionBlocks') AS blocks FROM carteleria_promos53 WHERE id=1").first(),blocks=JSON.parse(row?.blocks||'{}');
  const items=result.items.filter(p=>!cyd73queueBlocked(p,blocks)),unavailableCount=result.items.length-items.length;
  return cyd54json({...result,items,unavailableCount,unavailableMessage:unavailableCount?'Promoción bloqueada: '+unavailableCount+' cartel(es) no disponibles para imprimir.':''},response.status);
}
