
// V1.6. Revisión del mercado 814, con historial independiente por local.
const CYD69_INIT=new WeakMap();
function cyd69locals(env){return [...(env.roster.markets['814']||[])].sort((a,b)=>Number(a)-Number(b));}
const cyd69add=(day,days)=>new Date(new Date(day+'T12:00:00Z').getTime()+days*86400000).toISOString().slice(0,10);
const cyd69monday=day=>cyd69add(day,-((new Date(day+'T12:00:00Z').getUTCDay()+6)%7));
function cyd69week(value,today=cyd53day(),allowFuture=false){
  const week=value||cyd69monday(today<CYD74_START?CYD74_START:today),max=cyd69add(cyd69monday(allowFuture&&today<CYD74_START?CYD74_START:today),allowFuture?14:0);
  if(!/^\d{4}-\d{2}-\d{2}$/.test(week)||!Number.isFinite(Date.parse(week+'T12:00:00Z'))||cyd69add(week,0)!==week||cyd69monday(week)!==week||week>max)cyd53error('Elige una semana válida del plan de revisión.');
  return week;
}
async function cyd69init(env){
  await cyd53init(env);
  if(!CYD69_INIT.has(env.DB))CYD69_INIT.set(env.DB,env.DB.batch([
    env.DB.prepare('CREATE TABLE IF NOT EXISTS carteleria_weekly_plans69 (local TEXT NOT NULL,week_start TEXT NOT NULL,created_at TEXT NOT NULL,start_day TEXT NOT NULL,catalog_revision INTEGER NOT NULL,version INTEGER NOT NULL DEFAULT 1,data TEXT NOT NULL,PRIMARY KEY(local,week_start))'),
    env.DB.prepare('CREATE TABLE IF NOT EXISTS carteleria_weekly_reviews69 (local TEXT NOT NULL,week_start TEXT NOT NULL,category_key TEXT NOT NULL,scheduled_day TEXT NOT NULL,reviewed_at TEXT NOT NULL,catalog_revision INTEGER NOT NULL,reviewed_lists TEXT NOT NULL,PRIMARY KEY(local,week_start,category_key))'),
    env.DB.prepare('CREATE TABLE IF NOT EXISTS carteleria_weekly_prints69 (local TEXT NOT NULL,week_start TEXT NOT NULL,category_key TEXT NOT NULL,product_key TEXT NOT NULL,fingerprint TEXT NOT NULL,scheduled_day TEXT NOT NULL,printed_at TEXT NOT NULL,PRIMARY KEY(local,week_start,category_key,product_key,fingerprint))')
  ]).catch(error=>{CYD69_INIT.delete(env.DB);throw error;}));
  await CYD69_INIT.get(env.DB);
}
function cyd69scope(principal,local,write=false){
  if(write&&principal.profile.role!=='store')cyd53error('La revisión se confirma desde el acceso del local.',403);
  if(!['store','master'].includes(principal.profile.role))cyd53error('La revisión semanal está habilitada para los locales del mercado 814 y Administrador.',403);
  local=cyd54scope(principal,local||principal.profile.code);
  if(!cyd69locals(principal).includes(local))cyd53error('La revisión semanal está habilitada para todos los locales del mercado 814.',403);
  return local;
}
function cyd69queueContext(value){
  if(!value||typeof value!=='object'||typeof value.week!=='string'||typeof value.key!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(value.week)||!/^[A-Za-z0-9_-]{43}$/.test(value.key))cyd53error('Referencia de revisión semanal inválida.');
  return {week:value.week,key:value.key};
}
const cyd69fingerprint=p=>JSON.stringify([p.occamKey,p.code,p.barcode,p.qty,p.offer,p.unit]);
async function cyd69groups(catalog,today=cyd53day()){
  const byCategory=new Map();
  for(const p of catalog.filter(p=>p.occamKey&&!p.promotionBlocked&&cyd70active(p,today))){
    const department=String(p.subgrupo||'Sin departamento').trim(),categoryId=String(p.categoryId||'').trim(),categoryName=String(p.categoryName||'Sin categoría').trim();
    const id=JSON.stringify([CYD53_E.norm(department),categoryId||CYD53_E.norm(categoryName)]);
    if(!byCategory.has(id))byCategory.set(id,{department,categoryId,categoryName,products:[]});
    byCategory.get(id).products.push(p);
  }
  const out=new Map();
  await Promise.all([...byCategory].map(async([id,group])=>{
    const key=await cyd54sha(id),items=group.products.map(p=>({key:p.occamKey,token:cyd69fingerprint(p),family:cyd68family(p.occamList)})).sort((a,b)=>a.key.localeCompare(b.key));
    const counts={red:0,yellow:0,other:0};items.forEach(p=>counts[p.family]++);
    out.set(key,{key,department:group.department,categoryId:group.categoryId,categoryName:group.categoryName,total:items.length,counts,items,signature:await cyd54sha(JSON.stringify(items)),validUntil:cyd70validUntil(group.products),active:true});
  }));
  return out;
}
function cyd69metadata(group){return {key:group.key,department:group.department,categoryId:group.categoryId,categoryName:group.categoryName,total:group.total,counts:group.counts,validUntil:group.validUntil||null,active:group.active!==false};}
function cyd69assign(categories,week,start,existing=[]){
  const days=Array.from({length:7},(_,i)=>cyd69add(week,i)).filter(d=>d>=start),loads=new Map(days.map(day=>[day,{total:0,count:0,departments:new Map()}]));
  for(const c of existing){const load=loads.get(c.day);if(load&&c.active!==false){load.total+=c.total;load.count++;load.departments.set(c.department,(load.departments.get(c.department)||0)+1);}}
  return [...categories].sort((a,b)=>b.total-a.total||a.key.localeCompare(b.key)).map(c=>{
    const day=[...days].sort((a,b)=>{const x=loads.get(a),y=loads.get(b);return x.total-y.total||(x.departments.get(c.department)||0)-(y.departments.get(c.department)||0)||x.count-y.count||a.localeCompare(b);})[0];
    const load=loads.get(day);load.total+=c.total;load.count++;load.departments.set(c.department,(load.departments.get(c.department)||0)+1);
    return {...c,day};
  });
}
async function cyd69ensurePlans(env,current,groups,today){return cyd70ensurePlans(env,current,groups,today);}
async function cyd69plan(env,local,week,current,groups,today){
  const cached=env.cyd74Plans?.get(local+'|'+week);if(cached!==undefined)return cached;
  const row=await env.DB.prepare('SELECT * FROM carteleria_weekly_plans69 WHERE local=? AND week_start=?').bind(local,week).first();
  return row?{...row,data:JSON.parse(row.data)}:null;
}
function cyd69stats(categories,today){
  const active=categories.filter(c=>c.active!==false),due=active.filter(c=>c.day<today),on=due.filter(c=>c.status==='on'),late=due.filter(c=>c.status==='late'),missed=due.filter(c=>c.status==='missed');
  const current=active.filter(c=>c.day===today);
  return {total:active.length,reviewed:active.filter(c=>c.review).length,due:due.length,onTime:on.length,late:late.length,missed:missed.length,adherence:due.length?Math.round(on.length/due.length*100):null,todayTotal:current.length,todayReviewed:current.filter(c=>c.review).length,latePrints:categories.reduce((sum,c)=>sum+c.latePrints,0)};
}
async function cyd69view(env,local,plan,groups,current,today,activation){
  if(!plan)return {local,week:null,today,activation,categories:[],stats:cyd69stats([],today)};
  if(plan.data.cycle70?.policy71)return cyd71view(env,local,plan,groups,current,today,activation);
  const [reviewResult,printResult]=await env.DB.batch([
    env.DB.prepare('SELECT * FROM carteleria_weekly_reviews69 WHERE local=? AND week_start=?').bind(local,plan.week_start),
    env.DB.prepare('SELECT category_key,product_key,fingerprint,printed_at,scheduled_day FROM carteleria_weekly_prints69 WHERE local=? AND week_start=?').bind(local,plan.week_start)
  ]);
  const reviews=new Map(reviewResult.results.map(r=>[r.category_key,r]));
  const categories=plan.data.categories.map(c=>{
    const saved=reviews.get(c.key),review=saved?{reviewedAt:saved.reviewed_at,day:H(new Date(saved.reviewed_at)),revision:saved.catalog_revision}:null;
    const prints=printResult.results.filter(p=>p.category_key===c.key).map(p=>({key:p.product_key,token:p.fingerprint,printedAt:p.printed_at,late:H(new Date(p.printed_at))>p.scheduled_day}));
    const latePrints=new Set(prints.filter(p=>p.late).map(p=>p.key)).size;
    const status=c.active===false?'inactive':review?(review.day===c.day?'on':'late'):c.day<today?'missed':c.day===today?'today':'planned';
    const live=groups.get(c.key);
    return {...c,status,review,prints,latePrints,printed:new Set(prints.map(p=>p.key)).size,items:live?.items||[],signature:live?.signature||null};
  }).sort((a,b)=>a.day.localeCompare(b.day)||a.department.localeCompare(b.department,'es')||a.categoryName.localeCompare(b.categoryName,'es'));
  return {local,week:plan.week_start,startDay:plan.start_day,today,activation,revision:current.revision,planVersion:plan.version,categories,stats:cyd69stats(categories,today)};
}
async function cyd69get(env,principal,url){
  const local=cyd69scope(principal,url.searchParams.get('local')||undefined),today=cyd53day(),week=cyd69week(url.searchParams.get('week'),today,true),{current,groups}=await cyd79weekly(env);
  await cyd69ensurePlans(env,current,groups,today);const activation=await cyd74activation(env,local),plan=await cyd69plan(env,local,week,current,groups,today);
  if(!plan&&week>cyd69monday(today))cyd53error('Esa semana está fuera del ciclo disponible.');
  return cyd54json({ok:true,...await cyd69view(env,local,plan,groups,current,today,activation),cycle:await cyd70cycleView(env,local,plan,today),maxWeek:await cyd70maxWeek(env,today),restartDate:CYD74_START,market:'814',history:week<CYD74_START,readOnly:principal.profile.role!=='store'||week<CYD74_START});
}
async function cyd69review(req,env,principal){
  const body=await cyd53body(req,5000),local=cyd69scope(principal,body.local,true),today=cyd53day(),week=cyd69week(body.week,today);
  if(week<CYD74_START)cyd53error('El plan anterior al 16/11 quedó en el historial y es solo de consulta.',409);
  if(typeof body.key!=='string'||!/^[A-Za-z0-9_-]{43}$/.test(body.key))cyd53error('La categoría no es válida.');
  const {current:latest,groups:latestGroups}=await cyd79weekly(env);await cyd69ensurePlans(env,latest,latestGroups,today);
  const plan=await env.DB.prepare('SELECT data FROM carteleria_weekly_plans69 WHERE local=? AND week_start=?').bind(local,week).first(),category=plan?JSON.parse(plan.data).categories.find(c=>c.key===body.key):null;
  if(!category||category.active===false)cyd53error('La categoría ya no está activa en este plan. Actualiza la revisión.',409);
  if(category.day>today)cyd53error('Esta categoría todavía no llega a su día de revisión.');
  const planData=JSON.parse(plan.data);if(planData.cycle70?.policy71)return cyd71review(req,env,principal,body,local,today,week,planData,category);
  const prior=await env.DB.prepare('SELECT reviewed_at FROM carteleria_weekly_reviews69 WHERE local=? AND week_start=? AND category_key=?').bind(local,week,body.key).first();
  if(prior)return cyd54json({ok:true,alreadyReviewed:true,reviewedAt:prior.reviewed_at});
  const {current,groups}=await cyd79weekly(env),group=groups.get(body.key);
  if(!group||body.signature!==group.signature)cyd53error('La categoría cambió desde que la abriste. Actualiza y vuelve a revisar sus listas.',409);
  const required=['red','yellow',...(group.counts.other?['other']:[])];
  if(body.confirmed!==true||!Array.isArray(body.lists)||required.some(f=>!body.lists.includes(f)))cyd53error('Confirma la revisión de EDLP y Campaña antes de cerrar la categoría.');
  const now=new Date().toISOString();
  const result=await env.DB.prepare("INSERT OR IGNORE INTO carteleria_weekly_reviews69 (local,week_start,category_key,scheduled_day,reviewed_at,catalog_revision,reviewed_lists) SELECT ?,?,?,?,?,?,? WHERE EXISTS (SELECT 1 FROM carteleria_promos53 WHERE id=1 AND revision=?) AND EXISTS (SELECT 1 FROM carteleria_weekly_plans69 p,json_each(p.data, '$.categories') c WHERE p.local=? AND p.week_start=? AND json_extract(c.value, '$.key')=? AND json_extract(c.value, '$.day')=?)").bind(local,week,body.key,category.day,now,current.revision,JSON.stringify(required),current.revision,local,week,body.key,category.day).run();
  if(!Number(result.meta?.changes)){
    const existing=await env.DB.prepare('SELECT reviewed_at FROM carteleria_weekly_reviews69 WHERE local=? AND week_start=? AND category_key=?').bind(local,week,body.key).first();
    if(!existing)cyd53error('Las promociones cambiaron durante la revisión. Actualiza y vuelve a confirmar.',409);
    return cyd54json({ok:true,alreadyReviewed:true,reviewedAt:existing.reviewed_at});
  }
  return cyd54json({ok:true,reviewedAt:now,late:today>category.day});
}
async function cyd69printStatements(entries,env,principal,current){
  if(entries===undefined||Array.isArray(entries)&&!entries.length)return {statements:[],count:0,late:0};
  const local=cyd69scope(principal,principal.profile.code,true),today=cyd53day();
  if(!Array.isArray(entries)||entries.length>1000)cyd53error('La selección de impresión semanal no es válida.');
  if(today<CYD74_START)return {statements:[],count:0,late:0};
  const groups=await cyd69groups(cyd53catalog(current.state));await cyd69ensurePlans(env,current,groups,today);
  const plans=new Map(),clean=new Map();
  for(const entry of entries){
    if(!entry||typeof entry.key!=='string'||entry.key.length>250||typeof entry.token!=='string'||entry.token.length>700||typeof entry.categoryKey!=='string'||!/^[A-Za-z0-9_-]{43}$/.test(entry.categoryKey))cyd53error('La referencia de impresión semanal no es válida.');
    const week=cyd69week(entry.week,today,true);
    if(week<CYD74_START)continue;
    if(!plans.has(week)){const row=await env.DB.prepare('SELECT data FROM carteleria_weekly_plans69 WHERE local=? AND week_start=?').bind(local,week).first();if(!row)cyd53error('El plan de revisión no está disponible. Actualiza antes de imprimir.',409);plans.set(week,JSON.parse(row.data));}
    const category=plans.get(week).categories.find(c=>c.key===entry.categoryKey),group=groups.get(entry.categoryKey),product=group?.items.find(p=>p.key===entry.key);
    if(!category||category.active===false||!product||product.token!==entry.token)cyd53error('Un cartel de la revisión cambió desde que preparaste la impresión. Actualiza y vuelve a imprimirlo.',409);
    clean.set(week+'|'+entry.categoryKey+'|'+entry.key,{week,key:entry.key,categoryKey:entry.categoryKey,token:entry.token,scheduled:category.day,cycle:plans.get(week).cycle70?.policy71?plans.get(week).cycle70.start:null});
  }
  const rows=[...clean.values()],now=new Date().toISOString(),legacy=rows.filter(r=>!r.cycle),corrected=rows.filter(r=>r.cycle),statements=[];
  if(legacy.length)statements.push(env.DB.prepare("INSERT INTO carteleria_weekly_prints69 (local,week_start,category_key,product_key,fingerprint,scheduled_day,printed_at) SELECT ?,json_extract(value,'$.week'),json_extract(value,'$.categoryKey'),json_extract(value,'$.key'),json_extract(value,'$.token'),json_extract(value,'$.scheduled'),? FROM json_each(?) WHERE EXISTS (SELECT 1 FROM carteleria_promos53 WHERE id=1 AND revision=?) ON CONFLICT(local,week_start,category_key,product_key,fingerprint) DO UPDATE SET printed_at=excluded.printed_at").bind(local,now,JSON.stringify(legacy),current.revision));
  if(corrected.length){await cyd71init(env);statements.push(env.DB.prepare("INSERT INTO carteleria_cycle_prints71 (local,cycle_start,category_key,product_key,fingerprint,scheduled_day,printed_at) SELECT ?,json_extract(value,'$.cycle'),json_extract(value,'$.categoryKey'),json_extract(value,'$.key'),json_extract(value,'$.token'),json_extract(value,'$.scheduled'),? FROM json_each(?) WHERE EXISTS (SELECT 1 FROM carteleria_promos53 WHERE id=1 AND revision=?) ON CONFLICT(local,cycle_start,category_key,product_key,fingerprint) DO UPDATE SET printed_at=excluded.printed_at").bind(local,now,JSON.stringify(corrected),current.revision));}
  return {statements,count:rows.length,late:rows.filter(r=>r.scheduled<today).length};
}
async function cyd69report(env,principal,url){
  if(principal.profile.role!=='master')cyd53error('El resumen semanal está disponible por ahora solo para Administrador.',403);
  const today=cyd53day(),week=cyd69week(url.searchParams.get('week'),today,true),{current,groups}=await cyd79weekly(env);
  await cyd69ensurePlans(env,current,groups,today);const activation=await cyd74activation(env),rows=[],locals=cyd69locals(env);await cyd74primeViews(env,locals,week);
  for(const local of locals){const plan=await cyd69plan(env,local,week,current,groups,today);const view=await cyd69view(env,local,plan,groups,current,today,activation);rows.push({...view,cycle:await cyd70cycleView(env,local,plan,today),name:env.roster.stores[local]?.name||'Local '+local,market:env.roster.localMarket[local],marketName:env.roster.marketNames[env.roster.localMarket[local]]});}
  if(week>cyd69monday(today)&&rows.every(row=>!row.week))cyd53error('Esa semana está fuera del ciclo disponible.');
  return cyd54json({ok:true,today,week,activation,restartDate:CYD74_START,market:'814',history:week<CYD74_START,maxWeek:await cyd70maxWeek(env,today),rows,asOf:new Date().toISOString()});
}
async function cyd69route(req,env,principal,url){
  if(url.pathname==='/api/semanal/referencias-impresion'&&req.method==='POST')return cyd70printReferences(req,env,principal);
  if(url.pathname==='/api/semanal'&&req.method==='GET')return cyd69get(env,principal,url);
  if(url.pathname==='/api/semanal/revisar'&&req.method==='POST')return cyd69review(req,env,principal);
  if(url.pathname==='/api/semanal/resumen'&&req.method==='GET')return cyd69report(env,principal,url);
  return null;
}
