// V1.7.7 · Adherencia de impresión de cartelería por mercado/local/producto.
// Inicia un registro nuevo; no infiere productos impresos desde eventos históricos de cantidad.
const CYD81_INIT=new WeakMap();
async function cyd81init(env){
 await cyd53init(env);
 if(!CYD81_INIT.has(env.DB))CYD81_INIT.set(env.DB,(async()=>{
  await env.DB.batch([
   env.DB.prepare('CREATE TABLE IF NOT EXISTS carteleria_print_receipts81 (local TEXT NOT NULL,occam_key TEXT NOT NULL,fingerprint TEXT NOT NULL,confirmed_at TEXT NOT NULL,channel TEXT NOT NULL DEFAULT \'pc_confirmada\',PRIMARY KEY(local,occam_key,fingerprint))'),
   env.DB.prepare('CREATE TABLE IF NOT EXISTS carteleria_print_events82 (local TEXT NOT NULL,occam_key TEXT NOT NULL,fingerprint TEXT NOT NULL,ticket TEXT NOT NULL,confirmed_at TEXT NOT NULL,legacy INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(local,occam_key,fingerprint,ticket))'),
   env.DB.prepare('CREATE INDEX IF NOT EXISTS cyd81_receipts_key ON carteleria_print_receipts81(occam_key,fingerprint)'),
   env.DB.prepare('INSERT OR IGNORE INTO carteleria_config(key,value) VALUES (?,?)').bind('cyd81_tracking_since',new Date().toISOString())
  ]);
 })().catch(e=>{CYD81_INIT.delete(env.DB);throw e;}));
 await CYD81_INIT.get(env.DB);
}
function cyd81identity(p){return JSON.stringify([Number(p.qty),Number(p.offer),Number(p.unit)]);}
function cyd81summary(rows){return rows.reduce((a,r)=>({total:a.total+r.total,printed:a.printed+r.printed,pending:a.pending+r.pending,excluded:a.excluded+r.excluded}),{total:0,printed:0,pending:0,excluded:0});}
async function cyd81statements(env,current,local,prints,confirmedAt,ticket){
 if(!prints.length)return [];
 const active=new Map((await cyd68catalog(current,env)).filter(p=>p.occamKey&&!p.promotionBlocked).map(p=>[p.occamKey,p]));
 const records=new Map();
 for(const row of prints){
  if(!row||typeof row.key!=='string'||row.key.length>250||!Number.isFinite(Number(row.qty))||!Number.isFinite(Number(row.offer))||!Number.isFinite(Number(row.unit)))cyd53error('Los datos de los carteles impresos no son válidos.');
  const p=active.get(row.key);
  if(!p||p.printability75?.printable===false)cyd53error('Un cartel fue retirado o no se puede imprimir. Actualiza la cola.',409);
  if(cyd81identity(p)!==JSON.stringify([Number(row.qty),Number(row.offer),Number(row.unit)]))cyd53error('Un precio cambió después de preparar la impresión. Actualiza antes de confirmar.',409);
  records.set(row.key,{key:row.key,fingerprint:cyd81identity(p)});
 }
 const raw=JSON.stringify([...records.values()]);
 // The first post-upgrade event preserves the one known V1.7.7 receipt, if present.
 // A replay of the same confirmation ticket is idempotent.
 const events=env.DB.prepare(`INSERT INTO carteleria_print_events82(local,occam_key,fingerprint,ticket,confirmed_at,legacy)
 SELECT ?,json_extract(j.value,'$.key'),json_extract(j.value,'$.fingerprint'),?,?,
 CASE WHEN EXISTS(SELECT 1 FROM carteleria_print_receipts81 r WHERE r.local=? AND r.occam_key=json_extract(j.value,'$.key') AND r.fingerprint=json_extract(j.value,'$.fingerprint'))
 AND NOT EXISTS(SELECT 1 FROM carteleria_print_events82 e WHERE e.local=? AND e.occam_key=json_extract(j.value,'$.key') AND e.fingerprint=json_extract(j.value,'$.fingerprint')) THEN 1 ELSE 0 END
 FROM json_each(?) j WHERE EXISTS(SELECT 1 FROM carteleria_promos53 WHERE id=1 AND revision=?)
 ON CONFLICT(local,occam_key,fingerprint,ticket) DO NOTHING`).bind(local,ticket,confirmedAt,local,local,raw,current.revision);
 return [events,env.DB.prepare("INSERT INTO carteleria_print_receipts81(local,occam_key,fingerprint,confirmed_at,channel) SELECT ?,json_extract(value,'$.key'),json_extract(value,'$.fingerprint'),?,'pc_confirmada' FROM json_each(?) WHERE EXISTS (SELECT 1 FROM carteleria_promos53 WHERE id=1 AND revision=?) ON CONFLICT(local,occam_key,fingerprint) DO NOTHING").bind(local,confirmedAt,raw,current.revision)];
}
async function cyd82receipts(env,local,started){
 return (await env.DB.prepare(`SELECT r.occam_key,r.fingerprint,r.confirmed_at,COALESCE(SUM(1+e.legacy),1) AS print_count
 FROM carteleria_print_receipts81 r LEFT JOIN carteleria_print_events82 e ON e.local=r.local AND e.occam_key=r.occam_key AND e.fingerprint=r.fingerprint
 WHERE r.local=? AND r.confirmed_at>=? GROUP BY r.occam_key,r.fingerprint,r.confirmed_at`).bind(local,started).all()).results;
}
async function cyd82local(env,principal,url){
 if(principal.profile.role!=='store')cyd53error('Consulta reservada al local autenticado.',403);
 const local=cyd54scope(principal,principal.profile.code);
 if(url.searchParams.has('local')&&url.searchParams.get('local')!==local)cyd53error('Solo puedes consultar tu local.',403);
 await cyd81init(env);
 const started=(await env.DB.prepare("SELECT value FROM carteleria_config WHERE key='cyd81_tracking_since'").first())?.value;
 const receipts=await cyd82receipts(env,local,started);
 return cyd54json({ok:true,local,started,receipts:receipts.map(r=>({key:r.occam_key,fingerprint:r.fingerprint,count:Number(r.print_count)}))});
}
async function cyd81report(env,principal,url){
 if(!['master','market'].includes(principal.profile.role))cyd53error('Informe reservado a Administrador y jefes de mercado.',403);
 await cyd81init(env);
 const started=(await env.DB.prepare("SELECT value FROM carteleria_config WHERE key='cyd81_tracking_since'").first())?.value;
 const current=await cyd53state(env);
 const catalog=(await cyd68catalog(current,env)).filter(p=>p.occamKey&&!p.promotionBlocked);
 const valid=catalog.filter(p=>p.printability75?.printable!==false);
 const refs=valid.map(p=>({key:p.occamKey,fingerprint:cyd81identity(p)}));
 const requested=url.searchParams.get('local')||'';
 const locals=principal.profile.locals;
 if(requested){
  const local=cyd54scope(principal,requested);
  if(!locals.includes(local))cyd53error('Local fuera de tu mercado.',403);
  const found=refs.length?await cyd82receipts(env,local,started):[];
  const receipts=new Map(found.map(r=>[r.occam_key+'|'+r.fingerprint,r]));
  const products=catalog.map(p=>{
   const printable=p.printability75?.printable!==false,fp=cyd81identity(p),confirmed=printable?receipts.get(p.occamKey+'|'+fp):null;
   return {key:p.occamKey,item:p.code||'',upc:p.sourceUPC||p.barcode||'',name:p.name||'',list:p.occamList||'',family:cyd68family(p.occamList),qty:Number(p.qty),price:Number(p.offer),printedAt:confirmed?.confirmed_at||null,printCount:confirmed?Number(confirmed.print_count):0,printable,reasons:printable?[]:p.printability75?.reasons||[]};
  });
  return cyd54json({ok:true,local,market:env.roster.localMarket[local],name:env.roster.stores[local]?.name||'Local '+local,started,revision:current.revision,products});
 }
 // SQL agrupa los recibos corrientes por local; no devuelve cientos de miles de filas al navegador.
 const counts=refs.length?(await env.DB.prepare("SELECT r.local,COUNT(*) AS printed FROM json_each(?) AS j JOIN carteleria_print_receipts81 AS r ON r.occam_key=json_extract(j.value,'$.key') AND r.fingerprint=json_extract(j.value,'$.fingerprint') WHERE r.confirmed_at>=? GROUP BY r.local").bind(JSON.stringify(refs),started).all()).results:[];
 const printed=new Map(counts.map(r=>[String(r.local),Number(r.printed)]));
 const rows=locals.map(local=>{const p=Math.min(valid.length,printed.get(local)||0);return {local,market:env.roster.localMarket[local],name:env.roster.stores[local]?.name||'Local '+local,total:valid.length,printed:p,pending:valid.length-p,excluded:catalog.length-valid.length};});
 const byMarket=new Map();for(const row of rows){if(!byMarket.has(row.market))byMarket.set(row.market,[]);byMarket.get(row.market).push(row);}
 const markets=[...byMarket].map(([code,items])=>({market:code,name:env.roster.marketNames[code]||code,localCount:items.length,...cyd81summary(items)})).sort((a,b)=>Number(a.market)-Number(b.market));
 return cyd54json({ok:true,started,revision:current.revision,asOf:new Date().toISOString(),scope:principal.profile.role,markets,rows});
}
async function cyd81route(req,env,principal,url){
 if(url.pathname==='/api/carteleria/impresion/local'){if(req.method!=='GET')return cyd54json({ok:false,error:'Solo consulta.'},405);return cyd82local(env,principal,url);}
 if(url.pathname!=='/api/carteleria/impresion')return null;
 if(req.method!=='GET')return cyd54json({ok:false,error:'Solo consulta.'},405);
 return cyd81report(env,principal,url);
}
