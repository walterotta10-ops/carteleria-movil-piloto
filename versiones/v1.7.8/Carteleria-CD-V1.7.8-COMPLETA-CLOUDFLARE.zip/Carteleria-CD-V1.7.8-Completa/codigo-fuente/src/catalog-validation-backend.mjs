// Precio confirmado por el usuario: Coca-Cola 3 L retornable, normal y actual $2.090.
// Se aplica una sola vez al registro exacto que conservaba $2.050 de referencia.
const CYD75_PRICE_FIX=new WeakMap(),CYD75_SPECIFICATIONS=new WeakMap();
async function cyd75priceReference(env){
 if(!CYD75_PRICE_FIX.has(env.DB))CYD75_PRICE_FIX.set(env.DB,(async()=>{
  const key='coca_reference75_2090';if(await env.DB.prepare('SELECT value FROM carteleria_config WHERE key=?').bind(key).first())return;
  for(let attempt=0;attempt<3;attempt++){
   const row=await env.DB.prepare('SELECT revision,data,updated_at,last_import FROM carteleria_promos53 WHERE id=1').first(),state=JSON.parse(row.data),base=state.base.find(r=>CYD53_E.key(r)==='LISTA4|432282'&&String(r.upc)==='780161033312');
   const effective=base?cyd53catalog(state).find(p=>p.occamKey==='LISTA4|432282'):null;
   const eligible=base?.before===2050&&effective?.qty===1&&effective?.offer===2090,now=new Date().toISOString();
   if(!eligible){await env.DB.prepare('INSERT OR IGNORE INTO carteleria_config (key,value) VALUES (?,?)').bind(key,JSON.stringify({applied:false,checkedAt:now,reason:'Los datos vigentes ya no coinciden con el caso confirmado.'})).run();return;}
   const current={...row,state},history=await cyd62history(current,env),prior=cyd62prices(state,cyd53day());base.before=2090;
   state.priceChanges=cyd62changes(cyd62prices(state,cyd53day()),prior,history);
   state.referenceChecks75={...(state.referenceChecks75||{}),coca2090:{key:'LISTA4|432282',normal:2090,confirmedAt:now,source:'Confirmado por el usuario'}};
   await env.DB.batch([
    env.DB.prepare('INSERT OR IGNORE INTO carteleria_promo_versions53 (revision,data,saved_at) SELECT revision,data,updated_at FROM carteleria_promos53 WHERE id=1'),
    env.DB.prepare('UPDATE carteleria_promos53 SET data=?,revision=revision+1,updated_at=? WHERE id=1 AND revision=?').bind(JSON.stringify(state),now,row.revision),
    env.DB.prepare("INSERT OR IGNORE INTO carteleria_config (key,value) SELECT ?,? WHERE EXISTS (SELECT 1 FROM carteleria_promos53 WHERE id=1 AND revision=? AND json_extract(data,'$.referenceChecks75.coca2090.normal')=2090)").bind(key,JSON.stringify({applied:true,checkedAt:now,from:2050,to:2090,source:'Confirmado por el usuario'}),row.revision+1)
   ]);
   if(await env.DB.prepare('SELECT value FROM carteleria_config WHERE key=?').bind(key).first())return;
  }
  cyd53error('El catálogo cambió durante la verificación del precio. Actualiza y vuelve a intentarlo.',409);
 })().catch(error=>{CYD75_PRICE_FIX.delete(env.DB);throw error;}));
 await CYD75_PRICE_FIX.get(env.DB);
}
async function cyd75specifications(env,current){
 if(!env.cyd80SpecificationData)env.cyd80SpecificationData=cyd80specifications(env);
 const data=await env.cyd80SpecificationData;current.specificationRevision75=data.revision;
 CYD75_SPECIFICATIONS.set(current.state,{lookup:data.lookup,checkedAt:data.checkedAt});
}

function cyd75catalog(catalog,state,day=cyd53day()){
 const specs=CYD75_SPECIFICATIONS.get(state);
 const weekly=new Map((state.weekly||[]).map(row=>[row.pn,row])),base=new Map((state.base||[]).map(row=>[CYD53_E.key(row),row]));
 return catalog.map(product=>{
  const checked=CYD75_SPEC.repair(product,specs?.lookup,specs?.checkedAt||null),w=weekly.get(String(product.sourceProductNbr)),b=base.get(product.occamKey);
  const latest=w&&b&&(!w.from||w.from<=day)&&(!w.to||w.to>=day)&&(w.loadedRevision75?(!b.loadedRevision75||w.loadedRevision75>=b.loadedRevision75):!b.loadedRevision75&&w.from&&w.from>=(b.from||''));
  if(!latest||CYD53_E.ean(w.upc,true)!==product.barcode)return checked;
  const row={item:product.code||w.item||'',upc:product.barcode,descripcion:w.name,marca:w.brand,unidad:w.size,updated_at:w.loadedAt75||w.from},repaired=CYD75_SPEC.repair(checked,{find:()=>[row]},specs?.checkedAt||null);
  if(repaired.specificationCheck75.recovered.length)repaired.specificationCheck75={...repaired.specificationCheck75,source:'Reporte de jueves vigente: '+(state.source?.weekly||'Reporte semanal'),recovered:[...new Set([...checked.specificationCheck75.recovered,...repaired.specificationCheck75.recovered])]};
  else repaired.specificationCheck75=checked.specificationCheck75;
  return repaired;
 });
}
