
// V1.5: verdes dentro del calendario. Solo el lunes y martes iniciales quedan libres.
const CYD71_REQUESTED_START='2026-11-11',CYD71_INIT=new WeakMap();
async function cyd71init(env){
  await cyd70init(env);
  if(!CYD71_INIT.has(env.DB))CYD71_INIT.set(env.DB,env.DB.batch([
    env.DB.prepare('CREATE TABLE IF NOT EXISTS carteleria_cycle_reviews71 (local TEXT NOT NULL,cycle_start TEXT NOT NULL,category_key TEXT NOT NULL,scheduled_day TEXT NOT NULL,reviewed_at TEXT NOT NULL,catalog_revision INTEGER NOT NULL,reviewed_lists TEXT NOT NULL,PRIMARY KEY(local,cycle_start,category_key))'),
    env.DB.prepare('CREATE TABLE IF NOT EXISTS carteleria_cycle_prints71 (local TEXT NOT NULL,cycle_start TEXT NOT NULL,category_key TEXT NOT NULL,product_key TEXT NOT NULL,fingerprint TEXT NOT NULL,scheduled_day TEXT NOT NULL,printed_at TEXT NOT NULL,PRIMARY KEY(local,cycle_start,category_key,product_key,fingerprint))'),
    env.DB.prepare('CREATE TABLE IF NOT EXISTS carteleria_cycle_archive71 (local TEXT NOT NULL,cycle_start TEXT NOT NULL,saved_at TEXT NOT NULL,original TEXT NOT NULL,PRIMARY KEY(local,cycle_start))'),
    env.DB.prepare('CREATE TABLE IF NOT EXISTS carteleria_cycle_archive72 (local TEXT NOT NULL,cycle_start TEXT NOT NULL,saved_at TEXT NOT NULL,original TEXT NOT NULL,PRIMARY KEY(local,cycle_start))')
  ]).catch(error=>{CYD71_INIT.delete(env.DB);throw error;}));
  await CYD71_INIT.get(env.DB);
}
function cyd71assign(categories,start,first,existing=[],excluded=[]){
  const days=Array.from({length:21},(_,i)=>cyd69add(start,i)).filter(day=>day>=first&&!excluded.includes(day)),loads=new Map(days.map(day=>[day,{count:0,products:0,departments:new Map()}]));
  for(const c of existing){const load=loads.get(c.day);if(load&&c.active!==false){load.count++;load.products+=c.total;load.departments.set(c.department,(load.departments.get(c.department)||0)+1);}}
  return [...categories].sort((a,b)=>(a.validUntil||'9999').localeCompare(b.validUntil||'9999')||b.total-a.total||a.key.localeCompare(b.key)).map(c=>{
    const available=days.filter(day=>!c.validUntil||day<=c.validUntil);
    if(!available.length)return {...c,day:days[0]||cyd69add(start,2),active:false,total:0,counts:{red:0,yellow:0,other:0}};
    const day=available.sort((a,b)=>{const x=loads.get(a),y=loads.get(b);return x.count-y.count||x.products-y.products||(x.departments.get(c.department)||0)-(y.departments.get(c.department)||0)||a.localeCompare(b);})[0],load=loads.get(day);
    load.count++;load.products+=c.total;load.departments.set(c.department,(load.departments.get(c.department)||0)+1);return {...c,day};
  });
}
async function cyd71buildData(env,local,start,end,seeds,first,priorData=null){
  const metadata=new Map(seeds.map(c=>[c.key,c])),old=(await env.DB.prepare('SELECT * FROM carteleria_weekly_reviews69 WHERE local=? AND week_start>=? AND week_start<=?').bind(local,start,cyd69add(start,14)).all()).results,green=new Map();
  for(const check of old){
    const category=metadata.get(check.category_key);
    if(category&&category.active!==false&&category.day===check.scheduled_day&&H(new Date(check.reviewed_at))===check.scheduled_day)green.set(check.category_key,{reviewedAt:check.reviewed_at,scheduledDay:check.scheduled_day,revision:check.catalog_revision,sourceWeek:check.week_start});
  }
  for(const category of priorData?.categories||[])if(category.carried&&category.carriedReview&&metadata.get(category.key)?.active!==false)green.set(category.key,category.carriedReview);
  const saved=(await env.DB.prepare('SELECT * FROM carteleria_cycle_reviews71 WHERE local=? AND cycle_start=?').bind(local,start).all()).results,locked=[];
  for(const review of saved){const category=metadata.get(review.category_key);if(category){locked.push({...cyd69metadata(category),day:review.scheduled_day});green.delete(category.key);}}
  const preservedDays=green.size?[cyd69add(start,2),cyd69add(start,3)]:[],loads=preservedDays.map(day=>({day,count:0,products:0})),completed=[];
  for(const [key,review] of [...green].sort((a,b)=>a[1].reviewedAt.localeCompare(b[1].reviewedAt)||a[0].localeCompare(b[0]))){
    const category=cyd69metadata(metadata.get(key)),load=loads.sort((a,b)=>a.count-b.count||a.products-b.products||a.day.localeCompare(b.day))[0];
    completed.push({...category,day:load.day,preservedReview:review});load.count++;load.products+=category.total;
  }
  const fixed=new Set([...completed,...locked].map(c=>c.key)),pending=[...metadata.values()].filter(c=>!fixed.has(c.key)).map(cyd69metadata);
  return {policy71:true,policy72:true,scheduleStart:first,preservedDays,categories:[...completed,...locked,...cyd71assign(pending,start,first,locked,preservedDays)]};
}
async function cyd71migrate(env,row,current,groups,today){
  for(let attempt=0;attempt<3;attempt++){
    const old=JSON.parse(row.data);if(old.policy72)return row;
    const metadata=new Map(old.categories.map(c=>[c.key,c]));
    for(const group of groups.values()){const previous=metadata.get(group.key);metadata.set(group.key,{...previous,...cyd69metadata(group)});}
    const first=[row.cycle_start,row.cycle_number===1?CYD71_REQUESTED_START:row.cycle_start,today].sort().at(-1),updated=await cyd71buildData(env,row.local,row.cycle_start,row.last_day,[...metadata.values()],first,old);
    await env.DB.batch([
      env.DB.prepare('INSERT OR IGNORE INTO carteleria_cycle_archive72 (local,cycle_start,saved_at,original) SELECT ?,?,?,? WHERE EXISTS (SELECT 1 FROM carteleria_review_cycles70 WHERE local=? AND cycle_start=? AND version=?)').bind(row.local,row.cycle_start,new Date().toISOString(),JSON.stringify(row),row.local,row.cycle_start,row.version),
      env.DB.prepare('UPDATE carteleria_review_cycles70 SET data=?,first_day=?,catalog_revision=?,version=version+1 WHERE local=? AND cycle_start=? AND version=?').bind(JSON.stringify(updated),first,current.revision,row.local,row.cycle_start,row.version)
    ]);
    row=await env.DB.prepare('SELECT * FROM carteleria_review_cycles70 WHERE local=? AND cycle_start=?').bind(row.local,row.cycle_start).first();if(JSON.parse(row.data).policy72)return row;
  }
  cyd53error('Otro equipo está ajustando el reparto. Actualiza la revisión.',409);
}
async function cyd71sync(env,row,current,groups,today){
  for(let attempt=0;attempt<3;attempt++){
    const data=JSON.parse(row.data),keys=new Set(data.categories.map(c=>c.key)),existing=data.categories.map(c=>({...c,...(groups.has(c.key)?cyd69metadata(groups.get(c.key)):{active:false,total:0,counts:{red:0,yellow:0,other:0}})})),fresh=[...groups.values()].filter(c=>!keys.has(c.key)).map(cyd69metadata),first=[today,row.first_day].sort().at(-1),updated={...data,categories:[...existing,...cyd71assign(fresh,row.cycle_start,first,existing,data.preservedDays||[])]};
    if(JSON.stringify(data)===JSON.stringify(updated))return row;
    const changed=await env.DB.prepare('UPDATE carteleria_review_cycles70 SET data=?,catalog_revision=?,version=version+1 WHERE local=? AND cycle_start=? AND version=?').bind(JSON.stringify(updated),current.revision,row.local,row.cycle_start,row.version).run();
    row=await env.DB.prepare('SELECT * FROM carteleria_review_cycles70 WHERE local=? AND cycle_start=?').bind(row.local,row.cycle_start).first();if(Number(changed.meta?.changes)===1)return row;
  }
  return row;
}
async function cyd71records(env,local,start){
  const key=local+'|'+start;if(env.cyd74Records?.has(key))return env.cyd74Records.get(key);
  const [reviews,prints]=await env.DB.batch([
    env.DB.prepare('SELECT * FROM carteleria_cycle_reviews71 WHERE local=? AND cycle_start=?').bind(local,start),
    env.DB.prepare('SELECT * FROM carteleria_cycle_prints71 WHERE local=? AND cycle_start=?').bind(local,start)
  ]);
  const records={reviews:new Map(reviews.results.map(r=>[r.category_key,r])),prints:prints.results};if(!env.cyd74Records)env.cyd74Records=new Map();env.cyd74Records.set(key,records);return records;
}
function cyd71decorate(categories,records,groups,today){
  return categories.map(c=>{
    const saved=records.reviews.get(c.key),review=c.preservedReview?{...c.preservedReview,day:H(new Date(c.preservedReview.reviewedAt)),preserved:true}:saved?{reviewedAt:saved.reviewed_at,day:H(new Date(saved.reviewed_at)),revision:saved.catalog_revision}:null,prints=records.prints.filter(p=>p.category_key===c.key).map(p=>({key:p.product_key,token:p.fingerprint,printedAt:p.printed_at,late:H(new Date(p.printed_at))>p.scheduled_day})),live=groups?.get(c.key),latePrints=new Set(prints.filter(p=>p.late).map(p=>p.key)).size;
    return {...c,status:c.active===false?'inactive':review?(review.preserved||review.day===c.day?'on':'late'):c.day<today?'missed':c.day===today?'today':'planned',review,prints,latePrints,printed:new Set(prints.map(p=>p.key)).size,items:live?.items||[],signature:live?.signature||null};
  });
}
async function cyd71view(env,local,plan,groups,current,today,activation){
  const start=plan.data.cycle70.start,records=await cyd71records(env,local,start),categories=cyd71decorate(plan.data.categories,records,groups,today).sort((a,b)=>a.day.localeCompare(b.day)||a.department.localeCompare(b.department,'es')||a.categoryName.localeCompare(b.categoryName,'es'));
  return {local,week:plan.week_start,startDay:plan.start_day,today,activation,revision:current.revision,planVersion:plan.version,categories,stats:cyd69stats(categories,today)};
}
async function cyd71cycleView(env,local,plan,row,today){
  const updated=JSON.parse(row.data);if(updated.policy72){
    const records=await cyd71records(env,local,row.cycle_start),categories=cyd71decorate(updated.categories,records,null,today);
    return {number:row.cycle_number,start:row.cycle_start,end:row.last_day,firstDay:row.first_day,weekNumber:Math.floor((new Date(plan.week_start+'T12:00:00Z').getTime()-new Date(row.cycle_start+'T12:00:00Z').getTime())/(7*86400000))+1,maxWeek:cyd69add(row.cycle_start,14),stats:cyd69stats(categories,today),policy71:true,policy72:true,carriedCount:0,carried:[],preservedCount:categories.filter(c=>c.preservedReview).length,weekdays:'Lunes a domingo',weeks:Array.from({length:3},(_,i)=>{const week=cyd69add(row.cycle_start,i*7),subset=categories.filter(c=>c.day>=week&&c.day<=cyd69add(week,6));return {week,number:i+1,products:subset.reduce((n,c)=>n+c.total,0),...cyd69stats(subset,today)};})};
  }
  const data=JSON.parse(row.data),records=await cyd71records(env,local,row.cycle_start),scheduled=cyd71decorate(data.categories.filter(c=>!c.carried),records,null,today),carried=data.categories.filter(c=>c.carried).map(c=>({...c,status:'on',review:c.carriedReview})),stats=cyd69stats(scheduled,today);
  stats.total+=carried.length;stats.reviewed+=carried.length;stats.due+=carried.length;stats.onTime+=carried.length;stats.adherence=stats.due?Math.round(stats.onTime/stats.due*100):null;
  return {number:row.cycle_number,start:row.cycle_start,end:row.last_day,firstDay:row.first_day,weekNumber:Math.floor((new Date(plan.week_start+'T12:00:00Z').getTime()-new Date(row.cycle_start+'T12:00:00Z').getTime())/(7*86400000))+1,maxWeek:cyd69add(row.cycle_start,14),stats,policy71:true,carriedCount:carried.length,carried,weekdays:'Miércoles a domingo',weeks:Array.from({length:3},(_,i)=>{const week=cyd69add(row.cycle_start,i*7),subset=scheduled.filter(c=>c.day>=week&&c.day<=cyd69add(week,6));return {week,number:i+1,products:subset.reduce((n,c)=>n+c.total,0),...cyd69stats(subset,today)};})};
}
async function cyd71review(req,env,principal,body,local,today,week,plan,category){
  if(category.preservedReview)return cyd54json({ok:true,alreadyReviewed:true,reviewedAt:category.preservedReview.reviewedAt});
  await cyd71init(env);const start=plan.cycle70.start,prior=await env.DB.prepare('SELECT reviewed_at FROM carteleria_cycle_reviews71 WHERE local=? AND cycle_start=? AND category_key=?').bind(local,start,body.key).first();
  if(prior)return cyd54json({ok:true,alreadyReviewed:true,reviewedAt:prior.reviewed_at});
  const {current,groups}=await cyd79weekly(env),group=groups.get(body.key);
  if(!group||body.signature!==group.signature)cyd53error('La categoría cambió. Actualiza y vuelve a revisar sus listas.',409);
  const lists=['red','yellow',...(group.counts.other?['other']:[])];if(body.confirmed!==true||!Array.isArray(body.lists)||lists.some(type=>!body.lists.includes(type)))cyd53error('Confirma la revisión de EDLP y Campaña antes de cerrar la categoría.');
  const now=new Date().toISOString(),result=await env.DB.prepare("INSERT OR IGNORE INTO carteleria_cycle_reviews71 (local,cycle_start,category_key,scheduled_day,reviewed_at,catalog_revision,reviewed_lists) SELECT ?,?,?,?,?,?,? WHERE EXISTS (SELECT 1 FROM carteleria_promos53 WHERE id=1 AND revision=?) AND EXISTS (SELECT 1 FROM carteleria_weekly_plans69 p,json_each(p.data,'$.categories') c WHERE p.local=? AND p.week_start=? AND json_extract(c.value,'$.key')=? AND json_extract(c.value,'$.day')=?)").bind(local,start,body.key,category.day,now,current.revision,JSON.stringify(lists),current.revision,local,week,body.key,category.day).run();
  if(!Number(result.meta?.changes)){const saved=await env.DB.prepare('SELECT reviewed_at FROM carteleria_cycle_reviews71 WHERE local=? AND cycle_start=? AND category_key=?').bind(local,start,body.key).first();if(saved)return cyd54json({ok:true,alreadyReviewed:true,reviewedAt:saved.reviewed_at});cyd53error('El reparto o las promociones cambiaron. Actualiza antes de confirmar.',409);}
  return cyd54json({ok:true,reviewedAt:now,late:today>category.day});
}
