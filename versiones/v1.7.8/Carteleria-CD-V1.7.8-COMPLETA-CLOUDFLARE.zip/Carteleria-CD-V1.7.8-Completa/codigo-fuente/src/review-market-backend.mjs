// V1.6. Reinicio del mercado 814 el lunes 16/11/2026. Una migración, sin arrastrar checks.
const CYD74_START='2026-11-16',CYD74_RESET='814:2026-11-16',CYD74_INIT=new WeakMap();
const cyd74index=today=>Math.max(0,Math.floor((Date.parse(cyd69monday(today)+'T12:00:00Z')-Date.parse(CYD74_START+'T12:00:00Z'))/(21*86400000)));
async function cyd74init(env){
  await cyd71init(env);
  if(!CYD74_INIT.has(env.DB))CYD74_INIT.set(env.DB,env.DB.batch([
    env.DB.prepare('CREATE TABLE IF NOT EXISTS carteleria_review_resets74 (id TEXT PRIMARY KEY,start_day TEXT NOT NULL,applied_at TEXT NOT NULL,generation TEXT NOT NULL,details TEXT NOT NULL)'),
    env.DB.prepare('CREATE TABLE IF NOT EXISTS carteleria_weekly_archive74 (local TEXT NOT NULL,week_start TEXT NOT NULL,reset_id TEXT NOT NULL,saved_at TEXT NOT NULL,original TEXT NOT NULL,PRIMARY KEY(local,week_start,reset_id))'),
    env.DB.prepare('CREATE TABLE IF NOT EXISTS carteleria_cycle_archive74 (local TEXT NOT NULL,cycle_start TEXT NOT NULL,reset_id TEXT NOT NULL,saved_at TEXT NOT NULL,original TEXT NOT NULL,PRIMARY KEY(local,cycle_start,reset_id))'),
    env.DB.prepare('CREATE TABLE IF NOT EXISTS carteleria_cycle_records74 (local TEXT NOT NULL,cycle_start TEXT NOT NULL,reset_id TEXT NOT NULL,kind TEXT NOT NULL,saved_at TEXT NOT NULL,data TEXT NOT NULL,PRIMARY KEY(local,cycle_start,reset_id,kind))')
  ]).catch(error=>{CYD74_INIT.delete(env.DB);throw error;}));
  await CYD74_INIT.get(env.DB);
}
async function cyd74reset(env,locals){
  if(await env.DB.prepare('SELECT id FROM carteleria_review_resets74 WHERE id=?').bind(CYD74_RESET).first())return;
  const [plans,cycles]=await env.DB.batch([
    env.DB.prepare("SELECT * FROM carteleria_weekly_plans69 WHERE local IN (SELECT value FROM json_each(?)) AND week_start>=? AND COALESCE(json_extract(data,'$.cycle70.policy74'),0)=0").bind(JSON.stringify(locals),CYD74_START),
    env.DB.prepare("SELECT * FROM carteleria_review_cycles70 WHERE local IN (SELECT value FROM json_each(?)) AND last_day>=? AND COALESCE(json_extract(data,'$.policy74'),0)=0").bind(JSON.stringify(locals),CYD74_START)
  ]);
  const collisions=cycles.results.filter(row=>row.cycle_start>=CYD74_START);
  const snapshots=collisions.length?await env.DB.batch([
    env.DB.prepare('SELECT * FROM carteleria_cycle_reviews71 WHERE local IN (SELECT value FROM json_each(?)) AND cycle_start>=?').bind(JSON.stringify(locals),CYD74_START),
    env.DB.prepare('SELECT * FROM carteleria_cycle_prints71 WHERE local IN (SELECT value FROM json_each(?)) AND cycle_start>=?').bind(JSON.stringify(locals),CYD74_START)
  ]):[];
  const generation=crypto.randomUUID(),now=new Date().toISOString(),statements=[
    env.DB.prepare('INSERT OR IGNORE INTO carteleria_review_resets74 (id,start_day,applied_at,generation,details) VALUES (?,?,?,?,?)').bind(CYD74_RESET,CYD74_START,now,generation,JSON.stringify({market:'814',locals,cycleWeeks:3})),
    env.DB.prepare("INSERT OR IGNORE INTO carteleria_config (key,value) SELECT 'weekly69_start',? WHERE EXISTS (SELECT 1 FROM carteleria_review_resets74 WHERE id=? AND generation=?)").bind(CYD74_START,CYD74_RESET,generation),
    env.DB.prepare("INSERT OR IGNORE INTO carteleria_config (key,value) SELECT 'review74_start_814',? WHERE EXISTS (SELECT 1 FROM carteleria_review_resets74 WHERE id=? AND generation=?)").bind(CYD74_START,CYD74_RESET,generation)
  ];
  for(const row of plans.results)statements.push(env.DB.prepare('INSERT OR IGNORE INTO carteleria_weekly_archive74 (local,week_start,reset_id,saved_at,original) SELECT ?,?,?,?,? WHERE EXISTS (SELECT 1 FROM carteleria_review_resets74 WHERE id=? AND generation=?)').bind(row.local,row.week_start,CYD74_RESET,now,JSON.stringify(row),CYD74_RESET,generation));
  for(const row of cycles.results){
    const data=JSON.parse(row.data),updated={...data,restartedAt:CYD74_START,categories:data.categories.filter(c=>c.day<CYD74_START)};
    statements.push(env.DB.prepare('INSERT OR IGNORE INTO carteleria_cycle_archive74 (local,cycle_start,reset_id,saved_at,original) SELECT ?,?,?,?,? WHERE EXISTS (SELECT 1 FROM carteleria_review_resets74 WHERE id=? AND generation=?)').bind(row.local,row.cycle_start,CYD74_RESET,now,JSON.stringify(row),CYD74_RESET,generation));
    if(row.cycle_start<CYD74_START)statements.push(env.DB.prepare('UPDATE carteleria_review_cycles70 SET last_day=?,data=?,version=version+1 WHERE local=? AND cycle_start=? AND version=? AND EXISTS (SELECT 1 FROM carteleria_review_resets74 WHERE id=? AND generation=?)').bind(cyd69add(CYD74_START,-1),JSON.stringify(updated),row.local,row.cycle_start,row.version,CYD74_RESET,generation));
    else{
      for(const [i,kind,table] of [[0,'reviews','carteleria_cycle_reviews71'],[1,'prints','carteleria_cycle_prints71']]){
        const records=snapshots[i].results.filter(r=>r.local===row.local&&r.cycle_start===row.cycle_start);
        statements.push(env.DB.prepare('INSERT OR IGNORE INTO carteleria_cycle_records74 (local,cycle_start,reset_id,kind,saved_at,data) SELECT ?,?,?,?,?,? WHERE EXISTS (SELECT 1 FROM carteleria_review_resets74 WHERE id=? AND generation=?)').bind(row.local,row.cycle_start,CYD74_RESET,kind,now,JSON.stringify(records),CYD74_RESET,generation));
        statements.push(env.DB.prepare('DELETE FROM '+table+' WHERE local=? AND cycle_start=? AND EXISTS (SELECT 1 FROM carteleria_review_resets74 WHERE id=? AND generation=?)').bind(row.local,row.cycle_start,CYD74_RESET,generation));
      }
      statements.push(env.DB.prepare('DELETE FROM carteleria_review_cycles70 WHERE local=? AND cycle_start=? AND version=? AND EXISTS (SELECT 1 FROM carteleria_review_resets74 WHERE id=? AND generation=?)').bind(row.local,row.cycle_start,row.version,CYD74_RESET,generation));
    }
  }
  await env.DB.batch(statements);
}
function cyd74data(seeds,start){
  return {policy71:true,policy72:true,policy74:true,market:'814',scheduleStart:start,preservedDays:[],categories:cyd71assign(seeds,start,start)};
}
const CYD79_PLAN_PREPARE=new WeakMap();
async function cyd74ensurePlans(env,current,groups,today){
  await cyd74init(env);const all=cyd69locals(env);await cyd74reset(env,all);
  const stamp=JSON.stringify([current.revision,current.specificationRevision75||0,today,cyd74index(today),all]),key='review79_prepared_814';
  // El reparto común se actualiza una sola vez; conserva el mismo día para los 12 locales.
  // Las entradas normales solo consultan y comprueban las semanas del local autorizado.
  for(let attempt=0;attempt<4;attempt++){
    const marker=await env.DB.prepare('SELECT value FROM carteleria_config WHERE key=?').bind(key).first();
    if(marker?.value===stamp)break;
    const running=CYD79_PLAN_PREPARE.get(env.DB);if(running){await running;continue;}
    const job=(async()=>{
      const latest=await env.DB.prepare('SELECT revision FROM carteleria_promos53 WHERE id=1').first();
      if(latest.revision!==current.revision)cyd53error('Las promociones cambiaron mientras se abría la revisión. Vuelve a actualizar.',409);
      await cyd79ensureScope(env,current,groups,today,all);
      await env.DB.prepare("INSERT INTO carteleria_config (key,value) SELECT ?,? WHERE EXISTS (SELECT 1 FROM carteleria_promos53 WHERE id=1 AND revision=?) ON CONFLICT(key) DO UPDATE SET value=excluded.value").bind(key,stamp,current.revision).run();
    })();
    CYD79_PLAN_PREPARE.set(env.DB,job);
    try{await job;}finally{if(CYD79_PLAN_PREPARE.get(env.DB)===job)CYD79_PLAN_PREPARE.delete(env.DB);}
    break;
  }
  return cyd79ensureScope(env,current,groups,today,cyd79planLocals(env));
}
async function cyd79ensureScope(env,current,groups,today,locals){
  const index=cyd74index(today),target=cyd69add(CYD74_START,index*21),localJson=JSON.stringify(locals);
  const read=async()=>((await env.DB.prepare('SELECT * FROM carteleria_review_cycles70 WHERE local IN (SELECT value FROM json_each(?)) AND cycle_start>=? AND cycle_start<=?').bind(localJson,CYD74_START,target).all()).results).filter(r=>JSON.parse(r.data).policy74);
  let rows=await read(),known=new Map(rows.map(r=>[r.local+'|'+r.cycle_start,r])),missing=[],created=new Set();
  const seeds=[...groups.values()].map(cyd69metadata);
  for(const local of locals)for(let i=0;i<=index;i++){
    const start=cyd69add(CYD74_START,i*21),key=local+'|'+start;if(known.has(key))continue;
    const end=cyd69add(start,20),previous=known.get(local+'|'+cyd69add(start,-21));
    const snapshot=end<today&&previous?JSON.parse(previous.data).categories.filter(c=>c.active!==false&&(!c.validUntil||c.validUntil>=start)).map(cyd69metadata):seeds;
    const row={local,cycle_start:start,cycle_number:i+1,first_day:start,last_day:end,catalog_revision:current.revision,version:1,generation:crypto.randomUUID(),data:JSON.stringify(cyd74data(snapshot,start))};
    known.set(key,row);missing.push(row);created.add(key);
  }
  if(missing.length){await env.DB.batch(missing.map(r=>env.DB.prepare('INSERT OR IGNORE INTO carteleria_review_cycles70 (local,cycle_start,cycle_number,first_day,last_day,catalog_revision,version,generation,data) VALUES (?,?,?,?,?,?,?,?,?)').bind(r.local,r.cycle_start,r.cycle_number,r.first_day,r.last_day,r.catalog_revision,1,r.generation,r.data)));rows=await read();}
  // Sincronizar catálogos en conjunto. El día asignado de una categoría existente se conserva.
  for(let attempt=0;attempt<3;attempt++){
    const updates=[];
    for(const row of rows.filter(r=>r.cycle_start===target)){
      const data=JSON.parse(row.data),keys=new Set(data.categories.map(c=>c.key));
      const existing=data.categories.map(c=>({...c,...(groups.has(c.key)?cyd69metadata(groups.get(c.key)):{active:false,total:0,counts:{red:0,yellow:0,other:0}})}));
      const fresh=[...groups.values()].filter(c=>!keys.has(c.key)).map(cyd69metadata),first=today<row.first_day?row.first_day:today;
      const updated={...data,categories:[...existing,...cyd71assign(fresh,row.cycle_start,first,existing)]};
      if(JSON.stringify(data)!==JSON.stringify(updated))updates.push(env.DB.prepare('UPDATE carteleria_review_cycles70 SET data=?,catalog_revision=?,version=version+1 WHERE local=? AND cycle_start=? AND version=?').bind(JSON.stringify(updated),current.revision,row.local,row.cycle_start,row.version));
    }
    if(!updates.length)break;
    await env.DB.batch(updates);rows=await read();
  }
  // Publicar solo las semanas que faltan o cuya versión de ciclo cambió.
  const plans=(await env.DB.prepare("SELECT local,week_start,json_extract(data,'$.cycle70.start') AS cycle_start,json_extract(data,'$.cycle70.version') AS cycle_version FROM carteleria_weekly_plans69 WHERE local IN (SELECT value FROM json_each(?)) AND week_start>=? AND week_start<=?").bind(localJson,CYD74_START,cyd69add(target,14)).all()).results;
  const published=new Map(plans.map(p=>[p.local+'|'+p.week_start,p]));
  const publish=rows.filter(r=>(r.cycle_start===target||created.has(r.local+'|'+r.cycle_start))&&Array.from({length:3},(_,i)=>cyd69add(r.cycle_start,i*7)).some(week=>{const p=published.get(r.local+'|'+week);return !p||p.cycle_start!==r.cycle_start||p.cycle_version!==r.version;}));
  if(publish.length)await env.DB.batch(publish.map(row=>cyd70publishStatement(env,row)));
  env.cyd74Cycles=new Map(rows.map(row=>[row.local+'|'+row.cycle_start,row]));
  return CYD74_START;
}
async function cyd74activation(env,local=null){
  const row=local?await env.DB.prepare('SELECT MIN(week_start) AS day FROM carteleria_weekly_plans69 WHERE local=?').bind(local).first():await env.DB.prepare('SELECT MIN(week_start) AS day FROM carteleria_weekly_plans69 WHERE local IN (SELECT value FROM json_each(?))').bind(JSON.stringify(cyd69locals(env))).first();
  return row?.day||CYD74_START;
}
async function cyd74primeViews(env,locals,week){
  const json=JSON.stringify(locals),plans=(await env.DB.prepare('SELECT * FROM carteleria_weekly_plans69 WHERE local IN (SELECT value FROM json_each(?)) AND week_start=?').bind(json,week).all()).results;
  env.cyd74Plans=new Map(locals.map(local=>[local+'|'+week,null]));
  for(const row of plans)env.cyd74Plans.set(row.local+'|'+week,{...row,data:JSON.parse(row.data)});
  const starts=[...new Set(plans.map(p=>JSON.parse(p.data).cycle70?.start).filter(Boolean))];
  if(!starts.length)return;
  const cycles=(await env.DB.prepare('SELECT * FROM carteleria_review_cycles70 WHERE local IN (SELECT value FROM json_each(?)) AND cycle_start IN (SELECT value FROM json_each(?))').bind(json,JSON.stringify(starts)).all()).results;
  if(!env.cyd74Cycles)env.cyd74Cycles=new Map();for(const row of cycles)env.cyd74Cycles.set(row.local+'|'+row.cycle_start,row);
  const [reviews,prints]=await env.DB.batch([
    env.DB.prepare('SELECT * FROM carteleria_cycle_reviews71 WHERE local IN (SELECT value FROM json_each(?)) AND cycle_start IN (SELECT value FROM json_each(?))').bind(json,JSON.stringify(starts)),
    env.DB.prepare('SELECT * FROM carteleria_cycle_prints71 WHERE local IN (SELECT value FROM json_each(?)) AND cycle_start IN (SELECT value FROM json_each(?))').bind(json,JSON.stringify(starts))
  ]);
  env.cyd74Records=new Map();
  for(const local of locals)for(const start of starts)env.cyd74Records.set(local+'|'+start,{reviews:new Map(reviews.results.filter(r=>r.local===local&&r.cycle_start===start).map(r=>[r.category_key,r])),prints:prints.results.filter(r=>r.local===local&&r.cycle_start===start)});
}
