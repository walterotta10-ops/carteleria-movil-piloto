
// V1.5. Una vuelta completa de categorías cada tres semanas; historial por local.
const CYD70_INIT=new WeakMap();
function cyd70date(value){const date=new Date(value);return Number.isFinite(date.getTime())?H(date):null;}
function cyd70active(product,today=cyd53day()){
  const from=product.campaignFromDate?cyd70date(product.campaignFromDate):null,to=product.campaignToDate?cyd70date(product.campaignToDate):null;
  return (!from||from<=today)&&(!to||to>=today);
}
function cyd70validUntil(products){const dates=products.map(p=>p.campaignToDate?cyd70date(p.campaignToDate):null);return dates.some(d=>!d)?null:dates.sort().at(-1)||null;}
async function cyd70init(env){
  await cyd69init(env);
  if(!CYD70_INIT.has(env.DB))CYD70_INIT.set(env.DB,env.DB.batch([
    env.DB.prepare('CREATE TABLE IF NOT EXISTS carteleria_review_cycles70 (local TEXT NOT NULL,cycle_start TEXT NOT NULL,cycle_number INTEGER NOT NULL,first_day TEXT NOT NULL,last_day TEXT NOT NULL,catalog_revision INTEGER NOT NULL,version INTEGER NOT NULL DEFAULT 1,generation TEXT NOT NULL,data TEXT NOT NULL,PRIMARY KEY(local,cycle_start))'),
    env.DB.prepare('CREATE TABLE IF NOT EXISTS carteleria_weekly_archive70 (local TEXT NOT NULL,week_start TEXT NOT NULL,archived_at TEXT NOT NULL,original TEXT NOT NULL,PRIMARY KEY(local,week_start))')
  ]).catch(error=>{CYD70_INIT.delete(env.DB);throw error;}));
  await CYD70_INIT.get(env.DB);
}
function cyd70assign(categories,start,first,existing=[]){
  const days=Array.from({length:21},(_,i)=>cyd69add(start,i)).filter(d=>d>=first),loads=new Map(days.map(day=>[day,{products:0,count:0,departments:new Map()}]));
  for(const c of existing){const load=loads.get(c.day);if(load&&c.active!==false){load.products+=c.total;load.count++;load.departments.set(c.department,(load.departments.get(c.department)||0)+1);}}
  return [...categories].sort((a,b)=>(a.validUntil||'9999').localeCompare(b.validUntil||'9999')||b.total-a.total||a.key.localeCompare(b.key)).map(c=>{
    const eligible=days.filter(d=>!c.validUntil||d<=c.validUntil);
    if(!eligible.length)return {...c,day:first,active:false,total:0,counts:{red:0,yellow:0,other:0}};
    const day=eligible.sort((a,b)=>{const x=loads.get(a),y=loads.get(b);return x.products-y.products||(x.departments.get(c.department)||0)-(y.departments.get(c.department)||0)||x.count-y.count||a.localeCompare(b);})[0],load=loads.get(day);
    load.products+=c.total;load.count++;load.departments.set(c.department,(load.departments.get(c.department)||0)+1);return {...c,day};
  });
}
function cyd70publishStatement(env,cycle){
  const data=JSON.parse(cycle.data),weeks=Array.from({length:3},(_,i)=>cyd69add(cycle.cycle_start,i*7));
  const payload=weeks.map(week=>({week,first:week===cycle.cycle_start?cycle.first_day:week,data:{categories:data.categories.filter(c=>(data.policy72||!c.carried)&&c.day>=week&&c.day<=cyd69add(week,6)),cycle70:{start:cycle.cycle_start,end:cycle.last_day,number:cycle.cycle_number,version:cycle.version,policy71:!!data.policy71,policy72:!!data.policy72,policy74:!!data.policy74}}}));
  return env.DB.prepare("INSERT INTO carteleria_weekly_plans69 (local,week_start,created_at,start_day,catalog_revision,version,data) SELECT ?,json_extract(value,'$.week'),?,json_extract(value,'$.first'),?,1,json_extract(value,'$.data') FROM json_each(?) WHERE EXISTS (SELECT 1 FROM carteleria_review_cycles70 WHERE local=? AND cycle_start=? AND version=?) ON CONFLICT(local,week_start) DO UPDATE SET data=excluded.data,start_day=excluded.start_day,catalog_revision=excluded.catalog_revision,version=carteleria_weekly_plans69.version+1 WHERE carteleria_weekly_plans69.data<>excluded.data").bind(cycle.local,new Date().toISOString(),cycle.catalog_revision,JSON.stringify(payload),cycle.local,cycle.cycle_start,cycle.version);
}
async function cyd70publish(env,cycle){await cyd70publishStatement(env,cycle).run();}
async function cyd70create(env,local,start,number,rotation,current,groups,today){
  const end=cyd69add(start,20),first=number===1?rotation:start;
  let seeds=[...groups.values()].map(cyd69metadata);
  if(end<today){const previous=await env.DB.prepare('SELECT data FROM carteleria_review_cycles70 WHERE local=? AND cycle_start<? ORDER BY cycle_start DESC LIMIT 1').bind(local,start).first();if(previous)seeds=JSON.parse(previous.data).categories.filter(c=>c.active!==false&&(!c.validUntil||c.validUntil>=first)).map(cyd69metadata);}
  const legacy=(await env.DB.prepare('SELECT * FROM carteleria_weekly_plans69 WHERE local=? AND week_start>=? AND week_start<=?').bind(local,start,cyd69add(start,14)).all()).results;
  const legacyCategories=legacy.flatMap(row=>JSON.parse(row.data).categories),base=new Map([...seeds,...legacyCategories].map(c=>[c.key,c]));
  for(const group of groups.values())if(base.has(group.key))base.set(group.key,{...base.get(group.key),...cyd69metadata(group)});
  const effectiveFirst=number===1?[first,CYD71_REQUESTED_START,today].sort().at(-1):first;
  const data=await cyd71buildData(env,local,start,end,[...base.values()],effectiveFirst),generation=crypto.randomUUID();
  const now=new Date().toISOString(),statements=[env.DB.prepare('INSERT OR IGNORE INTO carteleria_review_cycles70 (local,cycle_start,cycle_number,first_day,last_day,catalog_revision,generation,data) VALUES (?,?,?,?,?,?,?,?)').bind(local,start,number,effectiveFirst,end,current.revision,generation,JSON.stringify(data))];
  for(const row of legacy)statements.push(env.DB.prepare('INSERT OR IGNORE INTO carteleria_weekly_archive70 (local,week_start,archived_at,original) SELECT ?,?,?,? WHERE EXISTS (SELECT 1 FROM carteleria_review_cycles70 WHERE local=? AND cycle_start=? AND generation=?)').bind(local,row.week_start,now,JSON.stringify(row),local,start,generation));
  await env.DB.batch(statements);
  return env.DB.prepare('SELECT * FROM carteleria_review_cycles70 WHERE local=? AND cycle_start=?').bind(local,start).first();
}
async function cyd70sync(env,row,current,groups,today){
  if(JSON.parse(row.data).policy71)return cyd71sync(env,row,current,groups,today);
  for(let attempt=0;attempt<3;attempt++){
    const data=JSON.parse(row.data),known=new Set(data.categories.map(c=>c.key)),existing=data.categories.map(c=>({...c,...(groups.has(c.key)?cyd69metadata(groups.get(c.key)):{active:false,total:0,counts:{red:0,yellow:0,other:0}})}));
    const fresh=[...groups.values()].filter(c=>!known.has(c.key)).map(cyd69metadata),updated={categories:[...existing,...cyd70assign(fresh,row.cycle_start,today,existing)]};
    if(JSON.stringify(data)===JSON.stringify(updated))return row;
    const changed=await env.DB.prepare('UPDATE carteleria_review_cycles70 SET data=?,catalog_revision=?,version=version+1 WHERE local=? AND cycle_start=? AND version=?').bind(JSON.stringify(updated),current.revision,row.local,row.cycle_start,row.version).run();
    row=await env.DB.prepare('SELECT * FROM carteleria_review_cycles70 WHERE local=? AND cycle_start=?').bind(row.local,row.cycle_start).first();if(Number(changed.meta?.changes)===1)return row;
  }
  return row;
}
async function cyd70ensurePlans(env,current,groups,today){return cyd74ensurePlans(env,current,groups,today);}

async function cyd70cycleView(env,local,plan,today){
  const start=plan?.data.cycle70?.start;if(!start)return null;
  const row=env.cyd74Cycles?.get(local+'|'+start)||await env.DB.prepare('SELECT * FROM carteleria_review_cycles70 WHERE local=? AND cycle_start=?').bind(local,start).first();if(!row)return null;
  if(JSON.parse(row.data).policy71){const view=await cyd71cycleView(env,local,plan,row,today),data=JSON.parse(row.data);return {...view,policy74:!!data.policy74,restartDate:CYD74_START,closed:!!data.restartedAt,...(data.restartedAt?{weeks:view.weeks.filter(w=>w.week<=row.last_day),maxWeek:cyd69monday(row.last_day)}:{})};}
  const [checks,prints]=await env.DB.batch([
    env.DB.prepare('SELECT category_key,week_start,reviewed_at FROM carteleria_weekly_reviews69 WHERE local=? AND week_start>=? AND week_start<=?').bind(local,start,cyd69add(start,14)),
    env.DB.prepare('SELECT category_key,week_start,product_key,scheduled_day,printed_at FROM carteleria_weekly_prints69 WHERE local=? AND week_start>=? AND week_start<=?').bind(local,start,cyd69add(start,14))
  ]);
  const reviews=new Map(checks.results.map(r=>[r.week_start+'|'+r.category_key,r])),categories=JSON.parse(row.data).categories.map(c=>{const week=cyd69monday(c.day),review=reviews.get(week+'|'+c.key),latePrints=new Set(prints.results.filter(p=>p.week_start===week&&p.category_key===c.key&&H(new Date(p.printed_at))>p.scheduled_day).map(p=>p.product_key)).size;return {...c,review:review||null,status:c.active===false?'inactive':review?(H(new Date(review.reviewed_at))===c.day?'on':'late'):c.day<today?'missed':c.day===today?'today':'planned',latePrints};});
  return {number:row.cycle_number,start,end:row.last_day,firstDay:row.first_day,weekNumber:Math.floor((new Date(plan.week_start+'T12:00:00Z').getTime()-new Date(start+'T12:00:00Z').getTime())/(7*86400000))+1,maxWeek:cyd69add(start,14),stats:cyd69stats(categories,today),weeks:Array.from({length:3},(_,i)=>{const week=cyd69add(start,i*7),subset=categories.filter(c=>c.day>=week&&c.day<=cyd69add(week,6));return {week,number:i+1,products:subset.reduce((n,c)=>n+c.total,0),...cyd69stats(subset,today)};})};
}
async function cyd70maxWeek(env,today){return cyd69add(CYD74_START,cyd74index(today)*21+14);}

async function cyd70printReferences(req,env,principal){
  const local=cyd69scope(principal,principal.profile.code,true),body=await cyd53body(req,600000),today=cyd53day();
  if(!Array.isArray(body.products)||!body.products.length||body.products.length>1000)cyd53error('La selección de impresión no es válida.');
  if(today<CYD74_START)return cyd54json({ok:true,entries:[]});
  const {current,groups}=await cyd79weekly(env);await cyd69ensurePlans(env,current,groups,today);
  const byProduct=new Map([...groups.values()].flatMap(c=>c.items.map(item=>[item.key,{category:c,item}]))),plans=new Map(),cycles=new Map(),entries=[];
  for(const p of body.products){
    if(!p||typeof p.key!=='string'||p.key.length>250||typeof p.token!=='string'||p.token.length>700)cyd53error('Referencia de producto inválida.');
    const match=byProduct.get(p.key);if(!match)continue;
    if(match.item.token!==p.token)cyd53error('Los precios cambiaron antes de preparar la impresión. Actualiza y vuelve a seleccionar.',409);
    const referenceWeek=cyd69week(p.week&&p.week>=CYD74_START?p.week:undefined,today,true);
    if(!plans.has(referenceWeek))plans.set(referenceWeek,await cyd69plan(env,local,referenceWeek,current,groups,today));
    const plan=plans.get(referenceWeek);let category=plan?.data.categories.find(c=>c.key===match.category.key&&c.active!==false),week=referenceWeek;
    if(p.categoryKey&&p.categoryKey!==match.category.key)cyd53error('El producto no corresponde a esa categoría.',409);
    if(!category&&plan?.data.cycle70){
      const start=plan.data.cycle70.start;
      if(!cycles.has(start)){const cycle=await env.DB.prepare('SELECT data FROM carteleria_review_cycles70 WHERE local=? AND cycle_start=?').bind(local,start).first();cycles.set(start,cycle?JSON.parse(cycle.data):null);}
      category=cycles.get(start)?.categories.find(c=>c.key===match.category.key&&c.active!==false);if(category&&category.day)week=cyd69monday(category.day);
    }
    if(category?.carried)continue;
    if(!category){if(p.week||p.categoryKey)cyd53error('La categoría ya no está programada en este ciclo. Actualiza la revisión.',409);continue;}
    entries.push({week,categoryKey:category.key,key:p.key,token:match.item.token});
  }
  return cyd54json({ok:true,entries});
}
