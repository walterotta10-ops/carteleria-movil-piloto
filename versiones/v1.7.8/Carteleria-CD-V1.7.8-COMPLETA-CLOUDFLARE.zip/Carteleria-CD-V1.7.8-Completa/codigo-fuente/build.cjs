const fs = require('node:fs');
const path = require('node:path');

const root = path.join(__dirname, 'src', 'app');
const types = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.webmanifest': 'application/manifest+json',
  '.png': 'image/png'
};
const assets = {};

function addAssets(directory, prefix = '') {
  for (const entry of fs.readdirSync(directory, { withFileTypes: true }).sort((a,b) => a.name.localeCompare(b.name))) {
    const file = path.join(directory, entry.name);
    const route = prefix + '/' + entry.name;
    if (entry.isDirectory()) {
      addAssets(file, route);
      continue;
    }
    const extension = path.extname(entry.name);
    const type = types[extension];
    if (!type) throw new Error('Tipo de archivo desconocido: ' + route);
    const binary = extension === '.png';
    assets[route] = { type, binary, body: fs.readFileSync(file, binary ? 'base64' : 'utf8') };
  }
}

addAssets(root);
const backend = fs.readFileSync(path.join(__dirname, 'src', 'worker-backend.mjs'), 'utf8') + '\n' + fs.readFileSync(path.join(__dirname, 'src', 'weekly-review-backend.mjs'), 'utf8') + '\n' + fs.readFileSync(path.join(__dirname, 'src', 'review-cycle-backend.mjs'), 'utf8') + '\n' + fs.readFileSync(path.join(__dirname, 'src', 'review-correction-backend.mjs'), 'utf8') + '\n' + fs.readFileSync(path.join(__dirname, 'src', 'promotion-controls-backend.mjs'), 'utf8') + '\n' + fs.readFileSync(path.join(__dirname, 'src', 'review-market-backend.mjs'), 'utf8') + '\n' + fs.readFileSync(path.join(__dirname, 'src', 'catalog-validation-backend.mjs'), 'utf8') + '\n' + fs.readFileSync(path.join(__dirname, 'src', 'alert-lifecycle-backend.mjs'), 'utf8') + '\n' + fs.readFileSync(path.join(__dirname, 'src', 'catalog-performance-backend.mjs'), 'utf8') + '\n' + fs.readFileSync(path.join(__dirname, 'src', 'weekly-performance-backend.mjs'), 'utf8') + '\n' + fs.readFileSync(path.join(__dirname, 'src', 'module-performance-backend.mjs'), 'utf8') + '\n' + fs.readFileSync(path.join(__dirname, 'src', 'print-compliance-backend.mjs'), 'utf8');
const printRules = fs.readFileSync(path.join(root, 'cartel-rules.js'), 'utf8');
const specificationCore = fs.readFileSync(path.join(root, 'specification-core.js'), 'utf8');
const initialPrices = JSON.parse(fs.readFileSync(path.join(__dirname, 'src', 'initial-price-reference.json'), 'utf8'));
const target = path.join(__dirname, 'worker-v1.7.8.mjs');
fs.writeFileSync(target, 'const CYD62_INITIAL_PRICES=' + JSON.stringify(initialPrices) + ';\nconst G=' + JSON.stringify(assets) + '\n' + specificationCore + '\nconst CYD75_SPEC=createSpecificationCore75();\nconst CYD75_PRINT_RULES=(()=>{/** @type {any} */ const window={CYD75_SPEC};\n' + printRules + '\nreturn window.CARTELERIA_RULES;})();\n' + backend);
console.log(target);
