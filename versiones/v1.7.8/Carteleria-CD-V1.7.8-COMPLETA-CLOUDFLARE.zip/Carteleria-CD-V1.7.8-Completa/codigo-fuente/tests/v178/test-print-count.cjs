'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const {DatabaseSync}=require('node:sqlite');
const db=new DatabaseSync(':memory:');
const DB={prepare(sql){return {args:[],bind(...args){this.args=args;return this},run(){return db.prepare(sql).run(...this.args)},first(){return db.prepare(sql).get(...this.args)},all(){return {results:db.prepare(sql).all(...this.args)}}}},async batch(stmts){db.exec('BEGIN');try{const rs=stmts.map(s=>s.run());db.exec('COMMIT');return rs}catch(e){db.exec('ROLLBACK');throw e}}};
db.exec("CREATE TABLE carteleria_config(key TEXT PRIMARY KEY,value TEXT); CREATE TABLE carteleria_promos53(id INTEGER PRIMARY KEY,revision INTEGER); INSERT INTO carteleria_promos53 VALUES(1,3)");
let products=[{occamKey:'A',occamList:'EDLP',qty:1,offer:1000,unit:1500,printability75:{printable:true}},{occamKey:'B',occamList:'LISTA4',qty:1,offer:2000,unit:2200,printability75:{printable:true}},{occamKey:'C',occamList:'EDLP',qty:1,offer:2000,unit:2200,printability75:{printable:false}}];
const ctx=vm.createContext({cyd53init:async()=>{},cyd68catalog:async()=>products,cyd53error:(m,s)=>{throw Object.assign(new Error(m),{status:s})},cyd54json:x=>x,cyd54scope:(p,l)=>String(l),URL,console});
vm.runInContext(fs.readFileSync(path.join(__dirname,'../../src/print-compliance-backend.mjs'),'utf8')+'\nthis.api={cyd81init,cyd81statements,cyd82receipts,cyd82local,cyd81report};',ctx);
const api=ctx.api,env={DB},current={revision:3},started='2026-01-01T00:00:00.000Z',now='2026-11-24T00:00:00.000Z',local='622',A={key:'A',qty:1,offer:1000,unit:1500},B={key:'B',qty:1,offer:2000,unit:2200};
const print=async(rows,ticket,l=local,rev=3)=>DB.batch(await api.cyd81statements(env,{revision:rev},l,rows,now,ticket));
const counts=async(l=local)=>Object.fromEntries((await api.cyd82receipts(env,l,started)).map(r=>[r.occam_key+'|'+r.fingerprint,r.print_count]));
(async()=>{
 await api.cyd81init(env);db.prepare("UPDATE carteleria_config SET value=? WHERE key='cyd81_tracking_since'").run(started);
 // Simulate a receipt created by V1.7.7: only one known print, not an inferred count.
 db.prepare("INSERT INTO carteleria_print_receipts81(local,occam_key,fingerprint,confirmed_at) VALUES(?,?,?,?)").run(local,'A','[1,1000,1500]',now);
 assert.equal((await counts())['A|[1,1000,1500]'],1);
 await print([A,B,B],'ticket1');assert.deepEqual(await counts(),{'A|[1,1000,1500]':2,'B|[1,2000,2200]':1});
 await print([A,B],'ticket1');assert.deepEqual(await counts(),{'A|[1,1000,1500]':2,'B|[1,2000,2200]':1});
 await print([A],'ticket2');assert.equal((await counts())['A|[1,1000,1500]'],3);
 await print([A],'ticket2','171');assert.equal((await counts('171'))['A|[1,1000,1500]'],1);
 await print([A],'ticket3',local,2);assert.equal((await counts())['A|[1,1000,1500]'],3);
 products[0]={...products[0],offer:1100};await assert.rejects(print([A],'old-price'),/precio cambió/);await print([{...A,offer:1100}],'new-price');assert.equal((await counts())['A|[1,1100,1500]'],1);
 const data=await api.cyd82local(env,{profile:{role:'store',code:local}},new URL('https://test/api/carteleria/impresion/local'));assert.equal(data.local,local);assert.equal(data.receipts.length,3);
 await assert.rejects(api.cyd82local(env,{profile:{role:'store',code:local}},new URL('https://test/api/carteleria/impresion/local?local=171')),e=>e.status===403);
 await assert.rejects(api.cyd82local(env,{profile:{role:'master',code:local}},new URL('https://test/api/carteleria/impresion/local')),e=>e.status===403);
 assert.equal(db.prepare('SELECT COUNT(*) n FROM carteleria_print_receipts81 WHERE local=? AND ((occam_key=? AND fingerprint=?) OR (occam_key=? AND fingerprint=?))').get(local,'A','[1,1100,1500]','B','[1,2000,2200]').n,2);
 console.log('OK: D1-compatible SQLite: preserves prior receipts, 1/2/3 confirmations, dedup, local isolation, current price, unchanged unique compliance.');
})().catch(e=>{console.error(e);process.exitCode=1});
