'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const source=fs.readFileSync(path.join(__dirname,'../../src/app/print-compliance.js'),'utf8');
const shown=[];
const page={set innerHTML(v){this.html=v;shown.push(v)},get innerHTML(){return this.html||''}};
const root={isConnected:true,querySelector(selector){if(selector==='[data-cyd81-page]')return page;return null;}};
const host={set innerHTML(s){this.html=s},querySelector(selector){assert.equal(selector,'.cyd81');return root}};
let requests=[];
const summary={ok:true,started:'2026-11-23T00:00:00.000Z',markets:[{market:'814',name:'Santiago Norte',localCount:2,total:4,printed:1,pending:3,excluded:0}],rows:[{local:'622',name:'Quinta Normal',market:'814',total:2,printed:1,pending:1,excluded:0},{local:'171',name:'San Bernardo',market:'814',total:2,printed:0,pending:2,excluded:0}]};
const detail={ok:true,local:'622',name:'Quinta Normal',products:[{key:'A',name:'Leche',item:'123',upc:'7801',qty:1,price:1200,list:'EDLP',family:'red',printedAt:'2026-11-23T00:00:00Z',printable:true},{key:'B',name:'Detergente',item:'124',upc:'7802',qty:1,price:1990,list:'LISTA 4',family:'yellow',printedAt:null,printable:true}]};
const mockWindow={CYD54_ACCESS:{profile:{role:'master'}},fetch:async uri=>{requests.push(uri);return {ok:true,json:async()=>uri.includes('?local=')?detail:summary}}};
vm.runInNewContext(source,{window:mockWindow,fetch:mockWindow.fetch,location:{origin:'https://test.example'},Intl,Date,URL,console});
const flush=()=>new Promise(resolve=>setImmediate(resolve));
(async()=>{
mockWindow.CYD81_COMPLIANCE.open({host});await flush();
assert.match(page.html,/Santiago Norte/);assert.match(page.html,/25 %/);
function click(key,value){
 const btn={hasAttribute:k=>k==='data-cyd81-'+key,dataset:{cyd81Market:value,cyd81Local:value}};
 root.onclick({target:{closest:()=>btn}});
}
click('market','814');assert.match(page.html,/San Bernardo/);click('local','622');await flush();assert.match(page.html,/Detergente/);assert.doesNotMatch(page.html,/Leche/);assert.match(page.html,/Pendientes/);
assert.equal(requests.length,2);
console.log('OK: vista mercado → local → pendientes, porcentajes calculados y GET autenticado');
})().catch(e=>{console.error(e);process.exitCode=1});
