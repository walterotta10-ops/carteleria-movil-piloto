# Validación local
- Compilación de Worker completo y comprobación de sintaxis Node: OK.
- Prueba previa de navegación mercado/local/pendientes: OK.
- SQLite en memoria con las consultas D1: conserva recibo previo, cuenta nuevas confirmaciones, ignora ticket repetido, separa locales, rechaza precio anterior y no duplica el cumplimiento: OK.
- Prueba de renderizado de indicadores mediante DOM simulado: porcentajes, contador, cambios de precio, errores de consulta y perfil local: OK.
- No se ejecutó contra D1 de producción ni impresoras físicas. Se requiere desplegar y validar desde un local.
